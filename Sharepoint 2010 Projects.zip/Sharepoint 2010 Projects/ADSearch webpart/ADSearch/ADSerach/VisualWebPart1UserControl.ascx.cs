﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Runtime.InteropServices;
using System.Xml.Serialization;
using Microsoft.SharePoint.Utilities;


using Microsoft.Office.Server;
using Microsoft.Office.Server.Administration;
using Microsoft.Office.Server.UserProfiles;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Data;
///// a people search webpart
namespace ADSearch.VisualWebPart1
{
    public partial class VisualWebPart1UserControl : UserControl
    {
       // SPSite was not being used
         SPSite mySite = SPContext.Current.Site;
       // SPWeb myWeb = SPContext.Current.Web;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// submit the first and last name to the search resultes page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string strSearchValue = "";
            if (txtFirstName.Text.Trim() != "")
            {
                strSearchValue = txtFirstName.Text.Trim() + "*";/// add a wild card after each text box for wild card search
                if (txtLastName.Text.Trim() != "")
                    strSearchValue += " " + txtLastName.Text.Trim() + "*";/// add a wild card after each text box for wild card search
            }
            else if (txtLastName.Text.Trim() != "")
            {
                strSearchValue = txtLastName.Text.Trim() + "*";/// add a wild card after each text box for wild card search
            }
            // if the search vaule is empty trigger the alert box
            if (strSearchValue != "")
            {
                //not sure why its not getting the url dynmically i changed it but i kept the code to change it back just in case
                //SPList splstSiteUrl = myWeb.Lists["Site URL"];
                //SPListItem splstitemSiteUrl = splstSiteUrl.Items.GetItemById(1);

               /// string strSiteUrl = splstitemSiteUrl["Title"].ToString() + "/search/Pages/peopleresults.aspx?k=";
                string strSiteUrl = mySite.Url + "/search/Pages/peopleresults.aspx?k=" + strSearchValue + "&rm1=0BBA4D7D%2D4F2C%2D4086%2D975A%2D8F9D2B6C6D53"; 
                Response.Redirect(strSiteUrl);
            }
            else
            {
               // AlertMessage("Please enter valid first name or last name.");
            }

        }
        /// <summary>
        /// pop up an alert if the first and last name are empty
        /// </summary>
        /// <param name="Msg"></param>
        void AlertMessage(string Msg)
        {
            Page.RegisterStartupScript("Alert", Msg);
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
        }
    }
}
