﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Publishing;


namespace APM_iAscendHome_Master.Module1
{
    public class APMiAscendHome :System.Web.UI.MasterPage
    {
        //protected void Page_PreRender(object sender, EventArgs e)
        protected void Page_PageLoad(object sender, EventArgs e)
        {
            ClientContext clientContext = new ClientContext("http://dc1dvsp10-map:11110/sites/myascend/");
           
            Web web = clientContext.Web;

            //Get Logged in user's username
            string logged_in_user_username = web.CurrentUser.LoginName;
            
            //Get all Groups in the site
            GroupCollection all_site_groups = clientContext.Web.SiteGroups;
            
            //load all site groups
            //clientContext.Load(all_site_groups);

            //load all users in all the site groups
            //clientContext.Load(all_site_groups, groups => groups.Include(group => group.Users));

            //clientContext.ExecuteQuery();
            
           
            foreach (Group each_group in all_site_groups)
            {
                UserCollection all_group_users = each_group.Users;

                foreach (User each_user in all_group_users)
                {
                    if (logged_in_user_username != each_user.LoginName)
                    { 
                    //Hide it asp menu
                        Menu menu = Master.FindControl("mnuGlobalNav") as Menu;
                        //MenuItemCollection menu =
                       // menu.enumyascend.Visible = false;
                        //menu.Items[1].Enabled = false;
                      
                        
                       
                    }

                    else { }
                }
            }
        }
    }

}
