﻿function DeleteAttachment(value)
{
  return confirm("Are you sure you want to delete the attachment '" + value + "'?");
}

function DeletePlatform(value)
{
  return confirm("Are you sure you want to delete the platform '" + value + "'?");
}

function DeleteSite(value)
{
  return confirm("Are you sure you want to delete the site '" + value + "'?");
}

function DeleteUser(value)
{
  return confirm("Are you sure you want to delete the user '" + value + "'?");
}

function DeleteIncident()
{
  return confirm("Are you sure you want to delete the incident?");
}
