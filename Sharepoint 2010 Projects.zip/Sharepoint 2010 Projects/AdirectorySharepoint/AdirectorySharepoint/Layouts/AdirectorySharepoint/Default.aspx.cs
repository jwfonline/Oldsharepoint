﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;

using Ascend.Lib;

using Ascend.ADirectory;
using AdirectorySharepoint.ControlTemplates.AdirectorySharepoint;

namespace AdirectorySharepoint.Layouts.AdirectorySharepoint
{
    public partial class ApplicationPage1 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblWarning.Text = String.Empty;
            lblWarning2.Text = String.Empty;
            if (!IsPostBack) BindData();

            // set focus to retrieve button
            Page.SetFocus(btnRetrieve);
        }

        private void BindData()
        {
            pnlGrid.Visible = false;
            pnlDetails.Visible = false;
            pnlUpdate.Visible = false;

            //DataTable dt = PSUser.GetBusinessList();
            //ddlBusinessSearch.DataSource = dt;
            //ddlBusinessSearch.DataBind();

            //ddlBusinessSearch.Items.Insert(1, new ListItem("<blank>", "BLANK"));

            //ddlBusiness.DataSource = dt;
            //ddlBusiness.DataBind();

            // same field name as old asp code
            string lastName = Util.GetRequestString("Directory");
            if (lastName.Length > 0)
            {
                txtLastNameSearch.Text = lastName;
                RetrieveData();
            }

            // check for id too
            string id = Util.GetRequestString("id");
            if (id.Length > 0)
            {
                txtUserIdSearch.Text = id;
                RetrieveData();
            }
        }


        protected void btnRetrieve_Click(object sender, EventArgs e)
        {
            RetrieveData();
        }

        private void RetrieveData()
        {
            // verify at least 1 search criteria
            string criteria = String.Format("{0}{1}{2}{3}{4}{5}{6}{7}", txtLastNameSearch.Text, txtFirstNameSearch.Text, txtLDPhoneSearch.Text, txtMailZoneSearch.Text, txtOfficeSearch.Text, txtPhoneSearch.Text, txtUserIdSearch.Text, ddlBusinessSearch.SelectedValue);

            if (criteria.Length == 0)
            {
                lblWarning.Text = "You must enter at least 1 search criteria.";
                return;
            }

            // get filtered datatable
            DataTable dt = GetDataTable();

            GridView1.DataSource = dt;
            GridView1.DataBind();

            // show/hide details
            pnlUpdate.Visible = false;

            if (dt.Rows.Count == 0)
            {
                pnlGrid.Visible = false;
                pnlDetails.Visible = false;
            }
            else
            {
                pnlGrid.Visible = true;
                pnlDetails.Visible = true;
                GridView1.SelectedIndex = 0;
                DataKey key = GridView1.SelectedDataKey;
                string userId = key.Value.ToString();
                BindDetails(userId);
            }
        }


        private DataTable GetDataTable()
        {

            ADUser user = new ADUser();
            //cast the user controls as the correct type
            UC_SearchType LastNameSearchType = (UC_SearchType)ucLastNameSearchType;
            UC_SearchType FirstNameSearchType = (UC_SearchType)ucFirstNameSearchType;
            UC_SearchType LDPhoneSearchType = (UC_SearchType)ucLDPhoneSearchType;
            UC_SearchType PhoneSearchType = (UC_SearchType)ucPhoneSearchType;
            UC_SearchType OfficeSearchType = (UC_SearchType)ucOfficeSearchType;
            UC_SearchType MailZoneSearchType = (UC_SearchType)ucMailZoneSearchType;
            UC_SearchType UserIdSearchType = (UC_SearchType)ucUserIdSearchType;

            user.LastName = txtLastNameSearch.Text;
            user.LastNameSearchType = LastNameSearchType.ValueEnum;

            user.FirstName = txtFirstNameSearch.Text;
            user.FirstNameSearchType = FirstNameSearchType.ValueEnum;

            user.BusinessPhone = txtLDPhoneSearch.Text;
            user.BusinessPhoneSearchType = LDPhoneSearchType.ValueEnum;

            user.OtherPhone = txtPhoneSearch.Text;
            user.OtherPhoneSearchType = PhoneSearchType.ValueEnum;

            user.Office = txtOfficeSearch.Text;
            user.OfficeSearchType = OfficeSearchType.ValueEnum;

            user.Zip = txtMailZoneSearch.Text;
            user.ZipSearchType = MailZoneSearchType.ValueEnum;

            user.UserId = txtUserIdSearch.Text;
            user.UserIdSearchType = UserIdSearchType.ValueEnum;

            user.BusinessCategory = ddlBusinessSearch.SelectedValue;

            DataTable dt = user.GetResultsDataTable();

            // remove manager column (data not there)
            dt.Columns.Remove("Manager");

            return dt;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataKey key = GridView1.SelectedDataKey;
            string userId = key.Value.ToString();
            BindDetails(userId);
        }

        private void BindDetails(string userId)
        {
            pnlDetails.Visible = true;
            pnlUpdate.Visible = false;

            ADUser user = new ADUser(userId);
            FormView1.DataSource = user.GetUserDataTable();
            FormView1.DataBind();

            btnUpdate.Visible = (userId == Var.CurrentUserName );
        }

        private void BindForUpdate(string userId)
        {
            pnlDetails.Visible = false;
            pnlUpdate.Visible = true;

            // populate ADUser object
            ADUser aduser = new ADUser(userId);

            //// populate text fields
            litLast.Text = aduser.LastName;
            litMI.Text = aduser.MiddleInitial;
            txtFirstName.Text = aduser.FirstName;

            litAlias.Text = aduser.Alias;
            txtDisplayName.Text = aduser.DisplayName;

            litOffice.Text = aduser.Office;
            txtMailZone.Text = aduser.Zip;

            txtBusinessPhone.Text = aduser.BusinessPhone;
            txtOtherPhone.Text = aduser.OtherPhone;
            txtHomePhone.Text = aduser.HomePhone;
            txtOtherHomePhone.Text = aduser.OtherHomePhone;
            txtMobile.Text = aduser.Mobile;
            txtPager.Text = aduser.Pager;
            txtFax.Text = aduser.Fax;

            txtNotes.Text = aduser.Notes;

            if (!ddlBusiness.Items.Contains(new ListItem(aduser.BusinessCategory)))
                ddlBusiness.Items.Add(new ListItem(aduser.BusinessCategory));
            ddlBusiness.SelectedValue = aduser.BusinessCategory;

          //  trBusiness.Visible = (!PSUser.IsPeoplesoftUser(userId));
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string userId = GetDetailsUserId();
            BindForUpdate(userId);
        }

        protected string GetDetailsUserId()
        {
            string userId = Var.CurrentUserName;

            //if (Var.IsSystemAdmin())
            //{
            //    DataKey key = GridView1.SelectedDataKey;
            //    userId = key.Value.ToString();
            //}

            return userId;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (txtDisplayName.Text.Trim().Length == 0)
            {
                lblWarning2.Text = "You must enter a display name";
                return;
            }

            if (txtDisplayName.Text.IndexOf(",") == -1)
            {
                lblWarning2.Text = "Display Name must be in 'Last, First' format (e.g. Smith, Mary)";
                return;
            }

            if (txtFirstName.Text.Trim().Length == 0)
            {
                lblWarning2.Text = "You must enter a first name";
                return;
            }


            ADUser user = new ADUser();

            user.FirstName = txtFirstName.Text.Trim();
            user.DisplayName = txtDisplayName.Text.Trim();
            user.Zip = txtMailZone.Text.Trim();
            user.Notes = txtNotes.Text.Trim();
            user.BusinessPhone = txtBusinessPhone.Text.Trim();
            user.OtherPhone = txtOtherPhone.Text.Trim();
            user.HomePhone = txtHomePhone.Text.Trim();
            user.OtherHomePhone = txtOtherHomePhone.Text.Trim();
            user.Fax = txtFax.Text.Trim();
            user.Mobile = txtMobile.Text.Trim();
            user.Pager = txtPager.Text.Trim();
            user.BusinessCategory = ddlBusiness.SelectedValue;
            user.UpdateManualValues(GetDetailsUserId(), trBusiness.Visible);

            BindDetails(GetDetailsUserId());
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            BindDetails(GetDetailsUserId());
        }


        protected void lnkExport_Click(object sender, EventArgs e)
        {
            //Response.ContentType = "application/vnd.ms-excel";
            //Response.Charset = string.Empty;
            //this.Page.EnableViewState = false;

            //StringWriter tw = new StringWriter();
            //HtmlTextWriter hw = new HtmlTextWriter(tw);

            //GridView gv = new GridView();
            //gv.Font.Size = FontUnit.Point(8);
            //gv.HeaderStyle.BackColor = System.Drawing.Color.LightGray;
            //gv.AutoGenerateColumns = true;
            //gv.DataSource = GetDataTable();
            //gv.DataBind();

            //gv.RenderControl(hw);
            //Response.Write(tw.ToString());

            //Response.End();
        }
    }
}
