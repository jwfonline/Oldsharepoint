﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Ascend.ADirectory;
namespace AdirectorySharepoint.ControlTemplates.AdirectorySharepoint
{
    public partial class UC_SearchType : UserControl
    {

        public string Value
        {
            get { return DropDownList1.SelectedValue; }
            set { DropDownList1.SelectedValue = value; }
        }

       
        public ADUser.WildCardSearch ValueEnum
        {
            get
            {
                switch (DropDownList1.SelectedValue)
                {
                    case "1":
                        return ADUser.WildCardSearch.StartsWith;
                    case "2":
                        return ADUser.WildCardSearch.EqualTo;
                    case "3":
                        return ADUser.WildCardSearch.Contains;
                    case "4":
                        return ADUser.WildCardSearch.EndsWith;
                    default:
                        return ADUser.WildCardSearch.StartsWith;
                }
            }
            set
            {
                DropDownList1.SelectedValue = value.ToString();

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
