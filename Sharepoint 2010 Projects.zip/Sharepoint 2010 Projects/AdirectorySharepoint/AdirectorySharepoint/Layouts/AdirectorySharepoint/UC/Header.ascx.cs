﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Ascend.ADirectory;

namespace AdirectorySharepoint.ControlTemplates.AdirectorySharepoint
{
    public partial class Header : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            litUser.Text = Var.CurrentUserName;
        }
    }
}
