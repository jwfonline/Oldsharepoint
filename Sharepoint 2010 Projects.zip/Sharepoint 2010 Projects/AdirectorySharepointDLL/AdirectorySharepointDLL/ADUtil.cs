using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Caching;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Ascend.ADirectory;
using Ascend.Lib;


/// <summary>
/// Summary description for Util
/// </summary>
public class ADUtil : System.Web.UI.Page
{
  private static readonly string CacheCategory = "Caching";

  public ADUtil()
	{
	}

  public static void BindListControl(ListControl list, DataTable dt, int valueField, int textField)
  {
    list.DataValueField = dt.Columns[valueField].ColumnName;
    list.DataTextField = dt.Columns[textField].ColumnName;
    list.DataSource = dt;
    list.DataBind();
  }

  public static void BindListControl(ListControl list, DataTable dt)
  {
    BindListControl(list, dt, 0, 1);
  }

  public static DataTable AddDataTableToCache(string cacheName, string sql, string connect)
  {
    DataTable dt = Db.GetDataTable(sql, connect);
    AddDataTableToCache(cacheName, dt);
    return dt;
  }


  public static void RemoveDataTableFromCache(string cacheName)
  {
    HttpRuntime.Cache.Remove(cacheName);
    HttpContext.Current.Trace.Write(CacheCategory, string.Format("Removed {0} from cache.", cacheName));
  }

  public static void AddDataTableToCache(string cacheName, DataTable dt)
  {
    HttpRuntime.Cache.Add(cacheName, dt, null,
                          DateTime.Now.AddSeconds(Var.CacheExpirationInSeconds),
                          TimeSpan.Zero, CacheItemPriority.Default, null);
    HttpContext.Current.Trace.Write(CacheCategory, string.Format("Added {0} to cache.", cacheName));
  }

  public static DataTable GetDataTableFromCache(string cacheName)
  {
    DataTable dt = new DataTable();
    object evalCache = HttpRuntime.Cache.Get(cacheName);
    if (evalCache != null) dt = (DataTable)evalCache;
    return dt;
  }

  public static DataTable GetDataTableFromCache(string cacheName, string sql, string connect)
  {
    DataTable dt = new DataTable();
    object evalCache = HttpRuntime.Cache.Get(cacheName);
    if (evalCache != null)
    {
      dt = (DataTable)evalCache;
      HttpContext.Current.Trace.Write(CacheCategory, string.Format("Retrieved {0} from cache.", cacheName));
    }
    else
    {
      HttpContext.Current.Trace.Write(CacheCategory, string.Format("Retrieved {0} from database - cache enabled.", cacheName));
      dt = AddDataTableToCache(cacheName, sql, connect);
    }
    return dt;
  }

  public static DataTable GetFilteredDataTable(string filter, DataTable dt)
  {
    DataRow[] rows = dt.Select(filter);
    DataTable dtFiltered = dt.Clone();
    foreach (DataRow row in rows) dtFiltered.ImportRow(row);
    return dtFiltered;
  }

 

}
