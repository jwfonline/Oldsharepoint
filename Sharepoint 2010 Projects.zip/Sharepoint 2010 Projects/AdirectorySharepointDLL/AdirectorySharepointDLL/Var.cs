using System;
using System.Configuration;
using System.Web;

using Ascend.ADirectory;
using Ascend.Lib;

namespace Ascend.ADirectory
{

  using System;

	/// <remarks>
	/// Class. Accessor class with properties to return variables 
	/// stored in the web.config file or in session variables
	/// </remarks>
	public class Var
	{

    /// <summary>String constant. Holds name of default page.</summary>
    public const string DefaultAspx = "~/default.aspx";

    /// <summary>String constant. Holds name of logon page.</summary>
    public const string UnauthorizedAspx = "~/Unauthorized.aspx";
        
    public static readonly string RegistryKey = "ADIR";

    public static string DisplayDateFormat = @"M/d/yyyy";
    //public static string PeopleSoftConnect = RegistryEntry.GetKeyValue(RegistryKey, "PeopleSoftConnect", true);
    //public static string SiteInfoConnect = RegistryEntry.GetKeyValue(RegistryKey, "SiteInfoConnect", true);
    public static readonly double CacheExpirationInSeconds = 3600;
   // public static string EAUsers = RegistryEntry.GetKeyValue(RegistryKey, "EAUsers", false);
    
    public static string LDAPPath = @"LDAP://apm.ascend.com/DC=apm,DC=ascend,DC=com";
    public static string LDAPUserName = @"apm\galmod";
    public static string LDAPPassword = @"WiseAsc2010";


    //static public bool IsSystemAdmin()
    //{
    //    return (Var.EAUsers.IndexOf(Var.CurrentUserName) != -1);
    //}

		
	    /// <summary>
        /// Static method. Sets session variable with value.
        /// Source=Session.
        /// </summary>
        /// <param name="varName">Name of session variable.</param>
        /// <param name="varValue">Value to set session variable.</param>
        static public void Session(string varName, string varValue)
        {
          HttpContext.Current.Session[varName] = varValue;
        }

        /// <summary>
        /// Static method. Gets session variable value.
        /// Source=Session.
        /// </summary>
        /// <param name="varName">Name of session variable.</param>
        static public string Session(string varName)
        {
          if (HttpContext.Current.Session[varName] == null)
            return "";
          else
            return HttpContext.Current.Session[varName].ToString();
        }

	    static public string CurrentUserIdentityName
	    {
		    get { return HttpContext.Current.User.Identity.Name; }
	    }

	    static public string CurrentUserName
	    {
            get { return Ascend.Lib.Util.RemoveDomain(CurrentUserIdentityName); }
	    }

	}
}
