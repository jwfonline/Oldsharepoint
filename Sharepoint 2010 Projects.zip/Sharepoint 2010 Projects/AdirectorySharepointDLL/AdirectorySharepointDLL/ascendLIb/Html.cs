using System;
using System.Text;

namespace Ascend.Lib
{
	/// <summary>
	/// Useful Html related methods.
	/// </summary>
	public class Html
	{

    /// <summary>Const. HTML non-breaking space (1)</summary>
    public const string Nbsp1 = "&nbsp;";

    /// <summary>Const. HTML non-breaking space (2)</summary>
    public const string Nbsp2 = "&nbsp;&nbsp;";

    /// <summary>Const. HTML non-breaking space (3)</summary>
    public const string Nbsp3 = "&nbsp;&nbsp;&nbsp;";
    
    /// <summary>Const. HTML line break</summary>
    public const string Br = "<br clear=\"all\">";

    /// <summary>
    /// Static method. Returns a html attribute name/value pair.
    /// </summary>
    /// <param name="name">Name of the attribute.</param>
    /// <param name="value">Value of the attribute.</param>
    /// <returns>Returns formatted attribute for an element.</returns>
    public static string GetAttribute(string name, string value)
    {
      if (value.Length == 0)
      {
        return String.Empty; 
      }
      else 
      {
        StringBuilder sb = new StringBuilder(100);
        sb.Append(" ");
        sb.Append(name);
        sb.Append("=\"");
        sb.Append(value);
        sb.Append("\"");
        return sb.ToString();
      }
    }

    /// <summary>
    /// Static method. Returns formatted anchor tag.
    /// </summary>
    /// <param name="href">href attribute value</param>
    /// <param name="style">class attribute value</param>
    /// <param name="text">text to display in anchor</param>
    /// <param name="target">target to display page if user clicks on link</param>
    /// <param name="tooltip">tooltip to display when user hovers over link</param>
    /// <returns></returns>
    public static string A(string text, string href, string style, string target, string tooltip)
    {
      return A(text, href, style, target, tooltip, String.Empty);
    }

    /// <summary>
    /// Static method. Returns formatted anchor tag.
    /// </summary>
    /// <param name="href">href attribute value</param>
    /// <param name="style">class attribute value</param>
    /// <param name="text">text to display in anchor</param>
    /// <param name="target">target to display page if user clicks on link</param>
    /// <param name="tooltip">tooltip to display when user hovers over link</param>
    /// <param name="id">id to assign to anchor</param>
    /// <returns>String. Html anchor tag</returns>
    public static string A(string text, string href, string style, string target, string tooltip, string id)
    {
      StringBuilder sb = new StringBuilder(100);
      sb.Append("<a");
      sb.Append(Html.GetAttribute("href", href));
      sb.Append(Html.GetAttribute("class", style));
      sb.Append(Html.GetAttribute("target", target));
      sb.Append(Html.GetAttribute("title", tooltip));
      sb.Append(Html.GetAttribute("id", id));
      sb.Append(">");
      sb.Append(text);
      sb.Append("</a>");
      return sb.ToString();
    }

    /// <summary>
    /// Static method. Returns html img tag.
    /// </summary>
    /// <param name="src">Href attribute value.</param>
    /// <param name="height">Height attribute value.</param>
    /// <param name="width">Width attribute value.</param>
    /// <param name="cssclass">Css class attribute value.</param>
    /// <param name="tooltip">Title attribute value.</param>
    /// <param name="alt">Alt attribute value.</param>
    /// <param name="border">Border attribute value.</param>
    /// <param name="hspace">HSpace attribute value.</param>
    /// <param name="vspace">VSpace attribute value.</param>
    /// <returns>Html Img tag with attributes</returns>
    public static string Img(string src, string height, string width, string cssclass, string tooltip, string alt, string border, string hspace, string vspace)
    {
      StringBuilder sb = new StringBuilder(100);
      sb.Append("<img");
      sb.Append(Html.GetAttribute("src", src));
      sb.Append(Html.GetAttribute("height", height));
      sb.Append(Html.GetAttribute("width", width));
      sb.Append(Html.GetAttribute("class", cssclass));
      sb.Append(Html.GetAttribute("title", tooltip));
      sb.Append(Html.GetAttribute("alt", alt));
      sb.Append(Html.GetAttribute("border", border));
      sb.Append(Html.GetAttribute("hspace", hspace));
      sb.Append(Html.GetAttribute("vspace", vspace));
      sb.Append(">");
      return sb.ToString();
    }

    /// <summary>
    /// Static method. Returns html span tag.
    /// </summary>
    /// <param name="text">Span text value.</param>
    /// <param name="cssclass">Class attribute value.</param>
    /// <returns>Html span tag with attributes</returns>

    public static string Span(string text, string cssclass)
    {
      StringBuilder sb = new StringBuilder(100);
      sb.Append("<span");
      sb.Append(Html.GetAttribute("class", cssclass));
      sb.Append(">");
      sb.Append(text);
      sb.Append("</span>");
      return sb.ToString();
    }

    /// <summary>
    /// Static method. Returns specified number of non-breaking spaces.
    /// </summary>
    /// <param name="count">Int. Number of spaces to return.</param>
    /// <returns>String of non-breaking spaces of specified length.</returns>
    public static string GetNbsp(int count)
    {
      StringBuilder sb = new StringBuilder(50);
      for (int i=0; i<count; i++)
      {
        sb.Append(Nbsp1);
      }
      return sb.ToString();
    }

	}

}
