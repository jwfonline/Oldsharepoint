using System;
using System.Configuration;

namespace Ascend.Lib
{
	/// <summary>
	/// Class containing constants, variables, and properties
	/// </summary>
  public class Const
  {
    public Const()
    {
    }

    /// <summary>String constant. Default date display format.</summary>
    public static string DefaultDateFormat = "dd-MMM-yyyy";

    /// <summary>String property. Returns Ascend lib path.
    /// 
    /// </summary>
    public static string AscendLibPath
    {
      get 
      {
          string path = "";// ConfigurationManager.AppSettings["AscendLibPath"].ToString();
        if (path == "") 
        {
          return "/Ascendlib"; 
        }
        else if (path.EndsWith("/"))
        {
          return path;
        }
        else
        {
          return path + "/";
        }
      }
    }


    /// <summary>String property. Calendar gif file name.</summary>
    public static string CalendarGif 
    {
      get { return AscendLibPath + "images/calendar.gif"; }
    }

    /// <summary>String property. Date Picker aspx file name.</summary>
    public static string DatePickerAspx
    {
      get { return AscendLibPath + "tools/datepicker.aspx"; }
    }

  }

}
