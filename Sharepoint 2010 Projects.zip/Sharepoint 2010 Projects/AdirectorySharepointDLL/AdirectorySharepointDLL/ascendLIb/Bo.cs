using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Text;
using Ascend.Lib; 

namespace Ascend.Lib
{
	/// <remarks>
	/// Class. Utility business object methods and properties.
	/// NOTE: All database table business objects goes through this class.
	/// This class contains static methods to handle updates, inserts, and deletes
	/// </remarks>
	public class Bo
	{

    // private variables
    private bool _add = false;
    private string _connect = String.Empty;
    private string _updateTable = String.Empty;
    private string _insertTable = String.Empty;
    private string _deleteTable = String.Empty;
    private Hashtable _field = new Hashtable() ;
    private Hashtable _where = new Hashtable();
    private Hashtable _datatype = new Hashtable();

    /// <summary>
    /// Gets/sets add mode. If not add mode, we are in edit (update or delete) mode.
    /// </summary>
    public bool AddMode 
    {
      get { return _add; }
      set { _add = value;}
    }

    /// <summary>
    /// Gets/sets connect string for database operations
    /// </summary>
    public string Connect
    {
      get { return _connect; }
      set { _connect = value; }
    }
    
    /// <summary>
    /// Gets/sets table name for update sql statements
    /// </summary>
    public string UpdateTable
    {
      get { return _updateTable; }
      set { _updateTable = value; }
    }

    /// <summary>
    /// Gets/sets table name for insert sql statements
    /// </summary>
    public string InsertTable
    {
      get { if (_insertTable.Length == 0) return _updateTable; else return _insertTable; }
      set { _insertTable = value; }
    }

    /// <summary>
    /// Gets/sets table name for delete sql statements
    /// </summary>
    public string DeleteTable
    {
      get { if (_deleteTable.Length == 0) return _updateTable; else return _deleteTable; }
      set { _deleteTable = value; }
    }

    public bool HasParms
    {
      get { return (_datatype.Count > 0); }
    }

    /// <summary>
    /// Gets the update sql statement based on values stored using AddField() and AddWhere() methods
    /// </summary>
    public string UpdateSql
    { 
      get 
      {
        string fields = GetUpdateHashtableString(_field, ", ");
        string where = GetUpdateHashtableString(_where, " and ");
        StringBuilder sb = new StringBuilder(250);
        sb.Append("update ");
        sb.Append(UpdateTable);
        sb.Append(" set ");
        sb.Append(fields);
        sb.Append(" where ");
        sb.Append(where);
        return sb.ToString();
      }
    }

    /// <summary>
    /// Gets the delete sql statement based on values stored using AddWhere() method
    /// </summary>
    public string DeleteSql
    { 
      get 
      {
        string where = GetUpdateHashtableString(_where, " and ");
        StringBuilder sb = new StringBuilder(250);
        sb.Append("delete from ");
        sb.Append(DeleteTable);
        sb.Append(" where ");
        sb.Append(where);
        return sb.ToString();
      }
    }

    /// <summary>
    /// Gets insert sql statement based on values stored using AddFields() method
    /// </summary>
    public string InsertSql
    {
      get
      {
        StringBuilder sql = new StringBuilder(2000);
        StringBuilder sbfields = new StringBuilder(250);
        StringBuilder sbvalues = new StringBuilder(250);
        IDictionaryEnumerator e = _field.GetEnumerator();
      
        bool first = true;

        e.Reset();
        while (e.MoveNext())
        {
          if (!first) 
          { 
            sbfields.Append(", "); 
            sbvalues.Append(", ");
          }

          sbfields.Append(e.Key);
          if (e.Value == null || e.Value.ToString().Length == 0)
          {
            sbvalues.Append("null");
          }
          else
          {
            if (HasParms) sbvalues.AppendFormat(":p{0}", e.Key); else sbvalues.Append(e.Value.ToString());
          }
          first = false;
        }

        sql.Append("insert into ");
        sql.Append(InsertTable);
        sql.Append(" (");
        sql.Append(sbfields.ToString());
        sql.Append(")");
        sql.Append(" values (");
        sql.Append(sbvalues.ToString());
        sql.Append(")");

        return sql.ToString();
      }
    }
    
    /// <summary>
    /// Turns on AddMode. A call to Update() will result in an insert sql statement.
    /// </summary>
    public void AddNew()
    {
      _add = true;
    }

    /// <summary>
    /// Adds a name/value pair to the _field hashtable used to build insert and update statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">value formatted for insert or insert statements</param>
    public void AddField(string key, string value)
    {
      _field[key] = value;
    }

    /// <summary>
    /// Adds a name/value pair to the _field hashtable used to build insert and update statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">value formatted for insert or insert statements</param>
    /// <param name="datatype">Oracle datatype used when creating insert/update/delete parameters</param>
    public void AddField(string key, string value, string datatype)
    {
      _field[key] = value;
      _datatype[key] = datatype;
    }

    /// <summary>Adds a name/value pair to the _field hashtable used to build insert and update statements.</summary>
    public void AddField(string key, int value)
    {
      _field[key] = value.ToString();
    }

    /// <summary>
    /// Adds a name/value pair and formats value as a string
    /// </summary>
    /// <param name="key">key to add</param>
    /// <param name="value">value to add</param>
    public void AddFieldString(string key, string value)
    {
      _field[key] = FormatString(value);
    }

    /// <summary>
    /// Adds a name/value pair and formats value as a date
    /// </summary>
    /// <param name="key">key to add</param>
    /// <param name="value">value to add</param>
    public void AddFieldDate(string key, string value)
    {
      _field[key] = FormatDate(value);
    }

    /// <summary>
    /// Adds a name/value pair to the _where hashtable used to build update and delete statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">formatted string</param>
    public void AddWhere(string key, string value)
    {
      _where[key] = value;
    }

    /// <summary>
    /// Adds a name/value pair to the _where hashtable used to build update and delete statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">formatted string</param>
    /// <param name="datatype">oracle datatype used to build parameter object during insert/update/delete</param>
    public void AddWhere(string key, string value, string datatype)
    {
      _where[key] = value;
      _datatype[key] = datatype;
    }

    /// <summary>
    /// Adds a name/value pair to the _where hashtable used to build update and delete statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">integer value</param>
    public void AddWhere(string key, int value)
    {
      _where[key] = value.ToString();
    }

    /// <summary>
    /// Adds a name/value pair to the _where hashtable used to build update and delete statements.
    /// </summary>
    /// <param name="key">key field to add</param>
    /// <param name="value">formatted string</param>
    public void AddWhereString(string key, string value)
    {
      _where[key] = FormatString(value);
    }

    /// <summary>
    /// Builds name/value pairs formatted for update set clauses or where clauses.
    /// </summary>
    /// <param name="ht">hash table with field name/value pairs.</param>
    /// <param name="delim">Delimiter between each name/value pair.</param>
    /// <returns>string formatted for update set or where clauses</returns>
    /// <example>
    ///   sample: "id=12, str='test'"
    ///   sample: "id=1 and type='P'" 
    /// </example>
    public string GetUpdateHashtableString(Hashtable ht, string delim)
    {
      StringBuilder sb = new StringBuilder(250);
      IDictionaryEnumerator e = ht.GetEnumerator();

      bool first = true;

      while (e.MoveNext())
      {
        if (!first) sb.Append(delim);
        if (e.Value == null || e.Value.ToString().Length == 0)
        {
          sb.Append(e.Key);
          if (delim == ", ")
            sb.Append(" = null");
          else
            sb.Append(" is null");
        }
        else
        {
          sb.Append(e.Key);
          sb.Append(" = ");

          if (HasParms) sb.AppendFormat(":p{0}", e.Key); else sb.Append(e.Value.ToString());
        }
        first = false;
      }
      return sb.ToString();
    }

    /// <summary>
    /// Execute update or insert statment based on AddMode.
    /// </summary>
    /// <returns>Number of rows affected.</returns>
    public int Update()
    {
      return Update(this.Connect);
    }

    /// <summary>
    /// Execute update or insert statement based on AddMode.
    /// </summary>
    /// <param name="connect">Database connection string.</param>
    /// <returns>Number of rows affected.</returns>
    public int Update(string connect)
    {
      if (AddMode) return Insert(connect);

      if (HasParms) return Db.ExecuteNonQuery(UpdateSql, GetDataParameters(), connect);

      return Db.ExecuteNonQuery(UpdateSql, connect);
    }

    /// <summary>
    /// Execute update or insert statement based on AddMode.
    /// </summary>
    /// <param name="conn">Open database connection.</param>
    /// <returns>Number of rows affected.</returns>
    public int Update(IDbConnection conn)
    {
      if (AddMode) return Insert(conn);

      if (HasParms) return Db.ExecuteNonQuery(UpdateSql, GetDataParameters(), conn);

      return Db.ExecuteNonQuery(UpdateSql, conn);
    }

		/// <summary>
		/// Execute update or insert statement based on AddMode.
		/// </summary>
		/// <param name="conn">Open database connection.</param>
		/// <param name="trans">Tranaction object to support commits and rollbacks</param>
		/// <returns>Number of rows affected.</returns>
		public int Update(IDbConnection conn, IDbTransaction trans)
		{
			if (AddMode) return Insert(conn, trans);

      if (HasParms) return Db.ExecuteNonQuery(UpdateSql, GetDataParameters(), conn, trans);
      
			return Db.ExecuteNonQuery(UpdateSql, conn, trans);
		}
		
		/// <summary>
    /// Execute an insert statement.
    /// </summary>
    /// <returns>Number of rows inserted.</returns>
    public int Insert()
    {
      return Insert(this.Connect);
    }

    /// <summary>
    /// Execute an insert statment.
    /// </summary>
    /// <param name="connect">Database connection string.</param>
    /// <returns>Number of rows inserted.</returns>
    public int Insert(string connect)
    {
      if (HasParms) return Db.ExecuteNonQuery(InsertSql, GetDataParameters(), connect);

      return Db.ExecuteNonQuery(InsertSql, connect);
    }

    /// <summary>
    /// Execute an insert statement.
    /// </summary>
    /// <param name="conn">Open database connection</param>
    /// <returns>Number of rows inserted.</returns>
    public int Insert(IDbConnection conn)
    {
      if (HasParms) return Db.ExecuteNonQuery(InsertSql, GetDataParameters(), conn);

      return Db.ExecuteNonQuery(InsertSql, conn);
    }

		/// <summary>
		/// Execute an insert statement.
		/// </summary>
		/// <param name="conn">Open database connection</param>
    /// <param name="trans">IDbTransaction</param>
		/// <returns>Number of rows inserted.</returns>
		public int Insert(IDbConnection conn, IDbTransaction trans)
		{
      if (HasParms) return Db.ExecuteNonQuery(InsertSql, GetDataParameters(), conn, trans);
      
      return Db.ExecuteNonQuery(InsertSql, conn, trans);
		}
		
		/// <summary>
    /// Execute a delete statement.
    /// </summary>
    /// <returns>Number of rows deleted.</returns>
    public int Delete()
    {
      return Delete(this.Connect);
    }

    /// <summary>
    /// Execute a delete statement.
    /// </summary>
    /// <param name="connect">Database connection string</param>
    /// <returns>Number of rows deleted.</returns>
    public int Delete(string connect)
    {
      if (HasParms) return Db.ExecuteNonQuery(DeleteSql, GetDataParameters(), connect);

      return Db.ExecuteNonQuery(DeleteSql, connect);
    }

    /// <summary>
    /// Execute a delete statement.
    /// </summary>
    /// <param name="conn">Open database connection.</param>
    /// <returns>Number of rows deleted.</returns>
    public int Delete(IDbConnection conn)
    {
      if (HasParms) return Db.ExecuteNonQuery(DeleteSql, GetDataParameters(), conn);

      return Db.ExecuteNonQuery(DeleteSql, conn);
    }

		/// <summary>
		/// Execute a delete statement.
		/// </summary>
		/// <param name="conn">Open database connection.</param>
		/// <param name="trans">Transaction object to support commit and rollback</param>
		/// <returns>Number of rows deleted.</returns>
		public int Delete(IDbConnection conn, IDbTransaction trans)
		{
      if (HasParms) return Db.ExecuteNonQuery(DeleteSql, GetDataParameters(), conn, trans);

			return Db.ExecuteNonQuery(DeleteSql, conn, trans);
		}
		
		/// <summary>
    /// Retrieves value from a datareader and returns the value cast as a string.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as a string.</returns>
    public static string GetString(IDataReader dr, string name)
    {
      return GetString(dr, name, String.Empty);
    }

    /// <summary>
    /// Retrieves value from a datareader and returns the value cast as a string.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value to return if no value found.</param>
    /// <returns>Value of field cast as a string.</returns>
    public static string GetString(IDataReader dr, string name, string defaultvalue)
    {
      int pos = dr.GetOrdinal(name);
      if (pos < 0) return defaultvalue;
      if (dr.IsDBNull(pos))
      {
        return defaultvalue; 
      }
      else 
      {
        return dr.GetValue(pos).ToString();
        //return dr.GetString(pos);
      }
    }

    /// <summary>
    /// Retrieves value from a DataRow and returns the value cast as a string.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as a string.</returns>
    public static string GetString(DataRow dr, string name)
    {
      return GetString(dr, name, String.Empty);
    }

    /// <summary>
    /// Retrieves value from a DataRow and returns the value cast as a string.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value to return if no value found.</param>
    /// <returns>Value of field cast as a string.</returns>
    public static string GetString(DataRow dr, string name, string defaultvalue)
    {
      if (dr.IsNull(name))
      {
        return defaultvalue; 
      }
      else 
      {
        return dr[name].ToString();
      }
    }


    /// <summary>
    /// Retrieves value from a datareader and returns the value cast as an int.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as an int.</returns>
    public static int GetInt(IDataReader dr, string name)
    {
      return GetInt(dr, name, -1);
    }

    /// <summary>
    /// Retrieves value from a datareader and returns the value cast as an int.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value if database field is null.</param>
    /// <returns>Value of field cast as an int.</returns>
    public static int GetInt(IDataReader dr, string name, int defaultvalue)
    {
      int pos = dr.GetOrdinal(name);
      if (pos < 0) return defaultvalue;
      if (dr.IsDBNull(pos)) return defaultvalue; else return dr.GetInt32(pos);
    }

    /// <summary>
    /// Retrieves value from a DataRow and returns the value cast as an int.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as an int.</returns>
    public static int GetInt(DataRow dr, string name)
    {
      return GetInt(dr, name, -1);
    }

    /// <summary>
    /// Retrieves value from a DataRow and returns the value cast as an int.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value if database field is null.</param>
    /// <returns>Value of field cast as an int.</returns>
    public static int GetInt(DataRow dr, string name, int defaultvalue)
    {
      if (dr.IsNull(name)) return defaultvalue; else return System.Convert.ToInt32(dr[name].ToString());
    }


    /// <summary>
    /// Retrieve value from a datareader and returns the value cast as a datetime object.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as a datetime object.</returns>
    public static DateTime GetDate(IDataReader dr, string name)
    {
      return GetDate(dr, name, DateTime.MinValue);
    }

    /// <summary>
    /// Retrieve value from a datareader formatted cast as a date.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value.</param>
    /// <returns>Value of field cast as a datetime object formatted as a date.</returns>
    public static DateTime GetDate(IDataReader dr, string name, DateTime defaultvalue)
    {
      int pos = dr.GetOrdinal(name);
      if (pos < 0) return defaultvalue;
      if (dr.IsDBNull(pos)) return defaultvalue; else return dr.GetDateTime(pos);
    }

    /// <summary>
    /// Retrieve value from a datareader and returns the value cast as a datetime object.
    /// </summary>
    /// <param name="dr">DataRow.</param>
    /// <param name="name">Name of field.</param>
    /// <returns>Value of field cast as a datetime object.</returns>
    public static DateTime GetDate(DataRow dr, string name)
    {
      return GetDate(dr, name, DateTime.MinValue);
    }

    /// <summary>
    /// Retrieve value from a datareader formatted cast as a date.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="defaultvalue">Default value.</param>
    /// <returns>Value of field cast as a datetime object formatted as a date.</returns>
    public static DateTime GetDate(DataRow dr, string name, DateTime defaultvalue)
    {
      if (dr.IsNull(name)) return defaultvalue; else return System.Convert.ToDateTime(dr[name].ToString());
    }

    /// <summary>Retrieve value from a datareader and returns the value as a formatted string.</summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="format">Date format</param>
    /// <returns>Value of field cast as a formatted string.</returns>
    public static string GetStringDate(IDataReader dr, string name, string format)
    {
      return GetStringDate(dr, name, format, DateTime.MinValue);
    }

    /// <summary>
    /// Retrieve value from a datareader formatted cast as a formatted string.
    /// </summary>
    /// <param name="dr">Open datareader object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="format">Date format</param>
    /// <param name="defaultvalue">Default value.</param>
    /// <returns>Value of field cast as a formatted string.</returns>
    public static string GetStringDate(IDataReader dr, string name, string format, DateTime defaultvalue)
    {
      int pos = dr.GetOrdinal(name);
      if (pos < 0) return defaultvalue.ToString(format);
      if (dr.IsDBNull(pos)) return defaultvalue.ToString(format); else return dr.GetDateTime(pos).ToString(format);
    }

    /// <summary>Retrieve value from a DataRow and returns the value as a formatted string.</summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="format">Date format</param>
    /// <returns>Value of field cast as a formatted string.</returns>
    public static string GetStringDate(DataRow dr, string name, string format)
    {
      return GetStringDate(dr, name, format, DateTime.MinValue);
    }

    /// <summary>
    /// Retrieve value from a DataRow formatted cast as a formatted string.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="format">Date format</param>
    /// <param name="defaultvalue">Default value.</param>
    /// <returns>Value of field cast as a formatted string.</returns>
    public static string GetStringDate(DataRow dr, string name, string format, DateTime defaultvalue)
    {
      if (dr.IsNull(name)) return defaultvalue.ToString(format); else return GetDate(dr, name).ToString(format);
    }

    /// <summary>
    /// Retrieve value from a DataRow formatted cast as a formatted string.
    /// </summary>
    /// <param name="dr">DataRow object.</param>
    /// <param name="name">Name of field.</param>
    /// <param name="format">Date format</param>
    /// <param name="defaultValue">Default value.</param>
    /// <returns>Value of field cast as a formatted string.</returns>
    public static string GetStringDate(DataRow dr, string name, string format, string defaultValue)
    {
      if (dr.IsNull(name)) return defaultValue; else return GetDate(dr, name).ToString(format);
    }

     /// <summary>
    /// Format an integer for a sql statement.
    /// </summary>
    /// <param name="i">Int value to format.</param>
    /// <returns>Int value formatted for a sql statement.</returns>
    public static string FormatInt(int i)
    {
      return i.ToString();
    }

    /// <summary>
    /// Format a stingified int for a sql statement.
    /// </summary>
    /// <param name="i">Int value to format.</param>
    /// <returns>Int value formatted for a sql statement.</returns>
    public static string FormatInt(string i)
    {
      if (Util.IsInt(i)) return i; else return String.Empty;
    }

    /// <summary>
    /// Format a string for a sql statement.
    /// </summary>
    /// <param name="s">String to format.</param>
    /// <returns>String value formatted for a sql statement.</returns>
    public static string FormatString(string s)
    {
      if (s.Length == 0)
        return String.Empty;
      else
        return String.Format("'{0}'", s.Replace("'", "''"));
    }

    /// <summary>
    /// Format a datetime object for a sql statement.
    /// </summary>
    /// <param name="dt">DateTime object to format.</param>
    /// <returns>DateTime value formatted for a sql statment.</returns>
    public static string FormatDateTime(DateTime dt)
    {
      return "'" + dt.ToString("dd-MMM-yyyy HH:mm") + "'";
    }

    /// <summary>
    /// Format a stringified date as a date for a sql statement.
    /// </summary>
    /// <param name="s">Stringified date to format.</param>
    /// <returns>Date value formatted for a sql statement.</returns>
    public static string FormatDateTime(string s)
    {
      if (Util.IsDate(s))
      {
        DateTime dt = System.Convert.ToDateTime(s);
        return "'" + dt.ToString("dd-MMM-yyyy HH:mm") + "'";
      }
      else
      {
        return String.Empty;
      }
    }

    /// <summary>
    /// Format a datetime object as a date for a sql statement.
    /// </summary>
    /// <param name="dt">DateTime object to format.</param>
    /// <returns>Date value formatted for a sql statement.</returns>
    public static string FormatDate(DateTime dt)
    {
      return "'" + dt.ToString("dd-MMM-yyyy") + "'";
    }

    /// <summary>
    /// Format a stringified date as a date for a sql statement.
    /// </summary>
    /// <param name="s">Stringified date to format.</param>
    /// <returns>Date value formatted for a sql statement.</returns>
    public static string FormatDate(string s)
    {
      if (Util.IsDate(s))
      {
        DateTime dt = System.Convert.ToDateTime(s);
        return "'" + dt.ToString("dd-MMM-yyyy") + "'";
      }
      else
      {
        return String.Empty;
      }
    }

    /// <summary>
    /// Format a stringified date as a date for a sql statement.
    /// </summary>
    /// <param name="s">Stringified date to format.</param>
    /// <param name="format">The string to format.</param>
    /// <returns>Date value formatted for a sql statement.</returns>
    public static string FormatDate(string s, string format)
    {
      if (Util.IsDate(s))
      {
        DateTime dt = System.Convert.ToDateTime(s);
        return "'" + dt.ToString(format) + "'";
      }
      else
      {
        return String.Empty;
      }
    }

    /// <summary>
    /// Formats a datetime object as a time for a sql statement.
    /// </summary>
    /// <param name="dt">DateTime object.</param>
    /// <returns>Time value formatted for a sql statement.</returns>
    public static string FormatTime(DateTime dt)
    {
      return "'" + dt.ToString("HH:mm") + "'";
    }

    public IDataParameter[] GetDataParameters()
    {
      ArrayList aparms = new ArrayList();

      // add field parameters
      GetDataParameters(aparms, _field);

      // add where parameters
      GetDataParameters(aparms, _where);

      // convert arraylist to IDataParameter[] array
      IDataParameter[] parms = (IDataParameter[]) aparms.ToArray(typeof(IDataParameter));

      return parms;
    }

    public void GetDataParameters(ArrayList parm, Hashtable fieldList)
    {
      IDictionaryEnumerator e = fieldList.GetEnumerator();
      e.Reset();
      while (e.MoveNext())
      {
        string key = e.Key.ToString();
        string value = e.Value.ToString();

        // only add the parm if value exists (otherwise null and handled in sql without a parameter)
        if (value.Length > 0 && _datatype.ContainsKey(key))
        {
          string oracleType = _datatype[key].ToString();
          string parameterName = string.Format(":p{0}", key);
          parm.Add(Db.GetParameter(parameterName, oracleType, ParameterDirection.Input, value));
        }
      }
    }

  }

}
