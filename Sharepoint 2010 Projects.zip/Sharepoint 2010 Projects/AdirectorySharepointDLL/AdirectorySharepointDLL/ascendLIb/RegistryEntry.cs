using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;


namespace Ascend.Lib
{
    public static class RegistryEntry
    {
        /// <summary>
        /// Returns a value from the Registry under the HKEY_LOCAL_MACHINE key
        /// </summary>
        /// <param name="key">The path to the key value (i.e. application acronym "MOS" )</param>
        /// <param name="value">The name of the STRING VALUE under the key (i.e. ConnectString, Mailbox, ServerRole, etc... )</param>
        /// <returns>Returns the DATA VALUE of the given STRING VALUE</returns>
        public static string GetKeyValue(string key, string value)
        {
          return GetKeyValue(key, value, true);
        }

        /// <summary>
        /// Returns a value from the Registry under the HKEY_LOCAL_MACHINE regKey
        /// </summary>
        /// <param name="regKey">The path to the key value (i.e. application acronym "MOS" )</param>
        /// <param name="value">The name of the STRING VALUE under the key (i.e. ConnectString, Mailbox, ServerRole, etc... )</param>
        /// <param name="decrypt">true to decrypt value, false to return values as in the registry</param>
        /// <returns>Returns the DATA VALUE of the given STRING VALUE</returns>
        public static string GetKeyValue(string regKey, string value, bool decrypt)
        {
            return GetKeyValue(regKey, value, decrypt, "PlaceEncryptionKeySaltHere");
        }

        /// <summary>
        /// Returns a value from the Registry under the HKEY_LOCAL_MACHINE regKey
        /// </summary>
        /// <param name="regKey">The path to the key value (i.e. application acronym "MOS" )</param>
        /// <param name="value">The name of the STRING VALUE under the key (i.e. ConnectString, Mailbox, ServerRole, etc... )</param>
        /// <param name="decrypt">true to decrypt value, false to return values as in the registry</param>
        /// <param name="cryptKey">The string value used to decrypt the reg value</param>
        /// <returns>Returns the DATA VALUE of the given STRING VALUE</returns>
        public static string GetKeyValue(string regKey, string value, bool decrypt, string cryptKey)
        {
            return GetKeyValue("Software\\_APM", regKey, value, decrypt, cryptKey);
        }

        /// <summary>
        /// Returns a value from the Registry under the HKEY_LOCAL_MACHINE regKey
        /// </summary>
        /// <param name="hklmSubKey">The path between HKLM and regKey (i.e. application acronym "Software\\_APM"  --> HKLM\Software\_APM\regKey )</param>
        /// <param name="regKey">The path to the key value (i.e. application acronym "MOS" )</param>
        /// <param name="value">The name of the STRING VALUE under the key (i.e. ConnectString, Mailbox, ServerRole, etc... )</param>
        /// <param name="decrypt">true to decrypt value, false to return values as in the registry</param>
        /// <param name="cryptKey">The string value used to decrypt the reg value</param>
        /// <returns>Returns the DATA VALUE of the given STRING VALUE</returns>
        public static string GetKeyValue(string hklmSubKey, string regKey, string value, bool decrypt, string cryptKey)
        {
            RegistryKey registryKey = Registry.LocalMachine;
            RegistryKey registryKeyValueString = registryKey.OpenSubKey(hklmSubKey + "\\" + regKey, false);

            if (registryKeyValueString == null)
            {
                throw new ApplicationException("Unable to find registry entry " + Registry.LocalMachine.Name + "\\" + hklmSubKey + "\\" + regKey);
            }
            else
            {
                try
                {
                    // Return the DATA VALUE of the given STRING VALUE
                    string data = registryKeyValueString.GetValue(value).ToString();
                    if (decrypt) return Util.Decrypt(data, cryptKey); else return data;
                }
                catch (Exception ex)
                {
                    // Return an empty string if any error occurs
                    return string.Empty;
                }
            }
        }
    }
}
