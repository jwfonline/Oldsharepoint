using System;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Ascend.Lib
{
  /// <summary>
  /// This page is used to enable sort functionality on pages
  /// </summary>
  public class AscendPage : System.Web.UI.Page
  {

    /// <summary>
    /// Method.  Sets the elements needed for the order by expression to be used in the SQL query.
    /// </summary>
    /// <param name="sortexpression">sortexpression to sort by (column name)</param>
    /// <param name="sortdirection">sortdirection (asc or desc)</param>
    protected void SetSort(string sortexpression, string sortdirection)
    {
        this.ViewState["sortexpression"] = sortexpression;
        this.ViewState["sortdirection"] = sortdirection;
    }

    /// <summary>
    /// Method.  Puts the orderby string together.
    /// mabonf 3/3/06 added lower() to get the uppercase and lowercase to order appropriately
    /// </summary>
    /// <returns>sort expression to use in the SQL query (eg column_name asc)</returns>
    protected string GetSort()
    {
      string orderby = this.ViewState["sortexpression"].ToString() + " " + this.ViewState["sortdirection"].ToString();
      return orderby;
    }

    /// <summary>
    /// Method.  Alternates the "asc" and "desc" (sortdirection) if you click on the same 
    /// column (sortexpression) but resets it to asc if the column has changed.
    /// </summary>
    /// <param name="source">contains info about the source object</param>
    /// <param name="e">contains information about the column that is to be sorted</param>
    protected void SetSortProperties(object source, DataGridSortCommandEventArgs e)
    {
      string old = this.ViewState["sortexpression"].ToString();
      if (old == e.SortExpression)
      {
        if (this.ViewState["sortdirection"].ToString() == "asc")
        {
          this.ViewState["sortdirection"] = "desc";
        }
        else
        {
          this.ViewState["sortdirection"] = "asc";
        }
      }
      else
      {
        this.ViewState["sortexpression"] =  e.SortExpression;
        this.ViewState["sortdirection"] = "asc";
      }
    }

		/// <summary>
		/// Method.  Alternates the "asc" and "desc" (sortdirection) if you click on the same 
		/// column (sortexpression) but resets it to asc if the column has changed.
		/// </summary>
		/// <param name="source">contains info about the source object</param>
		/// <param name="e">contains information about the column that is to be sorted</param>
		protected void SetSortProperties(object source, GridViewSortEventArgs e)
		{
			string old = this.ViewState["sortexpression"].ToString();
			if (old == e.SortExpression)
			{
				if (this.ViewState["sortdirection"].ToString() == "asc")
				{
					this.ViewState["sortdirection"] = "desc";
				}
				else
				{
					this.ViewState["sortdirection"] = "asc";
				}
			}
			else
			{
				this.ViewState["sortexpression"] = e.SortExpression;
				this.ViewState["sortdirection"] = "asc";
			}
		}

    public string GetLabelText(string id)
    {
      try
      {
        System.Web.UI.WebControls.Label lbl = (System.Web.UI.WebControls.Label) this.FindControl(id);
        return lbl.Text;
      }
      catch
      {
        return String.Empty;
      }
    }

  }
}
