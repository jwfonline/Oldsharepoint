using System.Data;

namespace Ascend.Lib
{
	/// <remarks>
	/// Class. Utility business object methods and properties.
	/// NOTE: All database table business objects goes through this class.
	/// This class contains static methods to handle updates, inserts, and deletes
	/// </remarks>
	public class BoSql : Bo
	{


    /// <summary>
    /// Execute update or insert statement based on AddMode.
    /// </summary>
    /// <param name="connect">Database connection string.</param>
    /// <returns>Number of rows affected.</returns>
    public new int Update(string connect)
    {
      if (AddMode)
        return DbSql.ExecuteNonQuery(InsertSql, connect);
      else
        return DbSql.ExecuteNonQuery(UpdateSql, connect);
    }

    /// <summary>
    /// Execute update or insert statement based on AddMode.
    /// </summary>
    /// <param name="conn">Open database connection.</param>
    /// <returns>Number of rows affected.</returns>
    public new int Update(IDbConnection conn)
    {
      if (AddMode)
        return DbSql.ExecuteNonQuery(InsertSql, conn);
      else
         return DbSql.ExecuteNonQuery(UpdateSql, conn);
    }

    /// <summary>
    /// Execute an insert statement.
    /// </summary>
    /// <returns>Number of rows inserted.</returns>
    public new int Insert()
    {
      return Insert(Connect);
    }
    
    
    /// <summary>
    /// Execute an insert statment.
    /// </summary>
    /// <param name="connect">Database connection string.</param>
    /// <returns>Number of rows inserted.</returns>
    public new int Insert(string connect)
    {
      return DbSql.ExecuteNonQuery(InsertSql, connect);
    }

    /// <summary>
    /// Execute an insert statement.
    /// </summary>
    /// <param name="conn">Open database connection</param>
    /// <returns>Number of rows inserted.</returns>
    public new int Insert(IDbConnection conn)
    {
      return DbSql.ExecuteNonQuery(InsertSql, conn);
    }

    /// <summary>
    /// Execute an insert statement.
    /// </summary>
    /// <param name="conn">Open database connection</param>
    /// <param name="trans">IDbTransaction</param>
    /// <returns>Number of rows inserted.</returns>
    public new int Insert(IDbConnection conn, IDbTransaction trans)
    {
      return DbSql.ExecuteNonQuery(InsertSql, conn, trans);
    }

    /// <summary>
    /// Execute a delete statement.
    /// </summary>
    /// <param name="connect">Database connection string</param>
    /// <returns>Number of rows deleted.</returns>
    public new int Delete(string connect)
    {
      return DbSql.ExecuteNonQuery(DeleteSql, connect);
    }

    /// <summary>
    /// Execute a delete statement.
    /// </summary>
    /// <param name="conn">Open database connection.</param>
    /// <returns>Number of rows deleted.</returns>
    public new int Delete(IDbConnection conn)
    {
      return DbSql.ExecuteNonQuery(DeleteSql, conn);
    }

 
  }

}
