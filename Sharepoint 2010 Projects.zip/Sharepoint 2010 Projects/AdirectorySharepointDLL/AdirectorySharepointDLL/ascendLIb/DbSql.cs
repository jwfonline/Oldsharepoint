using System;
using System.Data;
using System.Data.SqlClient;

namespace Ascend.Lib
{
	/// <remarks>
	/// Class. Utility database methods and properties.
	/// NOTE: All database access goes through this class.
	/// This class contains static methods to handle connections, data readers, etc.
	/// This class, when inherited, also contains properties and methods to update/insert records.
	/// </remarks>
	public class DbSql
	{

		/// <summary>
		/// Open a connection to the database.
		/// </summary>
		/// <param name="connect">Database connection string.</param>
		/// <returns>Open database connection object.</returns>
		public static IDbConnection OpenConnection(string connect)
		{
			// open a connection
			IDbConnection conn = new SqlConnection(connect);
			conn.Open();
			return conn;
		}

		/// <summary>
		/// Static method. Returns OracleCommand object cast as an IDbCommand object.
		/// </summary>
		/// <param name="sql">Sql statement.</param>
		/// <param name="conn">Connection object.</param>
		/// <returns>IDbCommand object.</returns>
		public static IDbCommand GetCommand(string sql, IDbConnection conn)
		{
			SqlConnection sqlConn = (SqlConnection)conn;
			IDbCommand cmd = new SqlCommand(sql, sqlConn);
			return cmd;
		}

		/// <summary>
		/// Static method. Returns OracleCommand object cast as an IDbCommand object.
		/// </summary>
		/// <param name="conn">Connection object.</param>
		/// <returns>IDbCommand object.</returns>
		public static IDbCommand GetCommand(IDbConnection conn)
		{
			SqlConnection sqlConn = (SqlConnection)conn;
			IDbCommand cmd = sqlConn.CreateCommand();
			return cmd;
		}

		/// <summary>
		/// Static method. Returns OracleDataAdapter object 
		/// </summary>
		/// <param name="sql">Sql statement.</param>
		/// <param name="conn">Connection object.</param>
		/// <returns>OracleDataAdapter object.</returns>
		public static SqlDataAdapter GetDataAdapter(string sql, IDbConnection conn)
		{
			SqlConnection sqlConn = (SqlConnection)conn;
			SqlDataAdapter da = new SqlDataAdapter(sql, sqlConn);
			return da;
		}

		/// <summary>
		/// Close a database connection.
		/// </summary>
		/// <param name="conn">Open database connection.</param>
		public static void CloseConnection(IDbConnection conn)
		{
			conn.Close();
		}

		/// <summary>
		/// Get a datareader object for a specified sql expression.
		/// Opens a database connection and specifies a CommandBehavior to CloseConnection when
		/// the datareader is closed.
		/// </summary>
		/// <param name="sql">Sql select statement.</param>
		/// <param name="connect">Database connection string.</param>
		/// <returns>Open IDataReader with results of sql select statement.</returns>
		public static IDataReader GetDataReader(string sql, string connect)
		{
			// open a connection
			IDbConnection conn = OpenConnection(connect);

			// create sql command object
			IDbCommand cmd = GetCommand(sql, conn);

			// create data reader that will automatically close connection when datareader is closed
			IDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

			// dispose of command object
			cmd.Dispose();

			return dr;
		}

		// generic function that returns a DataTable object for a specified sql expression
		/// <summary>
		/// Get a disconnected DataTable object for a specified select statement. 
		/// </summary>
		/// <param name="sql">Sql select statement.</param>
		/// <param name="conn">Open database connection object.</param>
		/// <returns>Returns DataTable object for sql select statement.</returns>
		public static DataTable GetDataTable(string sql, IDbConnection conn)
		{
			// create sql data adapter
			SqlDataAdapter da = new SqlDataAdapter(sql, (SqlConnection)conn);

			// create DataTable object
			DataTable dt = new DataTable();

			// fill datatable with data
			//dt.BeginLoadData();
			da.Fill(dt);
			//dt.EndLoadData();

			// dispose of DataAdapter
			da.Dispose();

			return dt;
		}

		/// <summary>
		/// Get a datatable object for a specified sql expression.
		/// </summary>
		/// <param name="sql">Sql select statement.</param>
		/// <param name="connect">Database connection string.</param>
		/// <returns>DataTable with results of sql select statement.</returns>
		public static DataTable GetDataTable(string sql, string connect)
		{
			// create sql data adapter
			SqlDataAdapter da = new SqlDataAdapter(sql, connect);

			// create DataTable object
			DataTable dt = new DataTable();

			// fill datatable with data
			//dt.BeginLoadData();
			da.Fill(dt);
			//dt.EndLoadData();

			// dispose of all resources
			da.Dispose();

			return dt;

		}

		// generic function that returns a datareader object for a specified sql expression
		/// <summary>
		/// Get an open datareader object for a specified select statement. 
		/// </summary>
		/// <param name="sql">Sql select statement.</param>
		/// <param name="conn">Open database connection object.</param>
		/// <returns>Returns IDataReader object for sql select statement.</returns>
		public static IDataReader GetDataReader(string sql, IDbConnection conn)
		{
			// create sql command object
			IDbCommand cmd = GetCommand(sql, conn);

			// create data reader that does not close connection
			IDataReader dr = cmd.ExecuteReader();

			// dispose of command object
			cmd.Dispose();

			return dr;
		}


		/// <summary>
		/// Executes the query, and returns the first column of the first row in the resultset returned by the query. Extra columns or rows are ignored.
		/// </summary>
		/// <param name="sql">Sql select statement.</param>
		/// <param name="connect">Database connection string.</param>
		/// <returns>Object holding first column of first row.</returns>
		public static object ExecuteScalar(string sql, string connect)
		{

			// open a connection
			IDbConnection conn = OpenConnection(connect);

			// create command object
			IDbCommand cmd = GetCommand(sql, conn);

			// execute scalar method on command object
			object obj = cmd.ExecuteScalar();

			// close command object and connection
			cmd.Dispose();
			CloseConnection(conn);

			// return object
			return obj;
		}

		/// <summary>
		/// Executes the query, and returns the first column of the first row in the resultset returned by the query. Extra columns or rows are ignored. 
		/// </summary>
		/// <param name="sql">Sql select statment.</param>
		/// <param name="conn">Open database connection.</param>
		/// <returns>Object holding first column of first row.</returns>
		public static object ExecuteScalar(string sql, IDbConnection conn)
		{
			// create command object
			IDbCommand cmd = GetCommand(sql, conn);

			// execute scalar method on command object
			object obj = cmd.ExecuteScalar();

			// close command object and connection
			cmd.Dispose();

			// return object
			return obj;
		}

		/// <summary>
		/// Executes a DML sql statement and returns number of rows affected.
		/// </summary>
		/// <param name="sql">DML sql statement.</param>
		/// <param name="connect">Database connection string.</param>
		/// <returns>Number of rows affected.</returns>
		public static int ExecuteNonQuery(string sql, string connect)
		{
			// open a connection
			IDbConnection conn = OpenConnection(connect);

			// open command object and set type
			IDbCommand cmd = GetCommand(sql, conn);
			cmd.CommandType = CommandType.Text;

			// execute nonquery command 
			int i = cmd.ExecuteNonQuery();

			// close command and connection objects
			cmd.Dispose();
			CloseConnection(conn);

			// return number of rows affected
			return i;
		}

		/// <summary>
		/// Executes a DML sql statement and returns number of rows affected.
		/// </summary>
		/// <param name="sql">DML sql statement.</param>
		/// <param name="conn">Open database connection object.</param>
		/// <returns>Number of rows affected.</returns>
		public static int ExecuteNonQuery(string sql, IDbConnection conn)
		{

			// open command object and set type
			IDbCommand cmd = GetCommand(sql, conn);
			cmd.CommandType = CommandType.Text;

			// execute nonquery command 
			int i = cmd.ExecuteNonQuery();

			// close command 
			cmd.Dispose();

			// return number of rows affected
			return i;
		}

    /// <summary>
    /// Executes a DML sql statement and returns number of rows affected.
    /// </summary>
    /// <param name="sql">DML sql statement.</param>
    /// <param name="conn">Open database connection object.</param>
    /// <param name="trans">Transaction object to support commits and rollbacks</param>
    /// <returns>Number of rows affected.</returns>
    public static int ExecuteNonQuery(string sql, IDbConnection conn, IDbTransaction trans) //NOT TESTED FOR SQL
    {

      // open command object and set type
      IDbCommand cmd = GetCommand(sql, conn);
      cmd.Transaction = trans;
      cmd.CommandType = CommandType.Text;

      // execute nonquery command 
      int i = cmd.ExecuteNonQuery();

      // close command 
      cmd.Dispose();

      // return number of rows affected
      return i;
    }

		public static IDataParameter GetParameter(string parameterName, DbType dbType, ParameterDirection direction, string value)
		{
			SqlParameter parm = new SqlParameter();
			parm.ParameterName = parameterName;
			parm.DbType = dbType;
			parm.Direction = direction;
			parm.Value = value;
      return (IDataParameter)parm; //This is perhaps a redundant cast. Not changing it though. paul
		}

		public static string ExecuteProcedure(string procedureName, IDataParameter[] parameters, string connect)
		{
			// open a connection
			IDbConnection conn = OpenConnection(connect);

			string error = ExecuteProcedure(procedureName, parameters, conn);

			CloseConnection(conn);

			return error;

		}

		public static string ExecuteProcedure(string procedureName, IDataParameter[] parameters, IDbConnection conn)
		{
			// open command object and set type
			IDbCommand cmd = GetCommand(conn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandText = procedureName;

			// add parameters
			foreach (IDataParameter parm in parameters)
			{
				cmd.Parameters.Add(parm);
			}

			string error = string.Empty;
			try
			{
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				error = ex.Message;
			}
			return error;
		}

		public static string ExecuteProcedure(string procedureName, string connect)
		{
			// open a connection
			IDbConnection conn = OpenConnection(connect);

			string error = ExecuteProcedure(procedureName, conn);

			CloseConnection(conn);

			return error;

		}

		public static string ExecuteProcedure(string procedureName, IDbConnection conn)
		{
			// open command object and set type
			IDbCommand cmd = GetCommand(conn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandText = procedureName;

			string error = string.Empty;
			try
			{
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				error = ex.Message;
			}
			return error;
		}


	}

}
