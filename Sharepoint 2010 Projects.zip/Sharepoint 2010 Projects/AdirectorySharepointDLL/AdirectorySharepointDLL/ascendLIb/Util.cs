using System;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Ascend.Lib
{
  /// <remarks>
  /// Class. Helpful utility methods used throughout an application
  /// </remarks>
  public class Util
  {

    /// <summary>
    /// Removes all single quotes from a string.
    /// </summary>
    /// <param name="aString">String to modify.</param>
    /// <returns>Returns <paramref>aString</paramref> with all single quotes removed.</returns>
    public static string RemoveTicks(string aString)
    {
      return aString.Replace("'",String.Empty);
    }

    /// <summary>
    /// Replaces carriage return/line spaces with a space.
    /// </summary>
    /// <param name="text">text string to modify.</param>
    /// <returns>Returns string with all cr/lf pairs replaced with spaces.</returns>
    public static string ReplaceCrLf(string text)
    {
      text = text.Replace("\r\n", " ");
      text = text.Replace("\r", " ");
      text = text.Replace("\n", " ");
      text = text.Replace("\t", " ");
      text = text.Replace("   ", " ");
      text = text.Replace("  ", " ");
      return text;
    }

    /// <summary>
    /// Replaces carriage return/line spaces with a break.
    /// </summary>
    /// <param name="text">text string to modify.</param>
    /// <returns>Returns string with all cr/lf pairs replaced with spaces.</returns>
    public static string ReplaceCrLfBr(string text)
    {
      text = text.Replace("\r\n", "<br>");
      text = text.Replace("\r", "<br>");
      text = text.Replace("\n", "<br>");
      return text;
    }

    /// <summary>
    /// Replaces all single ticks with two single ticks.
    /// </summary>
    /// <example>Joe's returns as Joe''s</example>
    /// <param name="aString">String to modify</param>
    /// <returns>Returns <paramref>aString</paramref> with single quotes replaced with 2 single quotes</returns>
    public static string FixTicks(string aString)
    {
      return aString.Replace("'","''");
    }

    /// <summary>
    /// Static Method. Returns path with trailing slashes removed.
    /// </summary>
    /// <param name="path">Path to analyze.</param>
    /// <returns>String. Path without any trailing slashes.</returns>
    public static string RemoveTrailingSlash(string path)
    {
      // check for forward slash. Remove it if found.
      if (path.EndsWith("/")) return path.Substring(0, path.Length - 1);

      // check for backward slash. Remove it if found.
      if (path.EndsWith("\\")) return path.Substring(0, path.Length - 1);

      // otherwise return initial value
      return path;
    }

    /// <summary>
    /// Static Method. Returns username without domain (i.e. soi\sgiwel)
    /// </summary>
    /// <param name="userId">User Id to analyze.</param>
    /// <returns>String. Returns userid without domain prefix.</returns>
    public static string RemoveDomain(string userId)
    {
      // check for forward slash. Remove it if found.
      if (userId.IndexOf("\\") > 0) return userId.Substring(userId.IndexOf("\\") + 1);

      // otherwise return initial value
      return userId;
    }

    /// <summary>
    /// Tests if string is a valid number.
    /// </summary>
    /// <param name="strNumber">String to examine.</param>
    /// <returns>Returns true if a number, false if not.</returns>
    public static bool IsNumber(String strNumber)
    {
      //paul s. recommends.  Needs testing though
      //double booleanval;
      //return double.TryParse(strNumber,out booleanval);

      try
      {
        double dbl = System.Convert.ToDouble(strNumber); //this is assigned but never used. paul
        return true;
      }
      catch
      {
        return false;
      }
    }  

    /// <summary>
    /// Test if string is a natural number.
    /// </summary>
    /// <param name="strNumber">String to examine.</param>
    /// <returns>Return true if a natural number, fales if not.</returns>
    public static bool IsNaturalNumber(string strNumber)
    {
      Regex objNotNaturalPattern=new Regex("[^0-9]");
      Regex objNaturalPattern=new Regex("0*[1-9][0-9]*");
      return  !objNotNaturalPattern.IsMatch(strNumber) && objNaturalPattern.IsMatch(strNumber);
    }  

    /// <summary>
    /// Static method. Returns boolean if string can be converted to a date.
    /// </summary>
    /// <param name="s">string to test.</param>
    /// <returns>True if valid date, false if not a valid date.</returns>
    public static bool IsDate(string s)
    {
      try
      {
        CultureInfo culture = new CultureInfo(String.Empty);
        DateTime dt = DateTime.Parse(s, culture);
        return true;
      }
      catch
      {
        return false;
      }
    }

    /// <summary>
    /// Static method. Returns boolean if string can be converted to a date using specified date format.
    /// </summary>
    /// <param name="s">string to test.</param>
    /// <param name="format">date format.</param>
    /// <returns>True if valid date, false if not a valid date.</returns>
    public static bool IsDate(string s, string format)
    {
      try
      {
        DateTime dt = DateTime.ParseExact(s, format, null);
        return true;
      }
      catch
      {
        return false;
      }
    }

    /// <summary>
    /// Static method. Returns boolean if string can be converted to an int.
    /// </summary>
    /// <param name="s">string to test.</param>
    /// <returns>True if valid int, false if not a valid int.</returns>
    public static bool IsInt(string s)
    {
      try
      {
        int i = System.Convert.ToInt32(s);
        return true;
      }
      catch
      {
        return false;
      }
    }

    /// <summary>
    /// Get the ascii value of a character.
    /// </summary>
    /// <param name="c">Character to get ascii value.</param>
    /// <returns>Returns ascii value of the character.</returns>
    public static byte Asc(char c)
    {
      Byte[] myBytes = System.Text.Encoding.ASCII.GetBytes(c.ToString());
      Byte asciiCode = myBytes[0];
      return asciiCode;
    }

    /// <summary>
    /// Gets the character represented by an ascii code.
    /// </summary>
    /// <param name="i">Ascii value to examine.</param>
    /// <returns>Returns character represented by the ascii value.</returns>
    public static string Chr(byte i)
    {
      Byte[] myBytes2 = {i};
      string myStr = System.Text.Encoding.ASCII.GetString(myBytes2);
      return myStr;
    }

    /// <summary>
    /// Get Request.Form variable for a specified key.
    /// </summary>
    /// <param name="key">key to search for</param>
    /// <returns>Returns string value for specified key. Returns empty string if not found.</returns>
    public static string GetRequestForm(string key)
    {
      if (HttpContext.Current.Request.Form[key] == null)
        return String.Empty;
      else
        return HttpContext.Current.Request.Form[key].ToString();
    }

    /// <summary>
    /// Get Request.QueryString variable for a specified key.
    /// </summary>
    /// <param name="key">key to search for</param>
    /// <returns>Returns string value for specified key. Returns empty string if not found.</returns>
    public static string GetRequestQueryString(string key)
    {
      if (HttpContext.Current.Request.QueryString[key] == null)
        return String.Empty;
      else
        return HttpContext.Current.Request.QueryString[key].ToString();
    }

    /// <summary>
    /// Get Request.QueryString or Request.Form variable for a specified key.
    /// Searches Request.QueryString collection first.
    /// </summary>
    /// <param name="key">key to search for</param>
    /// <returns>Returns string value for specified key. Returns empty string if not found.</returns>
    public static string GetRequestString(string key)
    {
      if (HttpContext.Current.Request.QueryString[key] == null)
        if (HttpContext.Current.Request.Form[key] == null)
          return String.Empty;
        else
          return HttpContext.Current.Request.Form[key].ToString();
      else
        return HttpContext.Current.Request.QueryString[key].ToString();
    }

    /// <summary>
    /// Retrieves a Request value from Form or QueryString collection and converts to an int.
    /// If unable to find value or convert to an int, returns 0.
    /// </summary>
    /// <param name="key">Key name to search for in Request collections.</param>
    /// <returns>Key value converted to an int.</returns>
    public static int GetRequestInt(string key)
    {
      return GetRequestInt(key, 0);
    }

    /// <summary>
    /// Retrieves a Request value from Form or QueryString collection and converts to an int.
    /// If unable to find value or convert to an int, returns the specified default value.
    /// </summary>
    /// <param name="key">Key name to search for in Request collections.</param>
    /// <param name="defaultvalue">Default value to return if unable to find or convert to an int.</param>
    /// <returns>Key value converted to an int.</returns>
    public static int GetRequestInt(string key, int defaultvalue)
    {
      string keyvalue;
      if (HttpContext.Current.Request.QueryString[key] == null)
      {
        if (HttpContext.Current.Request.Form[key] == null)
        {
          return defaultvalue;
        }
        else
        {
          keyvalue = HttpContext.Current.Request.Form[key].ToString();
          if (IsNumber(keyvalue)) 
            return System.Convert.ToInt32(keyvalue); 
          else 
            return defaultvalue;
        }
      }
      else
      {  
        keyvalue = HttpContext.Current.Request.QueryString[key].ToString();
        if (IsNumber(keyvalue)) 
          return System.Convert.ToInt32(keyvalue); 
        else return defaultvalue;
      }
    }

    /// <summary>
    /// Static method. Formats a stringified date using site display date format.
    /// </summary>
    /// <param name="s">String to format.</param>
    /// <param name="displayFormat">String with date format</param>
    /// <returns>Returns a string formatted using site display date format.</returns>
    public static string FormatDisplayDate(string s, string displayFormat)
    {
      if (s.Length == 0) return String.Empty; 
      else if (Util.IsDate(s)) return FormatDisplayDate(System.Convert.ToDateTime(s), displayFormat);
      else return String.Empty;
    }

    /// <summary>
    /// Static method. Formats a date using site display date format.
    /// </summary>
    /// <param name="dt">Date to format.</param>
    /// <param name="displayFormat">String with date format</param>
    /// <returns>Returns a string formatted using specified date format.</returns>
    public static string FormatDisplayDate(DateTime dt, string displayFormat)
    {
      return dt.ToString(displayFormat);
    }

    /// <summary>
    /// Static method. Returns boolean if string can be converted to a date using specified date format.
    /// </summary>
    /// <param name="s">string to convert to date.</param>
    /// <param name="format">date format.</param>
    /// <returns>True if valid date, false if not a valid date.</returns>
    public static DateTime ToDate(string s, string format)
    {
      try
      {
        DateTime dt = DateTime.ParseExact(s, format, null);
        return dt;
      }
      catch
      {
        return DateTime.MinValue;
      }
    }



    /// <summary>
    /// Static Method. Replaces a value within a string with another value.
    /// </summary>
    /// <param name="original">Original string to be modified.</param>
    /// <param name="value">String to insert into original string.</param>
    /// <param name="start">Starting position of the insertion.</param>
    /// <param name="length">Number of characters to remove from string.</param>
    /// <returns>String with new value inserted into original string.</returns>
    public static string Replace(string original, string value, int start, int length)
    {
      // first make sure original string has proper size
      string s = original.PadRight(start + length);

      // next remove old value from string.
      s = s.Remove(start, length);

      // insert new value (padding if necessary)
      return s.Insert(start, value.PadRight(length));
    }

    /// <summary>
    /// Public static method to read contents of a file.
    /// </summary>
    /// <param name="path">Path of file whose contents to read.</param>
    /// <returns>String with complete contents of file.</returns>
    public static string ReadContents(string path)
    {
      return ReadContents(path, System.Text.Encoding.UTF8);
    }

    /// <summary>
    /// Public static method to read contents of a file.
    /// </summary>
    /// <param name="path">Path of file whose contents to read.</param>
    /// <param name="encoding">Type of encoding for the file</param>
    /// <returns>String with complete contents of file.</returns>
    public static string ReadContents(string path, System.Text.Encoding encoding)
    {
      if (File.Exists(path))
      {
        //StreamReader sr = File.OpenText(path);
        StreamReader sr = new StreamReader(path, encoding);
        string contents = sr.ReadToEnd();
        sr.Close();
        return contents;
      }
      else
      {
        return String.Empty;
      }
    }

    /// <summary>
    /// Static Method. Returns ID of a control as it appears on the transformed
    /// html page.
    /// </summary>
    /// <param name="control">Control to determine Html ID.</param>
    /// <returns>ID of control that appears on HTML page.</returns>
    public static string GetHtmlId(System.Web.UI.Control control)
    {
      return GetHtmlId(control, true);
    }

    /// <summary>
    /// Static Method. Returns ID of a control as it appears on the transformed
    /// html page.
    /// </summary>
    /// <param name="control">Control to determine Html ID.</param>
    /// <param name="appendForm">Boolean to append FormName to ID.</param>
    /// <returns>ID of control that appears on HTML page.</returns>
    public static string GetHtmlId(System.Web.UI.Control control, bool appendForm)
    {
      // initialize id to control.id
      System.Text.StringBuilder id = new System.Text.StringBuilder(control.ID, 75);

      // get parent of control and its type.
      System.Web.UI.Control cntrl = control.Parent;
      string type = cntrl.GetType().ToString();

      // do recursive loop and keep adding parent Ids until we reach the Form leve.
      while (type != "System.Web.UI.HtmlControls.HtmlForm")
      {
        // add id to beginning of string if not a panel
        if (type != "System.Web.UI.WebControls.Panel")
        {
          id.Insert(0, "_");
          id.Insert(0, cntrl.ID);
        }

        // get parent and its type
        cntrl = cntrl.Parent;
        type = cntrl.GetType().ToString();

        // append form name if appendForm = true.
        if (appendForm && type == "System.Web.UI.HtmlControls.HtmlForm")
        {
          id.Insert(0, ".");
          id.Insert(0, cntrl.ID);
        }
      }
      return id.ToString();
    }

    /// <summary>
    /// Get a literal object containing html text.
    /// Usage=Used to dynamically add literal HTML code to a asp:placeholder control.
    /// </summary>
    /// <param name="literalValue">HTML code to add to the Literal object</param>
    /// <returns>
    /// Returns a System.Web.UI.WebControls.Literal object
    /// whose Text property contains the <paramref>literalValue</paramref>.
    /// </returns>
    public static Literal GetLiteral(string literalValue)
    {
      Literal l = new Literal();
      l.Text = literalValue;
      return l;
    }

    /// <summary>
    /// Computes an encrypted hash value for a given string.
    /// </summary>
    /// <param name="hashme">String to encrypt.</param>
    /// <returns>Encrypted string using SHA1 encryption.</returns>
    public static string ComputeHash(string hashme)
    {
      byte[] before = System.Text.Encoding.UTF8.GetBytes(hashme);
      byte[] after = new SHA1CryptoServiceProvider().ComputeHash(before);
      return Convert.ToBase64String(after);
    }

    /// <summary>
    /// Static Method. Sets the selected item for a DropDownList server control.
    /// </summary>
    /// <param name="ddl">Reference to the DropDownList.</param>
    /// <param name="value">Value to Find</param>
    public static void SetDropDownList(System.Web.UI.WebControls.DropDownList ddl, string value)
    {
      ListItem li = ddl.Items.FindByValue(value);
      if (li != null) li.Selected = true;
    }

    /// <summary>
    /// Method. Exports data in a DataTable as text
    /// </summary>
    /// <param name="dt">DataTable containing data to export.</param>
    /// <param name="addHeaderRow">Boolean to add header row to output.</param>
    /// <param name="separator">Field separator</param>
    /// <returns>String containing output</returns>
    public static string ExportDataTableAsText(DataTable dt, bool addHeaderRow, string separator)
    {
      StringBuilder sb = new StringBuilder();
      string[] values = {};

      // output each of the columns
      if (addHeaderRow)
      {
        foreach (DataColumn c in dt.Columns)
        {
          sb.Append(c.ColumnName + separator);
        }
        sb.Append("\r\n");
      }

      // output each of the rows
      foreach (DataRow r in dt.Rows)
      {
        foreach (DataColumn c in dt.Columns)
        {
          sb.Append(r[c].ToString() + separator); //redundant toString(). paul
        }
        sb.Append("\r\n");
      }

      return sb.ToString();
    }

    public static string GetControlHtml(System.Web.UI.WebControls.WebControl wc)
    {
      string html = String.Empty;

      StringWriter stringWriter = new StringWriter();
      HtmlTextWriter htmlWriter = new HtmlTextWriter(stringWriter);
   
      try
      {
        wc.RenderControl(htmlWriter);
        html = stringWriter.ToString();
      }
      finally
      {
        htmlWriter.Close();
        stringWriter.Close();
      }
      return html;
    }

    public static string GetControlHtml(System.Web.UI.HtmlControls.HtmlControl wc)
    {
      string html = String.Empty;

      StringWriter stringWriter = new StringWriter();
      HtmlTextWriter htmlWriter = new HtmlTextWriter(stringWriter);
   
      try
      {
        wc.RenderControl(htmlWriter);
        html = stringWriter.ToString();
      }
      finally
      {
        htmlWriter.Close();
        stringWriter.Close();
      }
      return html;
    }

    /// <summary>
    /// Static Method. Returns a value from Web.Config
    /// </summary>
    /// <param name="key"></param>
    /// <returns></returns>
    public static string GetConfig(string key)
    {
      //if (ConfigurationManager.AppSettings[key] != null)
      //{
      //          return ConfigurationManager.AppSettings[key].ToString();
      //}
      //else
      //{
        return String.Empty;
      //}

    }

    /// <summary>
    /// Static Method. Writes text to a file.
    /// </summary>
    /// <param name="path"></param>
    /// <param name="text"></param>
    public static void WriteContents(string path, string text)
    {
      StreamWriter sw = File.CreateText(path);
      sw.Write(text);
      sw.Close();
    }

    /// <summary>
    /// Static Method. Writes buffer to a file.
    /// </summary>
    /// <param name="path">Name of file to write buffer to.</param>
    /// <param name="buffer">Buffer holding contents.</param>
    public static void WriteContents(string path, ref byte[] buffer)
    {
      // Create a file
      FileStream fs = new FileStream(path, FileMode.Create);

      // Write data to the file
      fs.Write(buffer, 0, buffer.Length);

      // Close file
      fs.Close();
    }

    public static string ConvertFromZHCN(string source)
    {
      Encoding enc1252 = Encoding.GetEncoding(1252);
      Encoding encGBK = Encoding.GetEncoding(936);
      Encoding encUTF16 = Encoding.Unicode;
      Byte[] byteGBK;
      Byte[] byteUTF16;
      string utf16;
      byteGBK = encGBK.GetBytes(source);
      byteUTF16 = Encoding.Convert(enc1252, encUTF16, byteGBK);
      utf16 = encUTF16.GetString(byteUTF16);
      return utf16;
    }

    public static string ConvertToZHCN(string source)
    {
      Encoding enc1252 = Encoding.GetEncoding(1252);
      Encoding encGBK = Encoding.GetEncoding(936);
      Encoding encUTF16 = Encoding.Unicode;
      Byte[] byteGBK;
      Byte[] byteUTF16;
      string utf16;
      byteGBK = enc1252.GetBytes(source);
      byteUTF16 = Encoding.Convert(encGBK, encUTF16, byteGBK);
      utf16 = encUTF16.GetString(byteUTF16);
      return utf16;
    }

    public static string ConvertFromCyrllic(string source)
    {
      Encoding enc1252 = Encoding.GetEncoding(1252);
      Encoding encCyrllic = Encoding.GetEncoding(1251);
      Encoding encUTF16 = Encoding.Unicode;
      Byte[] byteCyrllic;
      Byte[] byteUTF16;
      string utf16;
      byteCyrllic = encCyrllic.GetBytes(source);
      byteUTF16 = Encoding.Convert(enc1252, encUTF16, byteCyrllic);
      utf16 = encUTF16.GetString(byteUTF16);
      return utf16;
    }

    public static string ConvertToCyrllic(string source)
    {
      Encoding enc1252 = Encoding.GetEncoding(1252);
      Encoding encCyrllic = Encoding.GetEncoding(1251);
      Encoding encUTF16 = Encoding.Unicode;
      Byte[] byteCyrllic;
      Byte[] byteUTF16;
      string utf16;
      byteCyrllic = enc1252.GetBytes(source);
      byteUTF16 = Encoding.Convert(encCyrllic, encUTF16, byteCyrllic);
      utf16 = encUTF16.GetString(byteUTF16);
      return utf16;
    }

		// The Initialization Vector for the DES encryption routine
		private static readonly byte[] IV = new byte[8] { 240, 3, 45, 29, 0, 76, 173, 59 };

        /// <summary>
        /// Encrypts a string using a default key
        /// </summary>
        /// <param name="data">string to be encrypted</param>
        /// <returns></returns>
        public static string Encrypt(string data)
        {
            return Encrypt(data, "PlaceEncryptionKeySaltHere");
        }

        /// <summary>
		/// Encrypts a string using the key
		/// </summary>
		public static string Encrypt(string data, string key)
		{
			byte[] buffer = Encoding.ASCII.GetBytes(data);
			TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
			MD5CryptoServiceProvider MD5 = new MD5CryptoServiceProvider();
			des.Key = MD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(key));
			des.IV = IV;
			return Convert.ToBase64String(
				des.CreateEncryptor().TransformFinalBlock(
					buffer,
					0,
					buffer.Length
				)
			);
		}

        /// <summary>
        /// Decrypts a string using a default key.
        /// </summary>
        /// <param name="data">string to be decrypted</param>
        /// <returns></returns>
        public static string Decrypt(string data)
        {
            return Decrypt(data, "PlaceEncryptionKeySaltHere");
        }

		/// <summary>
		/// Decrypts a string using the key
		/// </summary>
		public static string Decrypt(string data, string key)
		{
			try
			{
				byte[] buffer = Convert.FromBase64String(data);
				TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
				MD5CryptoServiceProvider MD5 = new MD5CryptoServiceProvider();
				des.Key = MD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(key));
				des.IV = IV;
				return Encoding.ASCII.GetString(
					des.CreateDecryptor().TransformFinalBlock(
						buffer,
						0,
						buffer.Length
					)
				);
			}
			catch (CryptographicException)
			{
				return "error decrypting data";
			}
		}

  }
}
