using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web;

using Ascend.ADirectory;
using Ascend.Lib;

namespace Ascend.ADirectory
{
	/// <summary>
	/// Summary description for User.
	/// </summary>
    public class PSUser : Ascend.Lib.Bo
	{
    const string   _updateTable = "ps_actdir_empl_vso";
    private string _userId = String.Empty;
    private string _employeeId = String.Empty;
    private string _lastName = String.Empty;
    private string _firstName = String.Empty;
    private string _middleInitial = String.Empty;
    private string _country = String.Empty;
    private string _title = String.Empty;
		private string _company = String.Empty;
		private string _department = String.Empty;
    private string _managerEmployeeId = String.Empty;
    private string _managerUserId = String.Empty;
    private string _managerLastName = String.Empty;
    private string _managerFirstName = String.Empty;
    private string _managerMiddleInitial = String.Empty;

    /// <summary>
    /// Constructor. Creates instance of RapLookup
    /// </summary>
    public PSUser()
    {
      UpdateTable = _updateTable;
    }

    /// <summary>
    /// Constructor. Creates instance of PSUser for specified userId.
    /// </summary>
    /// <param name="userId">String.</param>
    //public PSUser(string userId)
    //{
    //  UpdateTable = _updateTable;
    //  SetProperties(userId);
    //}

    /// <summary>string Property. Gets/sets userId .</summary>
    public string UserId
    {
      get { return _userId; }
      set { _userId = value; }
    }

    /// <summary>string Property. Gets/sets employeeid.</summary>
    public string EmployeeId
    {
      get { return _employeeId; }
      set { _employeeId = value; }
    }

    /// <summary>string Property. Gets/sets last name.</summary>
    public string LastName
    {
      get { return _lastName; }
      set { _lastName = value; }
    }

    /// <summary>string Property. Gets/sets first name.</summary>
    public string FirstName
    {
      get { return _firstName; }
      set { _firstName = value; }
    }

    /// <summary>string Property. Gets/sets middle initial.</summary>
    public string MiddleInitial
    {
      get { return _middleInitial; }
      set { _middleInitial = value; }
    }

		/// <summary>string Property. Gets Last, First MI.</summary>
		public string LastFirstMI
		{
			get { return String.Format("{0}, {1} {2}", _lastName, _firstName, _middleInitial); }
		}

    /// <summary>string Property. Gets/sets country.</summary>
    public string Country
    {
      get { return _country; }
      set { _country = value; }
    }

		/// <summary>string Property. Gets/sets title.</summary>
		public string Title
		{
			get { return _title; }
			set { _title = value; }
		}

		/// <summary>string Property. Gets/sets company.</summary>
		public string Company
		{
			get { return _company; }
			set { _company = value; }
		}

		/// <summary>string Property. Gets/sets department.</summary>
		public string Department
		{
			get { return _department; }
			set { _department = value; }
		}

		/// <summary>string Property. Gets/sets manager userid .</summary>
    public string ManagerUserId
    {
      get { return _managerUserId; }
      set { _managerUserId = value; }
    }

    /// <summary>string Property. Gets/sets manager employee id.</summary>
    public string ManagerEmployeeId
    {
      get { return _managerEmployeeId; }
      set { _managerEmployeeId = value; }
    }

    /// <summary>string Property. Gets/sets manager last name.</summary>
    public string ManagerLastName
    {
      get { return _managerLastName; }
      set { _managerLastName = value; }
    }

    /// <summary>string Property. Gets/sets manager first name.</summary>
    public string ManagerFirstName
    {
      get { return _managerFirstName; }
      set { _managerFirstName = value; }
    }

    /// <summary>string Property. Gets/sets manager middle initial.</summary>
    public string ManagerMiddleInitial
    {
      get { return _managerMiddleInitial; }
			set { _managerMiddleInitial = value; }
    }

		/// <summary>string Property. Gets manager Last, First MI.</summary>
		public string ManagerLastFirstMI
		{
			get { return String.Format("{0}, {1} {2}", _managerLastName, _managerFirstName, _managerMiddleInitial); }
		}

    /// <summary>
    /// Method. Sets properties of specified userId
    /// </summary>
    /// <param name="userId">userId for PeopleSoft view</param>
    //public void SetProperties(string userId)
    //{
    //  // get DataRow with information about the specified row
    //  DataRow dr = GetDataRow(userId);

    //  _userId = GetString(dr, "email_addr");
    //  _employeeId = GetString(dr, "emplid");
    //        _lastName = GetString(dr, "last_name");
    //        _firstName = GetString(dr, "first_name");
    //        _middleInitial = GetString(dr, "middle_name");
    //        _country = GetString(dr, "country");
    //        _title = GetString(dr, "empl_title");
    //        _company = GetString(dr, "company_descr");
    //        _department = GetString(dr, "dept_descr");
    //        _managerUserId = GetString(dr, "misc1_data");
    //        _managerEmployeeId = GetString(dr, "manager_id");
    //        _managerLastName = GetString(dr, "misc2_data");
    //        _managerFirstName = GetString(dr, "misc3_data");
    //        _managerMiddleInitial = GetString(dr, "misc4_data");
    //    }

    /// <summary>Method. Returns a DataRow for the specified id.</summary>
    /// <param name="id">id of user.</param>
    /// <returns>DataRow with all values for the specified id</returns>
    //public DataRow GetDataRow(string id)
    //{
    //  //  string sql = String.Format("select * from hrprod.ps_actdir_empl_vso where lower(email_addr) = '{1}'", id.ToLower());
    //  //DataTable dt = Db.GetDataTable(sql, Var.PeopleSoftConnect);
    //  //DataRow dr = dt.NewRow();
    //  //if (dt.Rows.Count == 1) dr = dt.Rows[0];
    //  //return dr;
    //}

    //public static DataTable GetBusinessList()
    //{
    //  string sql = "select distinct unit_long_m business from ps_actdir_empl_vso where unit_long_m not in ('Disability') order by unit_long_m";
    //  return ADUtil.GetDataTableFromCache("BusinessListCache", sql, Var.PeopleSoftConnect);
    //}

    //public static bool IsPeoplesoftUser(string userid)
    //{
    //  string sql = string.Format("select count(email_addr) mycount from ps_actdir_empl_vso where upper(email_addr) = '{0}'", userid.ToUpper());
    //  object obj = Db.ExecuteScalar(sql, Var.PeopleSoftConnect);
    //  return (System.Convert.ToInt32(obj) > 0);
    //}

 	}

}
