using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web;

using Ascend.Lib;
using Ascend.ADirectory;

namespace Ascend.ADirectory
{
	/// <summary>
	/// Summary description for User.
	/// </summary>
    public class SoiLocation : Ascend.Lib.Bo
	{
    const string      _updateTable = "soi_location";
    private string    _location_id = String.Empty;
    private string    _region_id = String.Empty;
    private string    _name = String.Empty;
    private string    _address = String.Empty;
    private string    _mailzone = String.Empty;
    private string    _station = String.Empty;
    private string    _attendant = String.Empty;
    private string    _phone = String.Empty;
    private string    _fax = String.Empty;
    private string    _plant_yn = String.Empty;
    private string    _office_yn = String.Empty;
    private string    _tech_yn = String.Empty;
    private string    _joint_yn = String.Empty;
    private string    _regional_yn = String.Empty;
    private string    _more_information = String.Empty;
    private string    _manager = String.Empty;
    private string    _history = String.Empty;
    private string    _key_products = String.Empty;
    private string    _guest_operations = String.Empty;
    private string    _other_information = String.Empty;
    private string    _accomplishments = String.Empty;
    private string    _last_update_date = String.Empty;
    private string    _last_update_user = String.Empty;

    /// <summary>
    /// Constructor. Creates instance of SoiLocation
    /// </summary>
    public SoiLocation()
    {
      UpdateTable = _updateTable;
    }

    /// <summary>
    /// Constructor. Creates instance of SoiLocation for specified location_id.
    /// </summary>
    /// <param name="location_id">String.</param>
    //public SoiLocation(string location_id)
    //{
    //  UpdateTable = _updateTable;
    //  SetProperties(location_id);
    //}

    /// <summary>string Property. Gets/sets location_id.</summary>
    public string LocationId 
    {
      get { return _location_id; }
      set 
      { 
        _location_id = value; 
        if (AddMode) AddField("location_id", _location_id); else AddWhere("location_id", _location_id); 
      }
    }
    

    /// <summary>string Property. Gets/sets region_id.</summary>
    public string RegionId 
    {
      get { return _region_id; }
      set { _region_id = value; AddField("region_id", _region_id);}
    }

    /// <summary>string Property. Gets/sets name.</summary>
    public string Name 
    {
      get { return _name; }
      set { _name = value; AddFieldString("name", _name);}
    }

    /// <summary>string Property. Gets/sets address.</summary>
    public string Address 
    {
      get { return _address; }
      set { _address = value; AddFieldString("address", _address);}
    }

    /// <summary>string Property. Gets/sets mailzone.</summary>
    public string Mailzone 
    {
      get { return _mailzone; }
      set { _mailzone = value; AddFieldString("mailzone", _mailzone);}
    }

    /// <summary>string Property. Gets/sets station.</summary>
    public string Station 
    {
      get { return _station; }
      set { _station = value; AddFieldString("station", _station);}
    }

    /// <summary>string Property. Gets/sets attendant.</summary>
    public string Attendant 
    {
      get { return _attendant; }
      set { _attendant = value; AddFieldString("attendant", _attendant);}
    }

    /// <summary>string Property. Gets/sets phone.</summary>
    public string Phone 
    {
      get { return _phone; }
      set { _phone = value; AddFieldString("phone", _phone);}
    }

    /// <summary>string Property. Gets/sets fax.</summary>
    public string Fax 
    {
      get { return _fax; }
      set { _fax = value; AddFieldString("fax", _fax);}
    }

    /// <summary>string Property. Gets/sets plant_yn.</summary>
    public string PlantYn 
    {
      get { return _plant_yn; }
      set { _plant_yn = value; AddFieldString("plant_yn", _plant_yn);}
    }

    /// <summary>string Property. Gets/sets office_yn.</summary>
    public string OfficeYn 
    {
      get { return _office_yn; }
      set { _office_yn = value; AddFieldString("office_yn", _office_yn);}
    }

    /// <summary>string Property. Gets/sets tech_yn.</summary>
    public string TechYn 
    {
      get { return _tech_yn; }
      set { _tech_yn = value; AddFieldString("tech_yn", _tech_yn);}
    }

    /// <summary>string Property. Gets/sets joint_yn.</summary>
    public string JointYn 
    {
      get { return _joint_yn; }
      set { _joint_yn = value; AddFieldString("joint_yn", _joint_yn);}
    }

    /// <summary>string Property. Gets/sets regional_yn.</summary>
    public string RegionalYn 
    {
      get { return _regional_yn; }
      set { _regional_yn = value; AddFieldString("regional_yn", _regional_yn);}
    }

    /// <summary>string Property. Gets/sets more_information.</summary>
    public string MoreInformation 
    {
      get { return _more_information; }
      set { _more_information = value; AddFieldString("more_information", _more_information);}
    }

    /// <summary>string Property. Gets/sets manager.</summary>
    public string Manager 
    {
      get { return _manager; }
      set { _manager = value; AddFieldString("manager", _manager);}
    }

    /// <summary>string Property. Gets/sets history.</summary>
    public string History 
    {
      get { return _history; }
      set { _history = value; AddFieldString("history", _history);}
    }

    /// <summary>string Property. Gets/sets key_products.</summary>
    public string KeyProducts 
    {
      get { return _key_products; }
      set { _key_products = value; AddFieldString("key_products", _key_products);}
    }

    /// <summary>string Property. Gets/sets guest_operations.</summary>
    public string GuestOperations 
    {
      get { return _guest_operations; }
      set { _guest_operations = value; AddFieldString("guest_operations", _guest_operations);}
    }

    /// <summary>string Property. Gets/sets other_information.</summary>
    public string OtherInformation 
    {
      get { return _other_information; }
      set { _other_information = value; AddFieldString("other_information", _other_information);}
    }

    /// <summary>string Property. Gets/sets accomplishments.</summary>
    public string Accomplishments 
    {
      get { return _accomplishments; }
      set { _accomplishments = value; AddFieldString("accomplishments", _accomplishments);}
    }

    /// <summary>string Property. Gets/sets last_update_date.</summary>
    public string LastUpdateDate 
    {
      get { return _last_update_date; }
      set { _last_update_date = value; AddFieldDate("last_update_date", _last_update_date);}
    }

    /// <summary>string Property. Gets/sets last_update_user.</summary>
    public string LastUpdateUser 
    {
      get { return _last_update_user; }
      set { _last_update_user = value; AddFieldString("last_update_user", _last_update_user);}
    }


    /// <summary>
    /// Method. Sets properties of specified location_id
    /// </summary>
    /// <param name="location_id">location_id for apm_location</param>
    //public void SetProperties(string location_id)
    //{
    //  // get DataRow with information about the specified row
    //  DataRow dr = GetDataRow(location_id);

    //  _location_id = GetString(dr, "location_id");
    //  _region_id = GetString(dr, "region_id");
    //  _name = GetString(dr, "name");
    //  _address = GetString(dr, "address");
    //  _mailzone = GetString(dr, "mailzone");
    //  _station = GetString(dr, "station");
    //  _attendant = GetString(dr, "attendant");
    //  _phone = GetString(dr, "phone");
    //  _fax = GetString(dr, "fax");
    //  _plant_yn = GetString(dr, "plant_yn");
    //  _office_yn = GetString(dr, "office_yn");
    //  _tech_yn = GetString(dr, "tech_yn");
    //  _joint_yn = GetString(dr, "joint_yn");
    //  _regional_yn = GetString(dr, "regional_yn");
    //  _more_information = GetString(dr, "more_information");
    //  _manager = GetString(dr, "manager");
    //  _history = GetString(dr, "history");
    //  _key_products = GetString(dr, "key_products");
    //  _guest_operations = GetString(dr, "guest_operations");
    //  _other_information = GetString(dr, "other_information");
    //  _accomplishments = GetString(dr, "accomplishments");
    //  _last_update_date = GetStringDate(dr, "last_update_date", Var.DisplayDateFormat);
    //  _last_update_user = GetString(dr, "last_update_user");
    //}

    /// <summary>Method. Returns DataTable with all rows</summary>
    /// <returns>DataTable with list of all records in soi_location.</returns>
    public static DataTable GetDataTable()
    {
      //string sql = "select location_id, name, mailzone, station, attendant, phone from apm_location order by location_id";
        //DataTable dt = Db.GetDataTable(sql, Var.SiteInfoConnect);
        DataTable dt = new DataTable();
        dt.Columns.Add("location_id");
        dt.Columns.Add("name");
        dt.Columns.Add("mailzone");
        dt.Columns.Add("station");
        dt.Columns.Add("attendant");
        dt.Columns.Add("phone");

        DataRow dr = dt.NewRow();
        dr["location_id"] = "1200";
        dr["name"] = "Alvin, Texas (Chocolate Bayou)";
        dr["mailzone"] = "1200";
        dr["station"] = "522-xxxx";
        dr["attendant"] = "522-0000";
        dr["phone"] = "(281) 228-4000";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1070";
        dr["name"] = "Atlanta, Georgia";
        dr["mailzone"] = "1070";
        dr["station"] = "622-1xxx";
        dr["attendant"] = "622-0000";
        dr["phone"] = "(770) 951-7600";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1690";
        dr["name"] = "Cantonment, Florida";
        dr["mailzone"] = "1690";
        dr["station"] = "634-xxxx";
        dr["attendant"] = "634-0000";
        dr["phone"] = "(850) 968-7000";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1260";
        dr["name"] = "Decatur, Alabama";
        dr["mailzone"] = "1260";
        dr["station"] = "628-xxxx";
        dr["attendant"] = "628-0000";
        dr["phone"] = "(256) 552-2011";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1235";
        dr["name"] = "Foley, Alabama";
        dr["mailzone"] = "1235";
        dr["station"] = "631-xxxx";
        dr["attendant"] = "631-0000";
        dr["phone"] = "(251) 952-1700";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1440";
        dr["name"] = "Greenwood, South Carolina";
        dr["mailzone"] = "1440";
        dr["station"] = "633-xxxx";
        dr["attendant"] = "633-0000";
        dr["phone"] = "(864) 942-4200";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "1450";
        dr["name"] = "Houston, Texas";
        dr["mailzone"] = "1450";
        dr["station"] = "636-xxxx";
        dr["attendant"] = "636-0000";
        dr["phone"] = "(713) 315-5700";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "5045";
        dr["name"] = "Louvain-la-Neuve, Belgium";
        dr["mailzone"] = "5045";
        dr["station"] = "";
        dr["attendant"] = "";
        dr["phone"] = "32 10 48 1211";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "8090";
        dr["name"] = "Shanghai, China";
        dr["mailzone"] = "8090";
        dr["station"] = "";
        dr["attendant"] = "";
        dr["phone"] = "86-21-6340-3300";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "";
        dr["name"] = "Seoul, Korea";
        dr["mailzone"] = "";
        dr["station"] = "";
        dr["attendant"] = "";
        dr["phone"] = "(82) (2) 564-5092";
        dt.Rows.Add(dr);

        dr = dt.NewRow();
        dr["location_id"] = "";
        dr["name"] = "Taipei, Taiwan R.O.C.";
        dr["mailzone"] = "";
        dr["station"] = "";
        dr["attendant"] = "";
        dr["phone"] = "886-2-8787-0103";
        dt.Rows.Add(dr);

      return dt;
    }

    /// <summary>Method. Returns a DataRow for the specified location_id.</summary>
    /// <param name="location_id">location_id to retrive values.</param>
    /// <returns>DataRow with all values for the specified location_id</returns>
    //public DataRow GetDataRow(string location_id)
    //{
    //  string sql = "select * from soi_location where location_id = " + location_id.ToString();
    //  DataTable dt = Db.GetDataTable(sql, Var.SiteInfoConnect);
    //  DataRow dr = dt.NewRow();
    //  if (dt.Rows.Count == 1) dr = dt.Rows[0];
    //  return dr;
    //}

 	}

}
