using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.DirectoryServices;
using System.Text;
using System.Web;

using Ascend.ADirectory;
using Ascend.Lib;

namespace Ascend.ADirectory
{
	public class ADUser
	{
		public enum WildCardSearch {StartsWith=1, EqualTo, Contains, EndsWith};

        private string[] _selectProperties = new string[] { "sAMAccountName", "distinguishedName", "givenname", "initials", "sn", "displayname", "mailnickname", "streetaddress", "l", "st", "postalcode", "c", "title", "company", "department", "manager", "physicalDeliveryOfficeName", "assistant", "telephoneNumber", "otherTelephone", "homePhone", "otherHomePhone", "mobile", "pager", "facsimileTelephoneNumber", "info", "businessCategory" };
        private string[] _updateProperties = new string[] { "sAMAccountName", "distinguishedName", "givenname", "initials", "sn", "displayname", "mailnickname", "streetaddress", "l", "st", "postalcode", "c", "title", "company", "department", "manager", "physicalDeliveryOfficeName", "assistant", "telephoneNumber", "otherTelephone", "homePhone", "otherHomePhone", "mobile", "pager", "facsimileTelephoneNumber", "info", "businessCategory" };

		private string _userFilter = "(&(ObjectClass={0})(sAMAccountName={1}))";
		private string _distinguishedNameFilter = "(&(ObjectClass={0})(distinguishedName={1}))";
		
		private string _userId = String.Empty;
		private string _distinguishedName = String.Empty;
		private string _firstName = String.Empty;
		private string _middleInitial = String.Empty;
		private string _lastName = String.Empty;
		private string _lastFirstMI = String.Empty;
		private string _displayName = String.Empty;
		private string _alias = String.Empty;
		private string _address = String.Empty;
		private string _city = String.Empty;
		private string _state = String.Empty;
		private string _zip = String.Empty;
		private string _country = String.Empty;
		private string _title = String.Empty;
		private string _company = String.Empty;
		private string _department = String.Empty;
		private string _managerDN = String.Empty;
		private string _manager = String.Empty;
		private string _office = String.Empty;
		private string _assistant = String.Empty;
		private string _businessPhone = String.Empty;
		private string _otherPhone = String.Empty;
		private string _homePhone = String.Empty;
		private string _otherHomePhone = String.Empty;
		private string _fax = String.Empty;
		private string _mobile = String.Empty;
		private string _pager = String.Empty;
		private string _notes = String.Empty;
    private string _businessCategory = string.Empty;

		private WildCardSearch _lastNameSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _firstNameSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _businessPhoneSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _otherPhoneSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _officeSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _zipSearchType = WildCardSearch.StartsWith;
		private WildCardSearch _userIdSearchType = WildCardSearch.StartsWith;
    private WildCardSearch _businessSearchType = WildCardSearch.StartsWith;

		/// <summary>
		/// Constructor. Creates new instance of ADUser.
		/// </summary>
		public ADUser()
		{
		}

		/// <summary>
		/// Constructor. Create new instance of ADUser and populates properties for specified userid
		/// </summary>
		/// <param name="userId"></param>
		public ADUser(string userId)
		{
			SetProperties(userId);
		}

		/// <summary>
		/// Property. logon user id
		/// </summary>
		public string UserId
		{
			get { return _userId; }
			set { _userId = value; }
		}

		/// <summary>
		/// Property. distinguished name of user
		/// </summary>
		public string DistinguishedName
		{
			get { return _distinguishedName; }
			set { _distinguishedName = value; }
		}

		/// <summary>
		/// Property. First name of user
		/// </summary>
		public string FirstName
		{
			get { return _firstName; }
			set { _firstName = value; }
		}

		/// <summary>
		/// Property. Middle initial of user
		/// </summary>
		public string MiddleInitial
		{
			get { return _middleInitial; }
			set { _middleInitial = value; }
		}

		/// <summary>
		/// Property. Last name of user
		/// </summary>
		public string LastName
		{
			get { return _lastName; }
			set { _lastName = value; }
		}

		/// <summary>
		/// Property. Last, First MI name of user
		/// </summary>
		public string LastFirstMI
		{
			get { return String.Format("{0}, {1} {2}",_lastName, _firstName, _middleInitial); }
		}

		/// <summary>
		/// Property. Display name of user
		/// </summary>
		public string DisplayName
		{
			get { return _displayName; }
			set { _displayName = value; }
		}

		/// <summary>
		/// Property. Alias name of user
		/// </summary>
		public string Alias
		{
			get { return _alias; }
			set { _alias = value; }
		}

		/// <summary>
		/// Property. Address (street) of user
		/// </summary>
		public string Address
		{
			get { return _address; }
			set { _address = value; }
		}

		/// <summary>
		/// Property. City of user
		/// </summary>
		public string City
		{
			get { return _city; }
			set { _city = value; }
		}

		/// <summary>
		/// Property. State/Province of user
		/// </summary>
		public string State
		{
			get { return _state; }
			set { _state = value; }
		}

		/// <summary>
		/// Property. Zip code/postal code of user
		/// </summary>
		public string Zip
		{
			get { return _zip; }
			set { _zip = value; }
		}

		/// <summary>
		/// Property. Country of user
		/// </summary>
		public string Country
		{
			get { return _country; }
			set { _country = value; }
		}

		/// <summary>
		/// Property. Title of user
		/// </summary>
		public string Title
		{
			get { return _title; }
			set { _title = value; }
		}

		/// <summary>
		/// Property. Company of user
		/// </summary>
		public string Company
		{
			get { return _company; }
			set { _company = value; }
		}

		/// <summary>
		/// Property. Department of user
		/// </summary>
		public string Department
		{
			get { return _department; }
			set { _department = value; }
		}

		/// <summary>
		/// Property. Manager of user
		/// </summary>
		public string Manager
		{
			get { return _manager; }
			set { _manager = value; }
		}

		/// <summary>
		/// Property. Manager distinguished name
		/// </summary>
		public string ManagerDN
		{
			get { return _managerDN; }
			set { _managerDN = value; }
		}

		/// <summary>
		/// Property. Office of user
		/// </summary>
		public string Office
		{
			get { return _office; }
			set { _office = value; }
		}

		/// <summary>
		/// Property. User's assistant
		/// </summary>
		public string Assistant
		{
			get { return _assistant; }
			set { _assistant = value; }
		}

		/// <summary>
		/// Property. BusinessPhone of user
		/// </summary>
		public string BusinessPhone
		{
			get { return _businessPhone; }
			set { _businessPhone = value; }
		}

		/// <summary>
		/// Property. Other phone of user
		/// </summary>
		public string OtherPhone
		{
			get { return _otherPhone; }
			set { _otherPhone = value; }
		}

		/// <summary>
		/// Property. Home phone of user
		/// </summary>
		public string HomePhone
		{
			get { return _homePhone; }
			set { _homePhone = value; }
		}

		/// <summary>
		/// Property. Other home phone of user
		/// </summary>
		public string OtherHomePhone
		{
			get { return _otherHomePhone; }
			set { _otherHomePhone = value; }
		}

		/// <summary>
		/// Property. Mobile of user
		/// </summary>
		public string Mobile
		{
			get { return _mobile; }
			set { _mobile = value; }
		}

		/// <summary>
		/// Property. Pager of user
		/// </summary>
		public string Pager
		{
			get { return _pager; }
			set { _pager = value; }
		}

		/// <summary>
		/// Property. Fax of user
		/// </summary>
		public string Fax
		{
			get { return _fax; }
			set { _fax = value; }
		}

		/// <summary>
		/// Property. user notes
		/// </summary>
		public string Notes
		{
			get { return _notes; }
			set { _notes = value; }
		}

    public string BusinessCategory
    {
      get { return _businessCategory; }
      set { _businessCategory = value; }
    }
    
    /// <summary>
		/// Property. Last Name search type
		/// </summary>
		public WildCardSearch LastNameSearchType
		{
			get { return _lastNameSearchType; }
			set { _lastNameSearchType = value; }
		}

		/// <summary>
		/// Property. First Name search type
		/// </summary>
		public WildCardSearch FirstNameSearchType
		{
			get { return _firstNameSearchType; }
			set { _firstNameSearchType = value; }
		}

		/// <summary>
		/// Property. Business phone search type
		/// </summary>
		public WildCardSearch BusinessPhoneSearchType
		{
			get { return _businessPhoneSearchType; }
			set { _businessPhoneSearchType = value; }
		}

		/// <summary>
		/// Property. Other Phone search type
		/// </summary>
		public WildCardSearch OtherPhoneSearchType
		{
			get { return _otherPhoneSearchType; }
			set { _otherPhoneSearchType = value; }
		}

		/// <summary>
		/// Property. Office search type
		/// </summary>
		public WildCardSearch OfficeSearchType
		{
			get { return _officeSearchType; }
			set { _officeSearchType = value; }
		}

		/// <summary>
		/// Property. Zip search type
		/// </summary>
		public WildCardSearch ZipSearchType
		{
			get { return _zipSearchType; }
			set { _zipSearchType = value; }
		}

		/// <summary>
		/// Property. User Id search type
		/// </summary>
		public WildCardSearch UserIdSearchType
		{
			get { return _userIdSearchType; }
			set { _userIdSearchType = value; }
		}

    // updates AD with new values
		public void UpdatePeopleSoftValues(string userId)
		{
			// get AD object for the user
			DirectoryEntry user = GetADObject("person", userId, _userFilter, _updateProperties);

			// set authentication values to perform the update
			user.AuthenticationType = AuthenticationTypes.Delegation;
			user.Username = Var.LDAPUserName;
			user.Password = Var.LDAPPassword;

			// set properties
			SetSingleValue(user.Properties["givenname"], this.FirstName);
			SetSingleValue(user.Properties["initials"], this.MiddleInitial);
			SetSingleValue(user.Properties["sn"], this.LastName);
			SetSingleValue(user.Properties["c"], this.Country);
			SetSingleValue(user.Properties["title"], this.Title);
			SetSingleValue(user.Properties["company"], this.Company);
			SetSingleValue(user.Properties["department"], this.Department);

			// commit the changes
			user.CommitChanges();

		}

		// updates AD with new values
		public void UpdateManualValues(string userId, bool updateBusinessCategory)
		{
			// get AD object for the user
			DirectoryEntry user = GetADObject("person", userId, _userFilter, _updateProperties);

			// set authentication values to perform the update
			user.AuthenticationType = AuthenticationTypes.Delegation;
			user.Username = Var.LDAPUserName;
			user.Password = Var.LDAPPassword;

      SetSingleValue(user.Properties["givenName"], this.FirstName);
      SetSingleValue(user.Properties["displayName"], this.DisplayName);
      SetSingleValue(user.Properties["postalcode"], this.Zip);
			SetSingleValue(user.Properties["info"], this.Notes);
			SetSingleValue(user.Properties["telephoneNumber"], this.BusinessPhone);
			SetMultiValue(user.Properties["otherTelephone"], this.OtherPhone);
			SetSingleValue(user.Properties["homePhone"], this.HomePhone);
			SetMultiValue(user.Properties["otherHomePhone"], this.OtherHomePhone);
			SetSingleValue(user.Properties["facsimileTelephoneNumber"], this.Fax);
			SetSingleValue(user.Properties["mobile"], this.Mobile);
			SetSingleValue(user.Properties["pager"], this.Pager);

      if (updateBusinessCategory) SetSingleValue(user.Properties["businessCategory"], this.BusinessCategory);

			// commit the changes
			user.CommitChanges();

		}

		public DataTable GetResultsDataTable()
		{
            bool addResultToCollection = false;
			string filter = GetFilter();
			SearchResultCollection results = GetSearchResultsCollection(filter, _selectProperties);
			DataTable dt = GetEmptyResultsDataTable();

			try
			{
				foreach (SearchResult result in results)
				{                       
					DirectoryEntry de = result.GetDirectoryEntry();
                    string distinguishedName = GetValue(de.Properties["distinguishedName"]);

                    if (_businessCategory == "BLANK")
                        addResultToCollection = (de.Properties["businessCategory"].Value == null);
                    else
                        addResultToCollection = true;


                  // do not include EA, SA, AA, etc. accounts
                  if (addResultToCollection && distinguishedName.IndexOf("OU=NetMan") == -1)
                  {
                    string lastName = GetValue(de.Properties["sn"]);
                    string firstName = GetValue(de.Properties["givenname"]);
                    string mi = GetValue(de.Properties["initials"]);
                    DataRow dr = dt.NewRow();

                    dr["UserId"] = GetValue(de.Properties["sAMAccountName"]);
                    dr["DistinguishedName"] = GetValue(de.Properties["distinguishedName"]);
                    dr["LastName"] = lastName;
                    dr["FirstName"] = firstName;
                    dr["MiddleInitial"] = mi;
                    dr["DisplayName"] = GetValue(de.Properties["displayname"]);
                    dr["Alias"] = GetValue(de.Properties["mailnickname"]);

                    dr["LastFirst"] = string.Format("{0}, {1}", lastName, firstName);

                    dr["Address"] = GetValue(de.Properties["streetAddress"]);
                    dr["City"] = GetValue(de.Properties["l"]);
                    dr["State"] = GetValue(de.Properties["St"]);
                    dr["Zip"] = GetValue(de.Properties["postalcode"]);
                    dr["Country"] = GetValue(de.Properties["c"]);

                    dr["Title"] = GetValue(de.Properties["title"]);
                    dr["Company"] = GetValue(de.Properties["company"]);
                    dr["Department"] = GetValue(de.Properties["department"]);
                    dr["Office"] = GetValue(de.Properties["physicalDeliveryOfficeName"]);
                    dr["Assistant"] = GetValue(de.Properties["assistant"]);

                    dr["BusinessPhone"] = GetValue(de.Properties["telephoneNumber"]);
                    dr["OtherPhone"] = GetValue(de.Properties["otherTelephone"]);
                    dr["HomePhone"] = GetValue(de.Properties["homePhone"]);
                    dr["OtherHomePhone"] = GetValue(de.Properties["otherHomePhone"]);
                    dr["Mobile"] = GetValue(de.Properties["mobile"]);
                    dr["Pager"] = GetValue(de.Properties["pager"]);
                    dr["Fax"] = GetValue(de.Properties["facsimileTelephoneNumber"]);

                    dr["Notes"] = GetValue(de.Properties["info"]);

                    dr["ManagerDN"] = GetValue(de.Properties["manager"]);

                    dr["BusinessCategory"] = GetValue(de.Properties["businessCategory"]);

                    dt.Rows.Add(dr);
                 }
			  }
			}
			catch
			{
				// ignore error
			}
			finally
			{
				results.Dispose();
			}
			return dt;
		}

		private DataTable GetEmptyResultsDataTable()
		{
			DataTable dt = new DataTable("Results");
			dt.Columns.Add(new DataColumn("UserId", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("DistinguishedName", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("LastName", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("FirstName", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("MiddleInitial", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("DisplayName", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Alias", System.Type.GetType("System.String")));

			dt.Columns.Add(new DataColumn("LastFirst", System.Type.GetType("System.String")));

			dt.Columns.Add(new DataColumn("Address", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("City", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("State", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Zip", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Country", System.Type.GetType("System.String")));

			dt.Columns.Add(new DataColumn("Title", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Company", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Department", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Office", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Assistant", System.Type.GetType("System.String")));

			dt.Columns.Add(new DataColumn("BusinessPhone", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("OtherPhone", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("HomePhone", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("OtherHomePhone", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Mobile", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Pager", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Fax", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Notes", System.Type.GetType("System.String")));

			dt.Columns.Add(new DataColumn("Manager", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("ManagerDN", System.Type.GetType("System.String")));

              dt.Columns.Add(new DataColumn("BusinessCategory", System.Type.GetType("System.String")));
              
              dt.DefaultView.Sort = "LastName asc, FirstName asc";
			return dt;
		}

		public DataTable GetUserDataTable()
		{
			DataTable dt = this.GetEmptyResultsDataTable();
			DataRow dr = dt.NewRow();
			dr["UserId"] = this.UserId;
			dr["DistinguishedName"] = this.DistinguishedName;
			dr["LastName"] = this.LastName;
			dr["FirstName"] = this.FirstName;
			dr["MiddleInitial"] = this.MiddleInitial;
			dr["DisplayName"] = this.DisplayName;
			dr["Alias"] = this.Alias;


			dr["Address"] = this.Address;
			dr["City"] = this.City;
			dr["State"] = this.State;
			dr["Zip"] = this.Zip;
			dr["Country"] = this.Country;

			dr["Title"] = this.Title;
			dr["Company"] = this.Company;
			dr["Department"] = this.Department;
			dr["Office"] = this.Office;
			dr["Assistant"] = this.Assistant;

			dr["BusinessPhone"] = this.BusinessPhone;
			dr["OtherPhone"] = this.OtherPhone;
			dr["HomePhone"] = this.HomePhone;
			dr["OtherHomePhone"] = this.OtherHomePhone;
			dr["Mobile"] = this.Mobile;
			dr["Pager"] = this.Pager;
			dr["Fax"] = this.Fax;
			dr["Notes"] = this.Notes;

			dr["Manager"] = this.Manager;
			dr["ManagerDN"] = this.ManagerDN;

            dr["BusinessCategory"] = this.BusinessCategory;

			dt.Rows.Add(dr);
			return dt;
		}

		private void SetProperties(string userId)
		{

			DirectoryEntry user = GetADObject("person", userId, _userFilter, _selectProperties);

			UserId = GetValue(user.Properties["sAMAccountName"]);
			DistinguishedName = GetValue(user.Properties["distinguishedName"]);
			FirstName = GetValue(user.Properties["givenname"]);
			MiddleInitial = GetValue(user.Properties["initials"]);
			LastName = GetValue(user.Properties["sn"]);
			DisplayName = GetValue(user.Properties["displayname"]);
			Alias = GetValue(user.Properties["mailnickname"]);

			Address = GetValue(user.Properties["streetAddress"]);
			City = GetValue(user.Properties["l"]);
			State = GetValue(user.Properties["St"]);
			Zip = GetValue(user.Properties["postalcode"]);
			Country = GetValue(user.Properties["c"]);

		  Title = GetValue(user.Properties["title"]);
		  Company = GetValue(user.Properties["company"]);
		  Department = GetValue(user.Properties["department"]);
		  Office = GetValue(user.Properties["physicalDeliveryOfficeName"]);
		  Assistant = GetValue(user.Properties["assistant"]);

		  BusinessPhone = GetValue(user.Properties["telephoneNumber"]);
		  OtherPhone = GetValue(user.Properties["otherTelephone"]);
		  HomePhone = GetValue(user.Properties["homePhone"]);
		  OtherHomePhone = GetValue(user.Properties["otherHomePhone"]);
		  Mobile = GetValue(user.Properties["mobile"]);
		  Pager = GetValue(user.Properties["pager"]);
		  Fax = GetValue(user.Properties["facsimileTelephoneNumber"]);
			Notes = GetValue(user.Properties["info"]);

      BusinessCategory = GetValue(user.Properties["businessCategory"]);

			// get ad object for manager
			ManagerDN = GetValue(user.Properties["manager"]);
			if (ManagerDN.Length > 0)
			{
				DirectoryEntry manager = GetADObject("person", ManagerDN, _distinguishedNameFilter, _selectProperties);
				Manager = GetValue(manager.Properties["displayName"]);
			}

		}

		private string GetValue(PropertyValueCollection property)
		{
			if (property.Value == null)
			{
				return string.Empty;
			}
			//else if (property.Value.GetType().ToString() == "System.Object[]")
			else if (property.Count > 1)
			{
				System.Object[] obj = (System.Object[]) property.Value;
				StringBuilder sb = new StringBuilder();
				foreach (object o in obj)
				{
					if (sb.Length == 0) sb.Append(o.ToString()); else sb.AppendFormat(";{0}", o);
				}
				return sb.ToString();
			}
			else
			{
				return property.Value.ToString();
			}
		}

		private void SetSingleValue(PropertyValueCollection property, string value)
		{

			if (value.Length == 0)
				property.Clear();
			else
				property.Value = value;
		}

		private void SetMultiValue(PropertyValueCollection property, string value)
		{
			if (value.Length == 0)
				property.Clear();
			else
			{
				string[] values = value.Split(new char[] { ';' });
				property.Clear();
				property.Value = values;
			}
		}

		/// <summary>
		/// Gets a connection to Active Directory at the root level
		/// </summary>
		/// <returns></returns>
		private DirectoryEntry GetRootDirectoryEntry()
		{
			DirectoryEntry root = new DirectoryEntry(Var.LDAPPath);
			root.AuthenticationType = AuthenticationTypes.Delegation;
			root.Username = Var.LDAPUserName;
			root.Password = Var.LDAPPassword;

			return root;
		}

		private DirectorySearcher GetDirectorySearcher(DirectoryEntry root, string[] properties)
		{
			DirectorySearcher searcher = new DirectorySearcher(root);
			searcher.SearchScope = SearchScope.Subtree;
			searcher.ReferralChasing = ReferralChasingOption.All;
			searcher.PropertiesToLoad.AddRange(properties);
			return searcher;
		}

		private DirectoryEntry GetADObject(string adType, string searchName, string filterTemplate, string[] properties)
		{
			DirectoryEntry root = GetRootDirectoryEntry();
			DirectorySearcher searcher = GetDirectorySearcher(root, properties);

			string filter = String.Format(filterTemplate, adType, searchName);
			searcher.Filter = filter;
			
			SearchResult result = searcher.FindOne();
			DirectoryEntry adObject = result.GetDirectoryEntry();
			return adObject;
		}

		private SearchResultCollection GetSearchResultsCollection(string filter, string[] properties)
		{
			DirectoryEntry root = GetRootDirectoryEntry();
			DirectorySearcher searcher = GetDirectorySearcher(root, properties);

			searcher.Filter = (filter.Contains("(businessCategory=BLANK)") ? filter.Replace("(businessCategory=BLANK)", string.Empty) : filter);

			SearchResultCollection results = searcher.FindAll();

			return results;
		}

        // 6/2/2008 sgwiel changed (!userAccountControl=546) to (!userAccountControl=514)
        // 5/18/2011 mmwise changed (!userAccountControl=514) to (!userAccountControl:1.2.840.113556.1.4.803:=2)
		private string GetFilter()
		{
			StringBuilder sb = new StringBuilder(256);
			sb.Append("(&");
			sb.Append("(objectCategory=person)");
			sb.Append("(objectClass=user)");
            if (Ascend.Lib.Util.GetConfig("ShowDisabledAdEntries").ToUpper() != "TRUE")
            {
                //sb.Append("(!userAccountControl=514)");
                sb.Append("(!userAccountControl:1.2.840.113556.1.4.803:=2)");


            }
			sb.Append(GetFilterClause("sn", LastName, LastNameSearchType));
			sb.Append(GetFilterClause("givenName", FirstName, FirstNameSearchType));
			sb.Append(GetFilterClause("telephoneNumber", BusinessPhone, BusinessPhoneSearchType));
			sb.Append(GetFilterClause("otherTelephone", OtherPhone, OtherPhoneSearchType));
			sb.Append(GetFilterClause("physicalDeliveryOfficeName", Office, OfficeSearchType));
			sb.Append(GetFilterClause("postalCode", Zip, ZipSearchType));
			sb.Append(GetFilterClause("sAMAccountName", UserId, UserIdSearchType));
            sb.Append(GetFilterClause("businessCategory", BusinessCategory, WildCardSearch.EqualTo));
			sb.Append(")");
			return sb.ToString();
		}

		private string GetFilterClause(string fieldName, string value, WildCardSearch searchType)
		{
			if (value.Length == 0) return String.Empty;
			switch (searchType)
			{
				case WildCardSearch.StartsWith:
					return String.Format("({0}={1}*)", fieldName, value);
				case WildCardSearch.Contains:
					return String.Format("({0}=*{1}*)", fieldName, value);
				case WildCardSearch.EndsWith:
					return String.Format("({0}=*{1})", fieldName, value);
				default:
					return String.Format("({0}={1})", fieldName, value);
			}
		}

	}
}
