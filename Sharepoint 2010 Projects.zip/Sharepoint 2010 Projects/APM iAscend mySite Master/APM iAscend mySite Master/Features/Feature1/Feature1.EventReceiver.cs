using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using System.Collections;

namespace APM_iAscend_mySite_Master.Features.Feature1
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("c479d8c5-1c11-4f4c-ba5b-95105e74eb88")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite curSite = (SPSite)properties.Feature.Parent;
            SPWeb curWeb = curSite.RootWeb;
            Uri masterUri = new Uri(curWeb.Url + "/_catalogs/masterpage/APMiAscendmySite.master");
            curWeb.MasterUrl = masterUri.AbsolutePath;
            curWeb.CustomMasterUrl = masterUri.AbsolutePath;
            curWeb.Update();
            foreach (SPWeb subWeb in curSite.AllWebs)
            {
                if (subWeb.IsRootWeb) continue;
                Hashtable hash = subWeb.AllProperties;
                subWeb.MasterUrl = subWeb.ParentWeb.MasterUrl;
                hash["__InheritsMasterUrl"] = "True";

                subWeb.CustomMasterUrl = subWeb.ParentWeb.CustomMasterUrl;
                hash["__InheritsCustomMasterUrl"] = "True";

                subWeb.Update();
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite curSite = (SPSite)properties.Feature.Parent;
            SPWeb curWeb = curSite.RootWeb;
            Uri masterUri = new Uri(curWeb.Url + "/_catalogs/masterpage/V4.master");
            curWeb.MasterUrl = masterUri.AbsolutePath;
            curWeb.CustomMasterUrl = masterUri.AbsolutePath;
            curWeb.Update();
            foreach (SPWeb subWeb in curSite.AllWebs)
            {
                if (subWeb.IsRootWeb) continue;
                Hashtable hash = subWeb.AllProperties;
                subWeb.MasterUrl = subWeb.ParentWeb.MasterUrl;
                hash["__InheritsMasterUrl"] = "True";

                subWeb.CustomMasterUrl = subWeb.ParentWeb.CustomMasterUrl;
                hash["__InheritsCustomMasterUrl"] = "True";

                subWeb.Update();
            }
        }
        
        
        
        
        
        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
