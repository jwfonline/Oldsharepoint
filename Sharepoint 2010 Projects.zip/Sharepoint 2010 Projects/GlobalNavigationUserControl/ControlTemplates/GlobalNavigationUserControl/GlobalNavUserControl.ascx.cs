﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;

namespace GlobalNavigationUserControl.ControlTemplates.GlobalNavigationUserControl
{
    public partial class GlobalNavUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SPWeb current_web=SPContext.Current.Web;
            SPUser current_user= current_web.CurrentUser;
            int Count = 0;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                //get the root
                string siteroot = Request.Url.Scheme + "://" + Request.Url.Host;

                try
                {

                
                using (SPSite site = new SPSite(siteroot + "/sites/myascend/hr/"))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            //check if the user has permissions
                            bool permission = web.DoesUserHavePermissions(current_user.LoginName, SPBasePermissions.Open);
                            //if true add the menu item to the nav
                            if (permission == true)
                            {
                                MenuItem hrItem = new MenuItem();
                                hrItem.NavigateUrl = "/sites/myascend/hr";
                                hrItem.Text = " Human Resources";
                                hrItem.Value="Human Resources";
                                Menu1.Items[2].ChildItems.Add(hrItem);
                                Count += 1;
                            }
                        }
                        catch (Exception)
                        {
                            
                          //  throw;
                        }
                      
                        
                    }

                }

                using (SPSite site = new SPSite(siteroot + "/sites/isc/ProjectBambino/"))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            bool permission = web.DoesUserHavePermissions(current_user.LoginName, SPBasePermissions.Open);
                            if (permission == true)
                            {
                                MenuItem ProjectBambinoItem = new MenuItem();
                                ProjectBambinoItem.NavigateUrl = "/sites/isc/ProjectBambino";
                                ProjectBambinoItem.Text = "ProjectBambino";
                                ProjectBambinoItem.Value = "ProjectBambino";
                                Menu1.Items[2].ChildItems.Add(ProjectBambinoItem);
                                Count += 1;
                            }
                        }
                        catch (Exception)
                        {
                            
                            //throw;
                        }
                       
                    }

                }
                    
                }
                catch (Exception)
                {

                   // throw;
                }
            });
        }
    }
}
