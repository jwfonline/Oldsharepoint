﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Web;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Taxonomy;
using Microsoft.SharePoint.Utilities;

using Microsoft.Office.Server;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.Office.Server.SocialData;
using Microsoft.Office.Server.ActivityFeed;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.EnumsAndConstants;
using Iascend.Intranet.Model;
using Iascend.Intranet.Framework.Logging;
//using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Enumerations;


namespace Iascend.Intranet.Data
{
    /// <summary>
    /// This class provides custom SharePoint Data Access methods
    /// </summary>
    [Serializable]
    public static class SPDataAccess
    {

        #region Shared Methods
        /// <summary>
        /// Gets the display name of the profile.
        /// </summary>
        /// <param name="person">The person.</param>
        /// <returns></returns>
        private static string GetProfileDisplayName(string person)
        {
            if (String.IsNullOrEmpty(person)) return "";

            string DisplayName = "";

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    UserProfileManager profileManager = new UserProfileManager(SPServiceContext.Current);
                    if (!profileManager.UserExists(person)) DisplayName = "";

                    else
                    {
                        UserProfile profile = profileManager.GetUserProfile(person);
                        DisplayName = profile.DisplayName.ToString();
                    }
                }
                catch { DisplayName = ""; }

            });

            return DisplayName;

        }



        /// <summary>
        /// Gets the display name of the profile.
        /// </summary>
        /// <param name="profile">The profile.</param>
        /// <returns></returns>
        private static string GetProfileDisplayName(UserProfile profile)
        {
            if (profile == null) return "";

            return profile.DisplayName.ToString();
        }


        /// <summary>
        /// Gets the profile URL.
        /// </summary>
        /// <param name="person">The person.</param>
        /// <returns></returns>
        private static string GetProfileUrl(string person)
        {
            if (String.IsNullOrEmpty(person)) return "";

            string Url = "";

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {

                try
                {
                    UserProfileManager profileManager = new UserProfileManager(SPServiceContext.Current);

                    if (!profileManager.UserExists(person)) Url = "";
                    else
                    {
                        UserProfile profile = profileManager.GetUserProfile(person);
                        Url = profile.PersonalUrl.ToString();
                    }
                }
                catch { Url = ""; }
            });

            return Url;
        }



        /// <summary>
        /// Gets the profile URL.
        /// </summary>
        /// <param name="profile">The profile.</param>
        /// <returns></returns>
        private static string GetProfileUrl(UserProfile profile)
        {
            if (profile == null) return "";

            return profile.PersonalUrl.ToString();
        }


        /// <summary>
        /// Gets the profile picture URL.
        /// </summary>
        /// <param name="person">The person.</param>
        /// <returns></returns>
        private static string GetProfilePictureUrl(string person)
        {
            if (String.IsNullOrEmpty(person)) return "";

            string Url = "";
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {

                try
                {
                    UserProfileManager profileManager = new UserProfileManager(SPServiceContext.Current);
                    if (!profileManager.UserExists(person))
                        Url = "/_layouts/images/person.gif";
                    else
                    {
                        UserProfile profile = profileManager.GetUserProfile(person);

                        if (profile[PropertyConstants.PictureUrl] != null && profile[PropertyConstants.PictureUrl].Value != null && profile[PropertyConstants.PictureUrl].Value.ToString().Length > 0)
                            Url = profile[PropertyConstants.PictureUrl].Value.ToString();
                    }

                }
                catch
                {
                    Url = "/_layouts/images/person.gif";
                }
            });

            if (String.IsNullOrEmpty(Url))
                Url = "/_layouts/images/person.gif";

            return Url;
        }

        /// <summary>
        /// Gets the profile picture URL.
        /// </summary>
        /// <param name="profile">The profile.</param>
        /// <returns></returns>
        private static string GetProfilePictureUrl(UserProfile profile)
        {
            if (profile == null) return "";

            if (profile[PropertyConstants.PictureUrl] != null && profile[PropertyConstants.PictureUrl].Value != null && profile[PropertyConstants.PictureUrl].Value.ToString().Length > 0)
                return profile[PropertyConstants.PictureUrl].Value.ToString();

            return "/_layouts/images/person.gif";
        }
        #endregion

        #region ImageRotator WebPart
        public static List<ImageRotatorItem> GetRandomImage(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<ImageRotatorItem> ImageRotatorItems = new List<ImageRotatorItem>();

            //SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            SPSite currentSite = null;
            SPWeb currentWeb = null;
            SPList RandomImageList = null;

            //insure site and list name are valid
            try
            {
                currentSite = new SPSite(siteUrl);
                currentWeb = currentSite.OpenWeb();
                RandomImageList = currentWeb.Lists[ListName];
            }
            catch
            {
                return ImageRotatorItems;
            }


            //insure that list contains correct columns
            try
            {
                // Construct a StoryQuery that expands recurring events
                SPQuery StoryQuery = new SPQuery();
                StoryQuery.ExpandRecurrence = true;
                StoryQuery.Query = "<Where><Eq><FieldRef Name='Display' /><Value Type='Boolean'>1</Value></Eq></Where>";
      
                  // StoryQuery.CalendarDate = Convert.ToDateTime(date);

                //Get Items
                SPListItemCollection RandomImageListItemCollection = RandomImageList.GetItems(StoryQuery);

                if (RandomImageListItemCollection.Count > 0)
                {
                    for (int x = 0; x < RandomImageListItemCollection.Count; x++)
                    {
                        //if the selected date matches the retrieved training item, then display it
                        //     if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))
                        //if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date))
                        //{
                        ImageRotatorItem ImageRotatorItem = new ImageRotatorItem();
                       // ImageRotatorItem.altText = Convert.ToString(RandomImageListItemCollection[x][SPBuiltInFieldId.Comments]);
                        ImageRotatorItem.imgUrl = Convert.ToString(RandomImageListItemCollection[x]["EncodedAbsUrl"]);
                        ImageRotatorItem.ID = Convert.ToInt32(RandomImageListItemCollection[x]["ID"]);
                       // SPLink link 
                        ImageRotatorItem.link = Convert.ToString(RandomImageListItemCollection[x]["Link"]);
                        ImageRotatorItems.Add(ImageRotatorItem);
                        //}
                    }
                }
            }
            catch
            {
                return ImageRotatorItems;
            }


            return ImageRotatorItems;
        }

        #endregion
        #region [UpcomingEvents WebPart]

        const int lookAheadItems = 3;

        /// <summary>
        /// Gets the upcoming events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<CalendarItem> GetUpcomingEvents(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<CalendarItem> calendarItems = new List<CalendarItem>();
            
            //SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            SPSite currentSite = null;
            SPWeb currentWeb = null;
            SPList calendarList = null;

            //insure site and list name are valid
            try
            {
                currentSite = new SPSite(siteUrl);
                currentWeb = currentSite.OpenWeb();
                calendarList = currentWeb.Lists[ListName];
            }
            catch {
                return calendarItems;
            }


            //Get the scheduled training sessions from SharePoint
            //SPList calendarList = currentWeb.Lists[Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue()];

            //insure that list contains correct columns
            try
            {
                // Construct a calendarQuery that expands recurring events
                SPQuery calendarQuery = new SPQuery();
                calendarQuery.ExpandRecurrence = true;
                calendarQuery.Query = "<Where><DateRangesOverlap><FieldRef Name=\"EventDate\" /><FieldRef Name=\"EndDate\" /><FieldRef Name=\"RecurrenceID\" /><Value Type=\"DateTime\"><Year /></Value></DateRangesOverlap></Where>";
                calendarQuery.CalendarDate = Convert.ToDateTime(date);

                //Get Items
                SPListItemCollection calendarListItemCollection = calendarList.GetItems(calendarQuery);

                if (calendarListItemCollection.Count > 0)
                {
                    for (int x = 0; x < calendarListItemCollection.Count; x++)
                    {
                        //if the selected date matches the retrieved training item, then display it
                        //     if (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))
                        if (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date))
                        {
                            CalendarItem calendarItem = new CalendarItem();
                            calendarItem.ID = Convert.ToString(calendarListItemCollection[x]["ID"]);
                            calendarItem.Title = Convert.ToString(calendarListItemCollection[x]["Title"]);
                            calendarItem.EventDate = Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]);
                            calendarItem.EndDate = Convert.ToDateTime(calendarListItemCollection[x]["EndDate"]);
                            calendarItem.Location = Convert.ToString(calendarListItemCollection[x]["Location"]);
                            calendarItem.URL = Convert.ToString( currentWeb.Url + "/lists/" + ListName);
                            //limit the number of items to the specified count after the selected day
                            if ( (calendarItems.Count >= lookAheadItems) && 
                                 (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date).AddDays(1))) 
                                break;
                            calendarItems.Add(calendarItem);
                        }
                    }
                }
            }
            catch {
                return calendarItems;
            }


            return calendarItems;
        }

        /// <summary>
        /// Gets the upcoming events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<CalendarItem> GetAllUpcomingEventsForSiteCollectionSubSites(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<CalendarItem> calendarItems = new List<CalendarItem>();

            SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            //SPSite currentSite = null;
           // SPWeb currentWeb = null;
            SPList calendarList;

            //insure site and list name are valid
            try
            {
               //currentSite = new SPSite(siteUrl);
                //currentWeb = currentSite.OpenWeb();
                // calendarList = currentWeb.Lists[ListName];
            }
            catch
            {
                return calendarItems;
            }




            //Get the scheduled training sessions from SharePoint
            //SPList calendarList = currentWeb.Lists[Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue()];

            //insure that list contains correct columns
            try
            {
                // Construct a calendarQuery that expands recurring events
                SPQuery calendarQuery = new SPQuery();
                calendarQuery.ExpandRecurrence = true;
                calendarQuery.Query = "<Where><DateRangesOverlap><FieldRef Name=\"EventDate\" /><FieldRef Name=\"EndDate\" /><FieldRef Name=\"RecurrenceID\" /><Value Type=\"DateTime\"><Year /></Value></DateRangesOverlap></Where>";
                calendarQuery.CalendarDate = Convert.ToDateTime(date);


                //loop though all webs
                foreach (SPWeb web in currentSite.AllWebs)
                {
                   
                   
                    //if (calendarList != null && calendarList.ItemCount > 0)
                    if (SPHelper.ListExists( web, ListName))
                    {
                        calendarList = web.Lists[ListName];
                        //Get Items
                        SPListItemCollection calendarListItemCollection = calendarList.GetItems(calendarQuery);

                        if (calendarListItemCollection.Count > 0)
                        {
                            for (int x = 0; x < calendarListItemCollection.Count; x++)
                            {
                                //if the selected date matches the retrieved training item, then display it
                                //     if (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))
                                if (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date))
                                {
                                    CalendarItem calendarItem = new CalendarItem();
                                    calendarItem.ID = Convert.ToString(calendarListItemCollection[x]["ID"]);
                                    calendarItem.Title = Convert.ToString(calendarListItemCollection[x]["Title"]);
                                    calendarItem.EventDate = Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]);
                                    calendarItem.EndDate = Convert.ToDateTime(calendarListItemCollection[x]["EndDate"]);
                                    calendarItem.Location = Convert.ToString(calendarListItemCollection[x]["Location"]);
                                    calendarItem.URL = Convert.ToString(web.Url + "/lists/" + ListName );
                                    //limit the number of items to the specified count after the selected day
                                    if ((calendarItems.Count >= lookAheadItems) &&
                                         (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date).AddDays(1)))
                                        break;
                                    calendarItems.Add(calendarItem);
                                }
                            }
                        }
                    }
                }

            }
            catch
            {
                return calendarItems;
            }

            //sort the calendar
            calendarItems.Sort(delegate(CalendarItem c1, CalendarItem c2)
            {
                return c1.EventDate.CompareTo(c2.EventDate);
            });
           
            return calendarItems;
           // return calendarItems;
        }

        /// <summary>
        /// Gets the upcoming events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<CalendarItem> GetEventsForDate(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<CalendarItem> calendarItems = new List<CalendarItem>();

            //SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            SPSite currentSite = null;
            SPWeb currentWeb = null;
            SPList calendarList = null;

            //insure site and list name are valid
            try
            {
                currentSite = new SPSite(siteUrl);
                currentWeb = currentSite.OpenWeb();
                calendarList = currentWeb.Lists[ListName];
            }
            catch
            {
                return calendarItems;
            }


            //Get the scheduled training sessions from SharePoint
            //SPList calendarList = currentWeb.Lists[Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue()];

            //insure that list contains correct columns
            try
            {
                // Construct a calendarQuery that expands recurring events
                SPQuery calendarQuery = new SPQuery();
                calendarQuery.ExpandRecurrence = true;
                calendarQuery.Query = "<Where><DateRangesOverlap><FieldRef Name=\"EventDate\" /><FieldRef Name=\"EndDate\" /><FieldRef Name=\"RecurrenceID\" /><Value Type=\"DateTime\"><Month /></Value></DateRangesOverlap></Where>";
                calendarQuery.CalendarDate = Convert.ToDateTime(date);

                //Get Items
                SPListItemCollection calendarListItemCollection = calendarList.GetItems(calendarQuery);

                if (calendarListItemCollection.Count > 0)
                {
                    for (int x = 0; x < calendarListItemCollection.Count; x++)
                    {
                        //if the selected date matches the retrieved training item, then display it
                        if (Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))                 
                        {
                            CalendarItem calendarItem = new CalendarItem();
                            calendarItem.ID = Convert.ToString(calendarListItemCollection[x]["ID"]);
                            calendarItem.Title = Convert.ToString(calendarListItemCollection[x]["Title"]);
                            calendarItem.EventDate = Convert.ToDateTime(calendarListItemCollection[x]["EventDate"]);
                            calendarItem.EndDate = Convert.ToDateTime(calendarListItemCollection[x]["EndDate"]);
                            calendarItem.Location = Convert.ToString(calendarListItemCollection[x]["Location"]);
                            calendarItem.URL = Convert.ToString( currentWeb.Url + "/lists/" + ListName);
                            calendarItems.Add(calendarItem);
                        }
                    }
                }
            }
            catch
            {
                return calendarItems;
            }


            return calendarItems;
        }


        #endregion

        #region [Story WebPart]

        //const int lookAheadItems = 3;

        /// <summary>
        /// Gets the Story.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<StoryItem> GetStory(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<StoryItem> StoryItems = new List<StoryItem>();

            //SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            SPSite currentSite = null;
            SPWeb currentWeb = null;
            SPList StoryList = null;

            //insure site and list name are valid
            try
            {
                currentSite = new SPSite(siteUrl);
                currentWeb = currentSite.OpenWeb();
                StoryList = currentWeb.Lists[ListName];
            }
            catch
            {
                return StoryItems;
            }


            //insure that list contains correct columns
            try
            {
                // Construct a StoryQuery that expands recurring events
                SPQuery StoryQuery = new SPQuery();
                StoryQuery.ExpandRecurrence = true;
                StoryQuery.Query = "<Where><Eq><FieldRef Name='Display' /><Value Type='Boolean'>1</Value></Eq></Where>";
               // StoryQuery.CalendarDate = Convert.ToDateTime(date);

                //Get Items
                SPListItemCollection StoryListItemCollection = StoryList.GetItems(StoryQuery);

                if (StoryListItemCollection.Count > 0)
                {
                    for (int x = 0; x < StoryListItemCollection.Count; x++)
                    {
                        //if the selected date matches the retrieved training item, then display it
                        //     if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))
                        //if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date))
                        //{
                            StoryItem StoryItem = new StoryItem();
                            StoryItem.Story = Convert.ToString(StoryListItemCollection[x]["Story"]);
                            StoryItem.ID = Convert.ToInt32(StoryListItemCollection[x]["ID"]);
                            StoryItems.Add(StoryItem);
                        //}
                    }
                }
            }
            catch
            {
                return StoryItems;
            }


            return StoryItems;
        }

    

        /// <summary>
        /// Gets the upcoming events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<StoryItem> GetAllStoryForSiteCollectionSubSites(string siteUrl, string ListName, DateTime? date)
        {

            // instantiate new list for quick links items
            List<StoryItem> StoryItems = new List<StoryItem>();

            SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            //SPSite currentSite = null;
            // SPWeb currentWeb = null;
            SPList StoryList;

            //insure site and list name are valid
            try
            {
                //currentSite = new SPSite(siteUrl);
                //currentWeb = currentSite.OpenWeb();
                // StoryList = currentWeb.Lists[ListName];
            }
            catch
            {
                return StoryItems;
            }




            //Get the scheduled training sessions from SharePoint
            //SPList StoryList = currentWeb.Lists[Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue()];

            //insure that list contains correct columns
            try
            {
                // Construct a StoryQuery that expands recurring events
                SPQuery StoryQuery = new SPQuery();
                StoryQuery.ExpandRecurrence = true;
                StoryQuery.Query = "<Where><DateRangesOverlap><FieldRef Name=\"EventDate\" /><FieldRef Name=\"EndDate\" /><FieldRef Name=\"RecurrenceID\" /><Value Type=\"DateTime\"><Year /></Value></DateRangesOverlap></Where>";
               


                //loop though all webs
                foreach (SPWeb web in currentSite.AllWebs)
                {


                    //if (StoryList != null && StoryList.ItemCount > 0)
                    if (SPHelper.ListExists(web, ListName))
                    {
                        StoryList = web.Lists[ListName];
                        //Get Items
                        SPListItemCollection StoryListItemCollection = StoryList.GetItems(StoryQuery);

                        if (StoryListItemCollection.Count > 0)
                        {
                            for (int x = 0; x < StoryListItemCollection.Count; x++)
                            {
                                //if the selected date matches the retrieved training item, then display it
                                //     if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]).ToShortDateString().Equals(Convert.ToDateTime(date).ToShortDateString()))
                                //if (Convert.ToDateTime(StoryListItemCollection[x]["EventDate"]) >= Convert.ToDateTime(date))
                                //{
                                    StoryItem StoryItem = new StoryItem();
                                    StoryItem.Story = Convert.ToString(StoryListItemCollection[x]["Story"]);
                                   
                                //}
                            }
                        }
                    }
                }

            }
            catch
            {
                return StoryItems;
            }

            ////sort the Story
            //StoryItems.Sort(delegate(StoryItem c1, StoryItem c2)
            //{
            //    return c1.EventDate.CompareTo(c2.EventDate);
            //});

            return StoryItems;
            // return StoryItems;
        }

        /// <summary>
        /// Gets the upcoming events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static List<StoryItem> GetStoryByID(string siteUrl, string ListName, int ID)
        {

            // instantiate new list for quick links items
            List<StoryItem> StoryItems = new List<StoryItem>();

            //SPSite currentSite = new SPSite(SPContext.Current.Site.Url);
            SPSite currentSite = null;
            SPWeb currentWeb = null;
            SPList StoryList = null;

            //insure site and list name are valid
            try
            {
                currentSite = new SPSite(siteUrl);
                currentWeb = currentSite.OpenWeb();
                StoryList = currentWeb.Lists[ListName];
            }
            catch
            {
                return StoryItems;
            }


            //Get the scheduled training sessions from SharePoint
            //SPList StoryList = currentWeb.Lists[Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsStory.GetStringValue()];

            //insure that list contains correct columns
            try
            {
                // Construct a StoryQuery that expands recurring events
                SPQuery StoryQuery = new SPQuery();
                StoryQuery.ExpandRecurrence = true;
                StoryQuery.Query = "<Where><And><Eq><FieldRef Name='Display' /><Value Type='Boolean'>" + ID + "</Value></Eq><Eq><FieldRef Name='ID' /><Value Type='Counter'>1</Value></Eq></And></Where>";
               
                //Get Items
                SPListItemCollection StoryListItemCollection = StoryList.GetItems(StoryQuery);

                if (StoryListItemCollection.Count > 0)
                {
                    for (int x = 0; x < StoryListItemCollection.Count; x++)
                    {
                       
                            StoryItem StoryItem = new StoryItem();
                            StoryItem.Story = Convert.ToString(StoryListItemCollection[x]["Story"]);
                            StoryItem.ID = Convert.ToInt32(StoryListItemCollection[x]["ID"]);
                            StoryItems.Add(StoryItem);
                      
                    }
                }
            }
            catch
            {
                return StoryItems;
            }


            return StoryItems;
        }


        #endregion

        #region [Announcements Web part]

        /// <summary>
        /// Get a list of all announcements from the annoucements list
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllHeadlineItems(string siteUrl, string listName)
        {
            // Get Items
            DataTable dt = SPHelper.GetSPListBySite(siteUrl, listName, null);
            return dt;
        }

        /// <summary>
        /// Generate Announcements Items
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static List<AnnouncementItem> GenerateAnnouncementsItems(DataTable dt)
        {
            // instantiate objects
            List<AnnouncementItem> items = new List<AnnouncementItem>();
            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new AnnouncementItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     Description = item.Lookup<string>("Description")
                 }
                ).ToList();
            }

            return items;
        }

        #endregion

        #region [Get Employees in Spotlight Web part]

        /// <summary>
        /// Get all employees in spotlight
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static DataTable GetAllEmployeesInSpotlight(string siteUrl, string listName)
        {
            DataTable dt = SPHelper.GetSPListByListTitle(listName, siteUrl);
            return dt;
        }

        #endregion

        #region [Get Quicklinks and AppLinks Web parts]

        /// <summary>
        /// Get all links from list
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static IList<LinksListItem> GetAlllinks(string siteUrl, string listName)
        {
            DataTable dt = SPHelper.GetSPListByListTitle(listName, siteUrl);
            return GenerateLinksStreamItems(dt);
        }

        /// <summary>
        /// This method generates all the QuickLinks items.  Selects the right columns by locale
        /// </summary>
        /// <param name="items">The data items to load</param>
        /// <returns>List of QuickLinks Items</returns>
        private static IList<LinksListItem> GenerateLinksStreamItems(DataTable dt)
        {

            // instantiate objects
            IList<LinksListItem> items = new List<LinksListItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new LinksListItem()
                 {
                     URL = ParseLinkUrl(item),
                     DisplayText = ParseLinkDisplayText(item)
                 }
                ).ToList();
            }

            return items;
        }


        /// <summary>
        /// Parses the quick link URL.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <param name="isSpanish">if set to <c>true</c> [is spanish].</param>
        /// <returns></returns>
        private static string ParseLinkUrl(DataRow item)
        {
            return ParseUrl(item, "URL");
        }

        /// <summary>
        /// Parses a sharepoint URL for just the base URL.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public static string ParseUrl(DataRow item, string column)
        {
            string RawUrl = item.Lookup<String>(column);

            if (String.IsNullOrEmpty(RawUrl)) return "";

            if (!RawUrl.Contains(",")) return RawUrl;

            return RawUrl.Split(',')[0].Trim();
        }

        /// <summary>
        /// Parses the quick link display text.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <param name="isSpanish">if set to <c>true</c> [is spanish].</param>
        /// <returns>string</returns>
        private static string ParseLinkDisplayText(DataRow item)
        {
            string RawUrl = item.Lookup<String>("URL");

            if (String.IsNullOrEmpty(RawUrl)) return "";

            if (!RawUrl.Contains(",")) return RawUrl;

            return RawUrl.Substring(RawUrl.IndexOf(',') + 1).Trim();
        }


        #endregion

        #region [Get Config Values]

        /// <summary>
        /// Gets the config value from the configuration list
        /// </summary>
        /// <param name="ConfigKey">The config key.</param>
        /// <returns></returns>
        public static string GetConfigValue(string ConfigKey)
        {
            string ConfigValue = "";

            try
            {
                // Get Configuation List Stream Items
                DataTable dt = SPHelper.GetSPList(Iascend.Intranet.Framework.Enumerations.SharePointLists.ConfigurationList.GetStringValue(), SPContext.Current.Site.Url);
                //DataTable dt = SPHelper.GetSPList(Iascend.Intranet.Framework.Enumerations.SharePointLists.ConfigurationList.GetStringValue());

                if (dt != null && dt.Rows.Count > 0)
                {
                    ConfigValue =
                                   (from item in dt.AsEnumerable()
                                    where item.Lookup<String>("Title") == ConfigKey
                                    select item.Lookup<String>("Value")
                                    ).SingleOrDefault();

                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                //ULSLogHelper.LogErrorMessage("Could not load Configuration Value from Configuration List", ex.ToString());
            }

            return ConfigValue;
        }

        #endregion

        #region [Metadata Web Part]

        /// <summary>
        /// Get Metadata Items
        /// </summary>
        /// <returns></returns>
        public static List<MetadataItem> GetMetadataItems()
        {
            List<MetadataItem> items = new List<MetadataItem>();

            string SiteUrl = SPContext.Current.Site.Url;

            string WebUrl = SPContext.Current.Web.ServerRelativeUrl;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SiteUrl))
                {
                    using (SPWeb oWebsite = site.OpenWeb(WebUrl))
                    {
                        if (oWebsite.Lists.TryGetList(Iascend.Intranet.Framework.Enumerations.SharePointLists.Metadata.GetStringValue()) != null)
                        {
                            DataTable dt = oWebsite.Lists[Iascend.Intranet.Framework.Enumerations.SharePointLists.Metadata.GetStringValue()].Items.GetDataTable();
                            items.AddRange(GenerateMetadataItemsStream(dt, oWebsite.Url));
                        }
                    }
                }
            });

            return items;
        }

        /// <summary>
        /// Get Medata Items
        /// </summary>
        /// <param name="Client"></param>
        /// <returns></returns>
        public static List<MetadataItem> GetMetadataItems(string Client)
        {
            List<MetadataItem> items = new List<MetadataItem>();

            string SiteUrl = SPContext.Current.Site.Url;

            string WebUrl = "/ClientSites";


            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SiteUrl))
                {
                    using (SPWeb oWebsite = site.OpenWeb(WebUrl))
                    {
                        foreach (SPWeb client in oWebsite.Webs)
                        {
                            if (client.Lists.TryGetList(Iascend.Intranet.Framework.Enumerations.SharePointLists.Metadata.GetStringValue()) != null)
                            {
                                DataTable dt = client.Lists[Iascend.Intranet.Framework.Enumerations.SharePointLists.Metadata.GetStringValue()].Items.GetDataTable();
                                List<MetadataItem> metadata = GenerateMetadataItemsStream(dt, client.Url);
                                items.AddRange(metadata.Where(m => m.AssignedBrand == Client));
                            }

                            client.Dispose();
                        }
                    }
                }
            });


            return items;
        }

        /// <summary>
        /// Geenrate Metadata Items Stream
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="SiteUrl"></param>
        /// <returns></returns>
        private static List<MetadataItem> GenerateMetadataItemsStream(DataTable dt, string SiteUrl)
        {
            // instantiate objects
            List<MetadataItem> items = new List<MetadataItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new MetadataItem()
                 {
                     AssignedTeam = dt.Columns.Contains("AssignedTeams") ? item.Lookup<string>("AssignedTeams").SharePointMetaDataFirst() : "",
                     AssignedBrand = dt.Columns.Contains("ClientAndBrand") ? item.Lookup<string>("ClientAndBrand").SharePointMetaDataFirst() : "",
                     ClientUrl = SiteUrl,
                     Title = item.Lookup<string>("Title"),
                     Description = item.Lookup<string>("Description"),
                     AccountLeadName = item.Lookup<string>("AccountLeadName"),
                     AccountLeadEmail = item.Lookup<string>("AccountLeadEmail"),
                     AccountLeadPhone = item.Lookup<string>("AccountLeadPhone"),
                     ClientContactName = item.Lookup<string>("ClientContactName"),
                     ClientContactEmail = item.Lookup<string>("ClientContactEmail"),
                     ClientContactPhone = item.Lookup<string>("ClientContactPhone")

                 }
                ).ToList();
            }

            return items;
        }

        #endregion

        #region [Marios Place]

        /// <summary>
        /// Get Marios Place welcome message
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static MariosWelcomeMessageItem GetMariosPlaceWelcomeMessage(string listName)
        {
            MariosWelcomeMessageItem welcomeMessageItem = new MariosWelcomeMessageItem();
            string webUrl = SPContext.Current.Web.ServerRelativeUrl;


            string siteUrl = SPContext.Current.Site.Url;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb spWeb = site.OpenWeb(webUrl))
                    {
                        if (spWeb.Lists.TryGetList(listName) != null)
                        {
                            DataTable dt = spWeb.Lists[listName].Items.GetDataTable();
                            welcomeMessageItem = GenerateMariosWelcomeMessageItem(dt)[0];
                        }
                    }
                }
            });

            return welcomeMessageItem;
        }

        /// <summary>
        /// Generate Announcements Items
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static List<MariosWelcomeMessageItem> GenerateMariosWelcomeMessageItem(DataTable dt)
        {
            // instantiate objects
            List<MariosWelcomeMessageItem> items = new List<MariosWelcomeMessageItem>();
            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new MariosWelcomeMessageItem()
                 {
                     title = item.Lookup<string>("title"),
                     welcomeMessage = item.Lookup<string>("WelcomeMessage"),
                     ImageURL = ParseUrl(item, "PPSMA_FCOImage"),
                     SignatureURL = ParseUrl(item, "SignatureImage")
                 }
                ).ToList();
            }

            return items;
        }

        /// <summary>
        /// Get Marios Place welcome message
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static MariosContactInformationItem GenerateMariosContactInformation(string listName)
        {
            string siteUrl = SPContext.Current.Site.Url;
            string webUrl = SPContext.Current.Web.ServerRelativeUrl;
            MariosContactInformationItem contactInformationItem = new MariosContactInformationItem();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb spWeb = site.OpenWeb(webUrl))
                    {
                        if (spWeb.Lists.TryGetList(listName) != null)
                        {
                            DataTable dt = spWeb.Lists[listName].Items.GetDataTable();

                            if (GenerateMariosContactInformation(dt) != null)
                            {
                                contactInformationItem = GenerateMariosContactInformation(dt)[0];
                            }
                        }
                    }
                }
            });

            return contactInformationItem;
        }

        /// <summary>
        /// Generate Announcements Items
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static List<MariosContactInformationItem> GenerateMariosContactInformation(DataTable dt)
        {
            // instantiate objects
            List<MariosContactInformationItem> items = new List<MariosContactInformationItem>();
            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new MariosContactInformationItem()
                 {
                     emailAddress = item.Lookup<string>("Title"),
                     mobilePhone = item.Lookup<string>("MobilePhone"),
                     officePhone = item.Lookup<string>("OfficePhone")
                 }
                ).ToList();
            }

            return items;
        }

        /// <summary>
        /// Get Marios Place welcome message
        /// </summary>
        /// <param name="siteUrl"></param>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static List<MariosBookItem> GetMariosBooks(string listName)
        {
            string siteUrl = SPContext.Current.Site.Url;
            string webUrl = SPContext.Current.Web.ServerRelativeUrl;
            List<MariosBookItem> mariosBooks = new List<MariosBookItem>();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb spWeb = site.OpenWeb(webUrl))
                    {
                        if (spWeb.Lists.TryGetList(listName) != null)
                        {
                            DataTable dt = spWeb.Lists[listName].Items.GetDataTable();

                            if (GenerateMariosBooks(dt) != null)
                            {
                                mariosBooks = GenerateMariosBooks(dt);
                            }
                        }
                    }
                }
            });

            return mariosBooks;
        }

        /// <summary>
        /// Generate Announcements Items
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static List<MariosBookItem> GenerateMariosBooks(DataTable dt)
        {
            // instantiate objects
            List<MariosBookItem> spotlighted = new List<MariosBookItem>();
            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
               spotlighted = (from item in dt.AsEnumerable()
                                                    orderby item.Lookup<DateTime>("Created") descending
                                              select new MariosBookItem()
                                              {
                                                  title = item.Lookup<string>("Title"),
                                                  description = item.Lookup<string>("Description"),
                                                  author = item.Lookup<string>("Author0"),
                                                  imageUrl = item.Lookup<string>("Cover"),
                                                  published = item.Lookup<string>("Published"),
                                                  created = item.Lookup<DateTime>("Created"),
                                              }).ToList();


             
            }

            return spotlighted;
        }

        #endregion

        #region [Project Status Control]

        /// <summary>
        /// Gets all project status items.
        /// </summary>
        /// <returns></returns>
        public static List<ProjectStatusItem> GetAllProjectStatusItemsForSite()
        {
            List<ProjectStatusItem> items = new List<ProjectStatusItem>();

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SPContext.Current.Site.Url))
                    {
                        using (SPWeb oWebsite = site.OpenWeb(SPContext.Current.Web.ServerRelativeUrl))
                        {
                            if (oWebsite.Lists.TryGetList(SharePointLists.ProjectStatus.GetStringValue()) != null)
                            {
                                DataTable dt = oWebsite.Lists[SharePointLists.ProjectStatus.GetStringValue()].Items.GetDataTable();
                                items.AddRange(GenerateProjectStatusStreamItems(dt, oWebsite));
                            }

                            //One Level Down....
                            foreach (SPWeb subWeb in oWebsite.Webs)
                            {
                                try
                                {
                                    if (subWeb.Lists.TryGetList(SharePointLists.ProjectStatus.GetStringValue()) != null)
                                    {
                                        DataTable dt = subWeb.Lists[SharePointLists.ProjectStatus.GetStringValue()].Items.GetDataTable();
                                        items.AddRange(GenerateProjectStatusStreamItems(dt, subWeb));
                                    }
                                }
                                catch { throw; }
                                finally
                                {
                                    site.Dispose();
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
            }

            return items;
        }

        /// <summary>
        /// Generates the project status stream items.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="site">The site.</param>
        /// <returns></returns>
        private static List<ProjectStatusItem> GenerateProjectStatusStreamItems(DataTable dt, SPWeb site)
        {
            // instantiate objects
            List<ProjectStatusItem> items = new List<ProjectStatusItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new ProjectStatusItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     Description = item.Lookup<string>("Description"),
                     ProjectManager = item.Lookup<string>("ProjectManager"),
                     EstimatedCompletionDate = item.Lookup<DateTime>("EstimatedCompletionDate"),
                     PlannedStartDate = item.Lookup<DateTime>("PlannedStartDate"),
                     ProjectPercentageComplete = item.Lookup<Double>("PercentComplete"),
                     ID = item.Lookup<Int32>("ID")
                 }
                ).ToList();
            }

            return items;
        }

        #endregion

        #region [Other]

        /// <summary>
        /// Get list items
        /// </summary>
        /// <param name="listName"></param>
        /// <returns></returns>
        public static DataTable GetListItems(string listName)
        {
            return GetListItems(listName, SPContext.Current.Site.Url);
        }

        /// <summary>
        /// Get List Items
        /// </summary>
        /// <param name="listName"></param>
        /// <param name="siteUrl"></param>
        /// <returns></returns>
        public static DataTable GetListItems(string listName, string siteUrl)
        {
            return GetListItems(listName, siteUrl, SPContext.Current.Web.ServerRelativeUrl);
        }

        /// <summary>
        /// Get List Items
        /// </summary>
        /// <param name="listName"></param>
        /// <param name="siteUrl"></param>
        /// <param name="serverRelativeUrl"></param>
        /// <returns></returns>
        public static DataTable GetListItems(string listName, string siteUrl, string serverRelativeUrl)
        {
            DataTable result = null;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb spWeb = site.OpenWeb(serverRelativeUrl))
                    {
                        if (spWeb.Lists.TryGetList(listName) != null)
                        {
                            result = spWeb.Lists[listName].Items.GetDataTable();
                        }
                    }
                }
            });

            return result;
        }

        #endregion

        #region Blog Post Comment

        /// <summary>
        /// Gets all blog post comment items.
        /// </summary>
        /// <returns></returns>
        public static List<BlogPostCommentItem> GetAllBlogPostCommentItems(bool UseRootAsStart)
        {
            // instantiate new list for Blog Post Comment Items
            List<BlogPostCommentItem> items = new List<BlogPostCommentItem>();

            try
            {
                string SiteUrl = SPContext.Current.Site.Url;
                string WebUrl = SPContext.Current.Web.ServerRelativeUrl;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    if (UseRootAsStart)
                    {
                        using (SPSite site = new SPSite(SiteUrl))
                        {
                            GetBlogCommentsListRecursive(site.RootWeb, items);
                        }
                    }

                    else
                    {
                        using (SPSite site = new SPSite(SiteUrl))
                        {
                            using (SPWeb web = site.OpenWeb(WebUrl))
                            {
                                GetBlogCommentsListRecursive(web, items);
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Get All Blog Post Comment Items", ex.ToString());
            }

            return items;
        }

        /// <summary>
        /// Gets the blog comments list recursive.
        /// </summary>
        /// <param name="site">The site.</param>
        /// <param name="items">The items.</param>
        public static void GetBlogCommentsListRecursive(SPWeb site, List<BlogPostCommentItem> items)
        {
            try
            {

                foreach (SPWeb subSite in site.Webs)
                {
                    try
                    {
                        if (subSite.Lists.TryGetList(SharePointLists.Comments.GetStringValue()) != null)
                        {
                            DataTable dt = subSite.Lists[SharePointLists.Comments.GetStringValue()].Items.GetDataTable();
                            items.AddRange(GenerateBlogPostCommentStreamItems(dt, subSite));
                        }

                        GetBlogCommentsListRecursive(subSite, items);

                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.Write(ex.ToString());
                        ULSLogHelper.LogErrorMessage("Get Blogs Comments List Recursive - Error accessing subsite: " + subSite.Name, ex.ToString());
                    }

                    subSite.Dispose();

                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Get Blogs Comments List Recursive - Error accessing site: " + site.Name, ex.ToString());
            }
        }


        /// <summary>
        /// Generates the blog post comment stream items.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="blogSite">The blog site.</param>
        /// <returns></returns>
        private static List<BlogPostCommentItem> GenerateBlogPostCommentStreamItems(DataTable dt, SPWeb blogSite)
        {
            // instantiate objects
            List<BlogPostCommentItem> items = new List<BlogPostCommentItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new BlogPostCommentItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     Body = item.Lookup<string>("Body"),
                     CreatedDate = item.Lookup<DateTime>("Created"),
                     Author = item.Lookup<string>("Author"),
                     AuthorProfileUrl = GetProfileUrl(item.Lookup<string>("Author")),
                     AuthorPictureUrl = GetProfilePictureUrl(item.Lookup<string>("Author")),
                     AuthorDisplayName = GetProfileDisplayName(item.Lookup<string>("Author")),
                     CommentUrl = String.Format("{0}/Lists/Posts/BlogDetail.aspx?ID={1}", blogSite.Url, item.Lookup<string>("PostID").ToString())
                 }
                ).ToList();
            }

            return items;
        }
        #endregion

        #region BlogList Web Part
        /// <summary>
        /// Gets the current site blog post items.
        /// </summary>
        /// <returns></returns>
        public static List<BlogPostItem> GetCurrentSiteBlogPostItems()
        {
            // instantiate new list for Blog Post Items
            List<BlogPostItem> items = new List<BlogPostItem>();

            string SiteUrl = SPContext.Current.Site.Url;
            string WebUrl = SPContext.Current.Web.ServerRelativeUrl;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SiteUrl))
                    {
                        using (SPWeb oWebsite = site.OpenWeb(WebUrl))
                        {
                            if (oWebsite.Lists.TryGetList(SharePointLists.BlogPosts.GetStringValue()) != null)
                            {
                                DataTable dt = oWebsite.Lists[SharePointLists.BlogPosts.GetStringValue()].Items.GetDataTable();
                                items.AddRange(GenerateCurrentSiteBlogPostStreamItems(dt, oWebsite));
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Get Current Site Blog Items", ex.ToString());
            }

            return items;
        }

        /// <summary>
        /// Generates the blog post stream items.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="SiteURL">The site URL.</param>
        /// <returns></returns>
        private static List<BlogPostItem> GenerateCurrentSiteBlogPostStreamItems(DataTable dt, SPWeb blogSite)
        {
            // instantiate objects
            List<BlogPostItem> items = new List<BlogPostItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new BlogPostItem()
                 {
                     SiteName = blogSite.Title ?? blogSite.Name,
                     Title = item.Lookup<string>("Title"),
                     Body = item.Lookup<string>("Body"),
                     NumComments = item.Lookup<string>("NumComments"),
                     PostCategory = item.Lookup<string>("PostCategory"),
                     PublishedDate = item.Lookup<DateTime>("PublishedDate"),
                     VideoPictureTitle = item.Lookup<string>("VideoPictureTitle") ?? "",
                     FeaturedBlog = item.Lookup<string>("FeaturedBlog"),
                     Author = item.Lookup<string>("Author"),
                     AuthorProfileUrl = GetProfileUrl(item.Lookup<string>("Author")),
                     AuthorPictureUrl = GetProfilePictureUrl(item.Lookup<string>("Author")),
                     AuthorDisplayName = GetProfileDisplayName(item.Lookup<string>("Author")),
                     VideoPictureUrl = GetVideoPictureUrl(blogSite, item.Lookup<string>("VideoPictureTitle"), item.Lookup<string>("ExternalVideoUrl")),
                     BlogUrl = String.Format("{0}/Lists/Posts/BlogDetail.aspx?ID={1}", blogSite.Url, item.Lookup<int>("ID").ToString()),
                     PostID = item.Lookup<int>("ID"),
                     AssignedTeam = dt.Columns.Contains("AssignedTeam") ? item.Lookup<string>("AssignedTeam").SharePointMetaDataFirst() : "",
                     AssignedClient = dt.Columns.Contains("AssignedClient") ? item.Lookup<string>("AssignedClient").SharePointMetaDataFirst() : ""
                 }
                ).ToList();
            }

            return items;
        }

        #endregion

        #region BlogSiteList WebPart

        /// <summary>
        /// Gets all blog list items.
        /// </summary>
        /// <returns></returns>
        public static List<BlogSiteListItem> GetAllBlogSiteListItems(bool StartAtTopLevel)
        {
            List<BlogSiteListItem> items = new List<BlogSiteListItem>();

            try
            {
                string SiteUrl = SPContext.Current.Site.Url;
                string WebUrl = SPContext.Current.Web.ServerRelativeUrl;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    if (StartAtTopLevel)
                    {
                        using (SPSite site = new SPSite(SiteUrl))
                        {
                            GetBlogSiteListRecursive(site.RootWeb, items);
                        }
                    }

                    else
                    {
                        using (SPSite site = new SPSite(SiteUrl))
                        {
                            using (SPWeb web = site.OpenWeb(WebUrl))
                            {
                                GetBlogSiteListRecursive(web, items);
                            }
                        }
                    }

                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Get All Blog Site List Items", ex.ToString());
            }

            return items;
        }


        /// <summary>
        /// Gets the blog list recursively.
        /// </summary>
        /// <param name="site">The site.</param>
        /// <param name="items">The items.</param>
        public static void GetBlogSiteListRecursive(SPWeb site, List<BlogSiteListItem> items)
        {
            try
            {
                foreach (SPWeb subSite in site.Webs)
                {
                    try
                    {
                        if (subSite.Lists.TryGetList(SharePointLists.BlogPosts.GetStringValue()) != null)
                        {
                            items.Add(new BlogSiteListItem()
                            {
                                Title = subSite.Name == "Blog" ? site.Name + " Blog" : subSite.Name.Contains("Blog") ? subSite.Name : subSite.Name + " Blog",
                                BlogUrl = String.Format("{0}", subSite.Url),
                                SiteName = subSite.Name
                            });
                        }

                        GetBlogSiteListRecursive(subSite, items);
                    }
                    catch { throw; }
                    finally
                    {
                        subSite.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("GetBlogSiteListRecursive, Site: " + site.Name, ex.ToString());
            }
        }

        #endregion

        #region videoBlogRotator WebPart

        /// <summary>
        /// Gets all blog post items.
        /// </summary>
        /// <returns></returns>
        public static List<BlogPostItem> GetAllBlogPostItems()
        {
            // instantiate new list for Blog Post Items
            List<BlogPostItem> items = new List<BlogPostItem>();

            try
            {

                string SiteUrl = SPContext.Current.Site.Url;
                string WebUrl = "/Blogs/";

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(SiteUrl))
                    {
                        using (SPWeb spWeb = site.OpenWeb(WebUrl))
                        {
                            try
                            {
                                if (spWeb.Lists.TryGetList(SharePointLists.BlogPosts.GetStringValue()) != null)
                                {
                                    DataTable dt = spWeb.Lists[SharePointLists.BlogPosts.GetStringValue()].Items.GetDataTable();
                                    items.AddRange(GenerateBlogPostStreamItems(dt, spWeb));
                                }
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.Write(ex.ToString());
                                ULSLogHelper.LogErrorMessage("Error Loading Blog Post List", ex.ToString());
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Could not load All Blog Post Items", ex.ToString());
            }
            return items;
        }

        /// <summary>
        /// Generates the blog post stream items.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="SiteURL">The site URL.</param>
        /// <returns></returns>
        private static List<BlogPostItem> GenerateBlogPostStreamItems(DataTable dt, SPWeb blogSite)
        {
            // instantiate objects
            List<BlogPostItem> items = new List<BlogPostItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 select new BlogPostItem()
                 {
                     SiteName = dt.Columns.Contains("AssignedTeam") ? item.Lookup<string>("AssignedTeam").SharePointMetaDataFirst() : blogSite.Name,
                     Title = item.Lookup<string>("Title"),
                     Body = item.Lookup<string>("Body"),
                     NumComments = item.Lookup<string>("NumComments"),
                     PostCategory = item.Lookup<string>("PostCategory"),
                     PublishedDate = item.Lookup<DateTime>("PublishedDate"),
                     VideoPictureTitle = item.Lookup<string>("VideoPictureTitle") ?? "",
                     FeaturedBlog = item.Lookup<string>("FeaturedBlog"),
                     Author = item.Lookup<string>("Author"),
                     AuthorProfileUrl = GetProfileUrl(item.Lookup<string>("Author")),
                     AuthorPictureUrl = GetProfilePictureUrl(item.Lookup<string>("Author")),
                     AuthorDisplayName = GetProfileDisplayName(item.Lookup<string>("Author")),
                     VideoPictureUrl = GetVideoPictureUrl(blogSite, item.Lookup<string>("VideoPictureTitle"), item.Lookup<string>("ExternalVideoUrl")),
                     BlogUrl = String.Format("{0}/Lists/Posts/BlogDetail.aspx?ID={1}", blogSite.Url, item.Lookup<int>("ID").ToString()),
                     BlogListUrl = String.Format("{0}", blogSite.Url),
                     PostID = item.Lookup<int>("ID"),
                     AssignedTeam = dt.Columns.Contains("AssignedTeam") ? item.Lookup<string>("AssignedTeam").SharePointMetaDataFirst() : "",
                     AssignedClient = dt.Columns.Contains("AssignedClient") ? item.Lookup<string>("AssignedClient").SharePointMetaDataFirst() : ""
                 }
                ).ToList();
            }

            return items;
        }

        /// <summary>
        /// Gets the video picture URL.
        /// </summary>
        /// <param name="blogSite">The blog site.</param>
        /// <param name="Title">The title.</param>
        /// <param name="ExternalVideoUrl">The external video URL.</param>
        /// <returns></returns>
        private static string GetVideoPictureUrl(SPWeb blogSite, string Title, string ExternalVideoUrl)
        {
            if (!String.IsNullOrEmpty(Title))
            {
                BlogPostMediaItem bpmi = GetBlogPostMediaItem(blogSite, Title);
                if (bpmi != null && bpmi.URL.Length > 0)
                    return bpmi.URL;
            }

            if (string.IsNullOrEmpty(ExternalVideoUrl))
            {
                return "/SiteCollectionImages/Iascend.jpg";
            }

            return ExternalVideoUrl;
        }


        /// <summary>
        /// Gets the blog post media item.
        /// </summary>
        /// <param name="blogSite">The blog site.</param>
        /// <param name="Title">The title.</param>
        /// <returns></returns>
        private static BlogPostMediaItem GetBlogPostMediaItem(SPWeb blogSite, string DocumentTitle)
        {
            // instantiate new list for quick links items
            List<BlogPostMediaItem> items = null;

            DataTable dt = blogSite.Lists[SharePointLists.VideosAndPhotos.GetStringValue()].Items.GetDataTable();
            items = GenerateBlogPostMediaItems(blogSite, DocumentTitle, dt);

            return items.FirstOrDefault();
        }


        /// <summary>
        /// Generates the blog post media items.
        /// </summary>
        /// <param name="blogSite">The blog site.</param>
        /// <param name="Title">The title.</param>
        /// <param name="dt">The dt.</param>
        /// <returns></returns>
        private static List<BlogPostMediaItem> GenerateBlogPostMediaItems(SPWeb blogSite, string DocumentTitle, DataTable dt)
        {

            List<BlogPostMediaItem> items = new List<BlogPostMediaItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 where item.Lookup<string>("Title") == DocumentTitle
                 select new BlogPostMediaItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     URL = String.Format("{0}/{1}/{2}", blogSite.Url, SharePointLists.VideosAndPhotos.GetStringValue(), item.Lookup<string>("FileLeafRef"))
                 }
                ).ToList();

            }

            return items;
        }




        #endregion

    }
}
