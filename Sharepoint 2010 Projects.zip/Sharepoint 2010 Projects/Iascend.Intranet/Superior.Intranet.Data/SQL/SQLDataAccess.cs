﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Utilities;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.Model;

namespace Iascend.Intranet.Data
{
    /// <summary>
    /// This class provides data access/wrappers for custom SQL Server Data
    /// </summary>
    [Serializable]
    public static class SQLDataAccess
    {
        
    }
}
