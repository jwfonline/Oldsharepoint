﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Collections.ObjectModel;
using System.Collections;
using System.Web.UI;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Taxonomy;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.WebControls;

using Iascend.Intranet.Framework;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Data;
using Iascend.Intranet.Business;
using Iascend.Intranet.Model;
using Iascend.Intranet.Framework.Helpers;

namespace Iascend.Intranet.Business
{
    /// <summary>
    /// This class contains all the basic business logic for the web parts
    /// </summary>
    public class BlogManager
    {
        #region Shared Functions
        
        #region Get Config Value from Configuration List

        /// <summary>
        /// Gets the config value.
        /// </summary>
        /// <param name="ConfigKey">The config key.</param>
        /// <returns></returns>
        public static string GetConfigValue(string ConfigKey)
        {
            return SPDataAccess.GetConfigValue(ConfigKey);
        }
        #endregion

        public static string SiteUrl()
        {
            return SPContext.Current.Web.Url;
        }

        public static string SiteName()
        {
            return SPContext.Current.Web.Name;
        }

        public static string GetAssignedTeam()
        {

            List<MetadataItem> items = new List<MetadataItem>();
            items = SPDataAccess.GetMetadataItems();

            if (items.Count > 0)
            {
                return items[0].AssignedTeam;
            }

            return SPContext.Current.Web.Name;

        }

        public static string GetAssignedClient()
        {

            List<MetadataItem> items = new List<MetadataItem>();
            items = SPDataAccess.GetMetadataItems();

            if (items.Count > 0)
            {
                return items[0].AssignedBrand;
            }

            return SPContext.Current.Web.Name;
        }

        public static string GetAssignedBrand()
        {
            List<MetadataItem> items = new List<MetadataItem>();
            items = SPDataAccess.GetMetadataItems();

            if (items.Count > 0)
            {
                return items[0].AssignedBrand;
            }

            return "";
        }


        public static MetadataItem GetClientMetadata(string Client)
        {
            List<MetadataItem> items = new List<MetadataItem>();

            items = SPDataAccess.GetMetadataItems(Client);

            return items.FirstOrDefault<MetadataItem>();
        }

        public static MetadataItem GetClientMetadataBySiteUrl()
        {
            List<MetadataItem> items = new List<MetadataItem>();

            items = SPDataAccess.GetMetadataItems();

            return items.FirstOrDefault<MetadataItem>();
        }

        public static string SiteTitle()
        {
            return SPContext.Current.Web.Title;
        }

        public static string ParentSiteName()
        {
            return SPContext.Current.Web.ParentWeb.Name;
        }

        public static string ParentSiteTitle()
        {
            return SPContext.Current.Web.ParentWeb.Title;
        }

        #endregion

        #region  Build Media Viewer Strings

        public static string GetEmbeddedViewer(string Url, string Title)
        {
            string Viewer = "";

            //Embedded Photo
            if (Url.EndsWith(".jpg")
                || Url.EndsWith(".gif")
                || Url.EndsWith(".png")
                || Url.EndsWith(".tiff")
                || Url.EndsWith(".jpeg")
                || Url.EndsWith(".bmp")
                )
            {
                Viewer = String.Format("<img width=\"100%\" src=\"{0}\" alt=\"{1}\" />", Url, Title);
            }
            //Embedded YouTube Viewer
            else if (Url.Contains("youtube.com"))
            {
                Viewer = String.Format("<object width=\"100%\" height=\"240px\"><param name=\"movie\" value=\"{0}{1}\" /><param name=\"allowFullScreen\" value=\"true\" /><param name=\"wmode\" value=\"transparent\" /><param name=\"allowscriptaccess\" value=\"always\" /><embed src=\"{0}{1}\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" allowscriptaccess=\"always\" allowfullscreen=\"true\" width=\"100%\" height=\"240px\"></embed></object>",
                    Url.Replace("watch?v=", "v/"),
                    Url.EndsWith("&amp;hl=en_US&amp;fs=1") ? "" : "&amp;hl=en_US&amp;fs=1");
            }
            //Embedded Quicktime Viewer
            else if (Url.EndsWith(".mov"))
            {
                Viewer = String.Format("<object width=\"100%\" codebase=\"http://www.apple.com/qtactivex/qtplugin.cab\" classid=\"clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B\"><param name=\"wmode\" value=\"transparent\" /><param name=\"AutoPlay\" value=\"False\" /><param name=\"src\" value=\"{0}\" /> <param name=\"scale\" value=\"tofit\">  <embed width=\"320px\" height=\"240px\" src=\"{0}\" pluginspage=\"http://www.apple.com/quicktime/download/\" autoplay=\"false\" scale=\"tofit\"></embed> </object>",
                                            Url);
            }
            //Embedded Flash Player
            else if (Url.EndsWith(".swf"))
            {
                Viewer = String.Format("<object width=\"100%\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7\" classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" type=\"application/x-oleobject\"> <param name=\"wmode\" value=\"transparent\" /> <param name=\"src\" value=\"{0}\" /> <embed width=\"100%\" src=\"{0}\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" pluginspage=\"http://www.adobe.com/go/getflashplayer\"></embed> </object>",
                                             Url);
            }
            else if (Url.EndsWith(".wmv"))
            //Embedded Silverlight Player
            {
                Viewer = String.Format("<object width=\"100%\" data=\"data:application/x-silverlight-2,\" type=\"application/x-silverlight-2\"><param value=\"/_layouts/clientbin/mediaplayer.xap\" name=\"source\" /><param value=\"true\" name=\"enableHtmlAccess\" /><param value=\"true\" name=\"windowless\" /><param value=\"#80808080\" name=\"background\" /><param value=\"mediaTitle={1},mediaSource={0},previewImageSource=/Style Library/Media Player/VideoPreview.png,autoPlay=false,loop=false\" name=\"initParams\"></object>",
                   Url, Title);
            }

            return Viewer;
        }

        public static string GetEmbeddedPlaceholderImage(string Url, string Title)
        {
            string Viewer = "";

            //Embedded Photo
            if (Url.EndsWith(".jpg")
                || Url.EndsWith(".gif")
                || Url.EndsWith(".png")
                || Url.EndsWith(".tiff")
                || Url.EndsWith(".jpeg")
                || Url.EndsWith(".bmp")
                )
            {
                Viewer = String.Format("<img width=\"100%\" src=\"{0}\" alt=\"{1}\" />", Url, Title);
            }
            //Embedded YouTube Viewer
            else if (Url.Contains("youtube.com"))
            {
                Viewer = String.Format("<img width=\"100%\" src=\"{0}\" alt=\"{1}\" />", "/SiteCollectionImages/YouTube.jpg", Title);
            }
            //Embedded Quicktime Viewer
            else if (Url.EndsWith(".mov"))
            {
                Viewer = String.Format("<img width=\"100%\" src=\"{0}\" alt=\"{1}\" />", "/SiteCollectionImages/Quicktime.png", Title);
            }
            else if (Url.EndsWith(".wmv"))
            //Embedded Silverlight Player
            {
                Viewer = String.Format("<img width=\"100%\" src=\"{0}\" alt=\"{1}\" />", "/SiteCollectionImages/Silverlight.png", Title);
            }

            return Viewer;
        }

        #endregion


        #region Get Recent Post Comments List

        public static List<BlogPostCommentItem> GetCurrentSiteRecentBlogPostCommentItems()
        {
            return SPDataAccess.GetAllBlogPostCommentItems(false);
        }

        public static List<BlogPostCommentItem> GetRecentBlogPostCommentItems()
        {
            return SPDataAccess.GetAllBlogPostCommentItems(true);
        }

        #endregion  

        #region BlogList WebPart

        /// <summary>
        /// Gets all blog post items for the site.
        /// </summary>
        /// <returns></returns>
        public static List<BlogPostItem> GetCurrentSiteBlogPostItems()
        {
            return SPDataAccess.GetCurrentSiteBlogPostItems();

        }

        public static List<BlogPostItem> GetAllBlogPostItems()
        {
            List<BlogPostItem> items = SPDataAccess.GetAllBlogPostItems();

            return items;
        }

        /// <summary>
        /// Gets all blog post items for the site.
        /// </summary>
        /// <param name="TeamName">Name of the team.</param>
        /// <returns></returns>
        public static List<BlogPostItem> GetAllBlogPostItems(string TeamName)
        {
            List<BlogPostItem> items = SPDataAccess.GetAllBlogPostItems();

            if (!String.IsNullOrEmpty(TeamName))
                items = items.Where(bpi => bpi.AssignedTeam == TeamName).ToList<BlogPostItem>();

            return items;
        }

        #endregion

     

        #region Blog Listing WebPart
        public static List<BlogSiteListItem> GetAllBlogSiteListItems(bool StartAtRoot)
        {
            List<BlogSiteListItem> Blogs = new List<BlogSiteListItem>();

            Blogs.AddRange(SPDataAccess.GetAllBlogSiteListItems(StartAtRoot));

            return Blogs;

        }
        #endregion

      
    }
}
