﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;

using Iascend.Intranet.Model;
using Iascend.Intranet.Data;


namespace Iascend.Intranet.Business
{
  public   class RandomStoryRotaterManager
    {
        public static List<StoryItem> GetStory(string ListSite, string ListName)
        {
            return SPDataAccess.GetStory(ListSite, ListName, null);
        }
        public static List<StoryItem> GetStoryByID(string ListSite, string ListName, int ID)
        {
            return SPDataAccess.GetStoryByID(ListSite, ListName, ID);
        }
    }
}
