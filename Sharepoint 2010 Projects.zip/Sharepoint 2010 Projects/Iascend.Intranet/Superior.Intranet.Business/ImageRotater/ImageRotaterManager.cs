﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using Microsoft.SharePoint;

using Iascend.Intranet.Model;
using Iascend.Intranet.Data;

namespace Iascend.Intranet.Business
{
  public  class ImageRotaterManager
    {
        public static List<ImageRotatorItem> GetRandomImage(string ListSite, string ListName)
        {
            return SPDataAccess.GetRandomImage(ListSite, ListName, null);
        }

    }
}
