﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Data;
using Iascend.Intranet.Model;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Framework.Caching;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.Business
{
    public class LeftNavigationManager
    {

        private static bool ColumnExists(DataTable Table, string ColumnName)
        {
            bool bRet = false;
            foreach (DataColumn col in Table.Columns)
            {
                if (col.ColumnName == ColumnName)
                {
                    bRet = true;
                    break;
                }
            }

            return bRet;
        }

        public static List<LeftNavigationItem> GetLeftNavigationItems()
        {
            //            string key = CacheHelper.GetCacheKey<List<LeftNavigationItem>>("GetDiscussionRollUpItems");
            //            if (CacheHelper.CacheContainsKey<List<LeftNavigationItem>>(key))
            //            {
            //                return CacheHelper.GetCacheItem<List<LeftNavigationItem>>(key);
            //            }
            //            else
            //            {
            try
            {
                List<LeftNavigationItem> items = LeftNavigationManager.InternalGetDiscussionRollUpItems();
                //                    if (items != null)
                //                    {
                //                        CacheHelper.SetCacheItem<List<LeftNavigationItem>>(key, items);
                //                    }
                return items;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                throw ex;
            }
            //           }
        }

        private static List<LeftNavigationItem> InternalGetDiscussionRollUpItems()
        {
            DataTable dataTable = SPDataAccess.GetListItems(SharePointLists.LeftNavigation.GetStringValue());

            List<LeftNavigationItem> items = new List<LeftNavigationItem>();

            if (!ColumnExists(dataTable, "DisplayOrder") ||
                 !ColumnExists(dataTable, "Title") ||
                 !ColumnExists(dataTable, "Link") ||
                 !ColumnExists(dataTable, "Section") ||
                 !ColumnExists(dataTable, "NewWindow"))
                return items;

            if (dataTable != null && dataTable.Rows.Count > 0)
            {
                try
                {
                    items =
                   (from item in dataTable.AsEnumerable()
                    orderby item.Field<double>("DisplayOrder")
                    select new LeftNavigationItem()
                    {
                        Title = item.Lookup<string>("Title"),
                        Url = item.Lookup<string>("Link").Substring(0, item.Lookup<string>("Link").IndexOf(",")),
                        Category = item.Lookup<string>("Section"),
                        NewWindow = item.Lookup<string>("NewWindow")
                    }
                   ).ToList();
                }
                catch
                {
                    try
                    {
                        items =
                        (from item in dataTable.AsEnumerable()
                         orderby item.Field<string>("Title")
                         select new LeftNavigationItem()
                         {
                             Title = item.Lookup<string>("Title"),
                             Url = item.Lookup<string>("Link").Substring(0, item.Lookup<string>("Link").IndexOf(",")),
                             Category = item.Lookup<string>("Section"),
                             NewWindow = item.Lookup<string>("NewWindow")
                         }
                        ).ToList();
                    }
                    catch
                    {
                        items = null;
                        //System.Diagnostics.Debug.Write("LeftNavigationList is not in required format: Title, Link, Section, NewWindow");
                    }
                }

            }


            return items;
        }
    }
}
