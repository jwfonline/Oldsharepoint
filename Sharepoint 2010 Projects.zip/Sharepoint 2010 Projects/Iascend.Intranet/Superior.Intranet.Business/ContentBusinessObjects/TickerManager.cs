﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;

using Iascend.Intranet.Model;
using Iascend.Intranet.Framework.Caching;
using Iascend.Intranet.Framework.Logging;
using Iascend.Intranet.Data;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using System.Data;
using System.Diagnostics;

namespace Iascend.Intranet.Business
{
    public class TickerManager
    {
        /// <summary>
        /// Gets all In the News Events.
        /// </summary>
        /// <param name="locale">The locale.</param>
        /// <returns></returns>
        public static List<TickerItem> GetAllTickers(string siteUrl)
        {
            string key = CacheHelper.GetCacheKey<List<TickerItem>>("GetTickerItemsBySiteUrl_" + siteUrl );

            if (CacheHelper.CacheContainsKey<List<TickerItem>>(key))
            {
                return CacheHelper.GetCacheItem<List<TickerItem>>(key);
            }
            else
            {
                try
                {
                    List<TickerItem> items = new List<TickerItem>();

                    //Add Calendar Items
                    try
                    {
                        items.AddRange(GenerateTickerCalendarStreamItems(siteUrl, SharePointLists.EventsCalendar.GetStringValue()));
                    }
                    catch
                    {
                    }
                    //Add Calendar Items
                    try
                    {
                        items.AddRange(GenerateTickerCalendarStreamItems(siteUrl, SharePointLists.ReportCalendar.GetStringValue()));
                    }
                    catch
                    {
                    }
                    //Add News and Announcement items
                    try
                    {
                        items.AddRange(GenerateTickerNewsItems(siteUrl, SharePointLists.News.GetStringValue()));
                    }
                    catch
                    {
                    }
                    try
                    {
                        items.AddRange(GenerateTickerNewsItems(siteUrl, SharePointLists.Announcements.GetStringValue()));
                    }
                    catch
                    {
                    }
                    //Add Tickers List Items
                    try
                    {
                        items.AddRange(GenerateTickerListItems(siteUrl, SharePointLists.Tickers.GetStringValue()));
                    }
                    catch
                    {
                    }
                    CacheHelper.SetCacheItem<List<TickerItem>>(key, items);
                    return items;
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Write(ex.ToString());
                    throw ex;
                }
            }
        }

        /// <summary>
        /// This method generates all the TickerItem items From the Ticker List. gets all ticket where open is yes.  
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="urlField">The URL field.</param>
        /// <returns>List of TickerItem Items</returns>
        public static List<TickerItem> GenerateTickerListItems(string siteUrl, string listName)
        {

            // instantiate objects
            DataTable dt = SPHelper.GetSPListByListTitle(listName, siteUrl);
            List<TickerItem> items = new List<TickerItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 where item.Lookup<string>("Display") == "1" & item.Lookup<DateTime>("Expires") >= DateTime.Now.Date
                 select new TickerItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     //URL = ContentManager.ParseUrl(item,"URL")
                   //  URL = string.Format( SPContext.Current.Site.Url + "/Lists/Tickers/DispForm.aspx?ID={0}",  item.Lookup<int>("ID").ToString())
                     URL = string.Format(siteUrl + "/Lists/" + listName + "/DispForm.aspx?ID={0}", item.Lookup<int>("ID").ToString())
                 }
                ).ToList();
            }

            return items;
        }

        /// <summary>
        /// This method generates all the TickerItem items.  
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="urlField">The URL field.</param>
        /// <returns>List of TickerItem Items</returns>
        private static List<TickerItem> GenerateTickerNewsItems(string siteUrl, string listName)
        {

            // instantiate objects
            DataTable dt = SPHelper.GetSPListByListTitle(listName, siteUrl);
            List<TickerItem> items = new List<TickerItem>();
            string listNameForUrl = "News";

            if (listName.ToLower().Equals("announcements"))
            {
                listNameForUrl = "Announcements";
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 where  item.Lookup<string>("AddtoTicker") == "Yes"
                 && item.Lookup<DateTime>("PublishDate") <= DateTime.Now
                     && (item.Lookup<DateTime>("ExpirationDate") == DateTime.MinValue || item.Lookup<DateTime>("ExpirationDate") >= DateTime.Now)
                 select new TickerItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     //URL = string.Format("/Pages/News-and-Announcements.aspx?ID={0}",  item.Lookup<int>("ID").ToString())
                     URL = string.Format(SPContext.Current.Site.Url + "/Lists/{0}/DispForm.aspx?ID={1}", listNameForUrl, item.Lookup<int>("ID").ToString())
                 }
                ).ToList();
            }

            return items;
        }

        /// <summary>
        /// Generates the ticker calendar stream items.
        /// </summary>
        /// <param name="dt">The dt.</param>
        /// <param name="locale">The locale.</param>
        /// <param name="urlField">The URL field.</param>
        /// <returns>List of TickerItem Items</returns>
        private static List<TickerItem> GenerateTickerCalendarStreamItems(string siteUrl, string listName)
        {
            DataTable dt = SPHelper.GetSPListByListTitle(listName, siteUrl);
            // instantiate objects
            List<TickerItem> items = new List<TickerItem>();

            if (dt != null && dt.Rows.Count > 0)
            {
                // perform a linq query to loop on all the items and map them
                items =
                (from item in dt.AsEnumerable()
                 where item.Lookup<string>("AddtoTicker") == "Yes"
                     //&& item.Lookup<DateTime>("EventDate") >= DateTime.Today
                     && item.Lookup<DateTime>("PublishDate") <= DateTime.Now
                     && (null != item.Lookup<DateTime>("ExpirationDate") && (item.Lookup<DateTime>("ExpirationDate") == DateTime.MinValue || item.Lookup<DateTime>("ExpirationDate") >= DateTime.Now))
                 select new TickerItem()
                 {
                     Title = item.Lookup<string>("Title"),
                     URL = string.Format( SPContext.Current.Site.Url + "/Lists/{0}/DispForm.aspx?ID={1}", listName, item.Lookup<int>("ID").ToString())
                 }
                ).ToList();
            }

            return items;
        }
    }
}

