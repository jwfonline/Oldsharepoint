﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;

using Iascend.Intranet.Model;
using Iascend.Intranet.Data;

namespace Iascend.Intranet.Business
{
    public class UpcomingEventsManager
    {
        #region Shared Functions
        #region Get Config Value from Configuration List

        /// <summary>
        /// Gets the config value.
        /// </summary>
        /// <param name="ConfigKey">The config key.</param>
        /// <returns></returns>
        public static string GetConfigValue(string ConfigKey)
        {
            return SPDataAccess.GetConfigValue(ConfigKey);
        }
        #endregion

        public static string SiteUrl()
        {
            return SPContext.Current.Web.Url;
        }

        public static string SiteName()
        {
            return SPContext.Current.Web.Name;
        }

        public static string GetAssignedTeam()
        {

            List<MetadataItem> items = new List<MetadataItem>();
            items = SPDataAccess.GetMetadataItems();

            if (items.Count > 0)
            {
                return items[0].AssignedTeam;
            }

            return SPContext.Current.Web.Name;

        }

        public static string GetAssignedBrand()
        {
            List<MetadataItem> items = new List<MetadataItem>();
            items = SPDataAccess.GetMetadataItems();

            if (items.Count > 0)
            {
                return items[0].AssignedBrand;
            }

            return "";
        }


        public static MetadataItem GetClientMetadata(string Client)
        {
            List<MetadataItem> items = new List<MetadataItem>();

            items = SPDataAccess.GetMetadataItems(Client);

            return items.FirstOrDefault<MetadataItem>();
        }

        public static string SiteTitle()
        {
            return SPContext.Current.Web.Title;
        }

        public static string ParentSiteName()
        {
            return SPContext.Current.Web.ParentWeb.Name;
        }

        public static string ParentSiteTitle()
        {
            return SPContext.Current.Web.ParentWeb.Title;
        }

        #endregion

        #region UpcomingEvents WebPart
        public static List<CalendarItem> GetUpcomingEvents(string ListSite, string ListName)
        {
            return SPDataAccess.GetUpcomingEvents(ListSite, ListName, null);
        }

        public static List<CalendarItem> GetUpcomingEvents(string ListSite, string ListName, DateTime dt)
        {
            return SPDataAccess.GetUpcomingEvents(ListSite, ListName, dt);
        }

        public static List<CalendarItem> GetAllUpcomingEventsForSiteCollectionSubSites(string ListSite, string ListName, DateTime dt)
        {
            return SPDataAccess.GetAllUpcomingEventsForSiteCollectionSubSites(ListSite, ListName, dt);
        }

        public static List<CalendarItem> GetEventsForDate(string ListSite, string ListName, DateTime dt)
        {
            return SPDataAccess.GetEventsForDate(ListSite, ListName, dt);
        }

        #endregion
    }
}
