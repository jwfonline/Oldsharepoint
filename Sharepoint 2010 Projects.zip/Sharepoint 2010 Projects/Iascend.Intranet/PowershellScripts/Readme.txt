#this is a set of powershell scripts for Iascend - modify as needed
#do the following for a successful run
#Step1 - edit all powershell scripts to reflect the proper hostname/port
#Step2 - run them in name order 01..02..etc - DO NOT RUN step 3 unless you want to overwrite the content type settings!
#Step3 - deploy Iascend.Intranet.Site and Iascend.Intranet.Webparts to the site
#go to the site and make sure things work 