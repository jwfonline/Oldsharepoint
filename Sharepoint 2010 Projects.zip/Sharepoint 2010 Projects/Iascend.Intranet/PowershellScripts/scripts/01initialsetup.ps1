﻿Add-PsSnapin Microsoft.SharePoint.PowerShell 

# SharePoint cmdlets Add-PsSnapin Microsoft.SharePoint.PowerShell 
# Set variables 
$WebAppPort = 80
$WebAppName = ("IascendEnergyIntranet" + $WebAppPort)
$WebAppHostHeader = "st-Iascend-dev"
$WebAppAppPool = ($WebAppName + $WebAppPort)
$WebAppAppPoolAccount = "DMZ\sppsconfig_dev"
$WebAppDatabaseName = ($WebAppName + $WebAppPort)
$WebAppDatabaseServer = "ST-Iascend-DEV"
$SiteCollectionName = "Iascend Intranet Home"
	$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
#	$WebAppUrl = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}
$SiteCollectionTemplate = "BLANKINTERNET#2"
$SiteCollectionLanguage = 1033 
$SiteCollectionSecondary = "DMZ\suzanne.george"  
$SiteCollectionOwner = $WebAppAppPoolAccount  
# Create a new Sharepoint WebApplication 
New-SPWebApplication -Name $WebAppName `
	-Port $WebAppPort `
	-HostHeader $WebAppHostHeader `
	-URL $WebAppUrl `
	-ApplicationPool $WebAppAppPool `
	-ApplicationPoolAccount (Get-SPManagedAccount $WebAppAppPoolAccount) `
	-DatabaseName $WebAppDatabaseName `
	-DatabaseServer $WebAppDatabaseServer  
# Create a new Sharepoint Site Collection 
New-SPSite -URL $SiteCollectionURL `
	-OwnerAlias $SiteCollectionOwner `
	-Language $SiteCollectionLanguage `
	-Template $SiteCollectionTemplate `
	-Name $SiteCollectionName `
	-SecondaryOwnerAlias $SiteCollectionSecondary
