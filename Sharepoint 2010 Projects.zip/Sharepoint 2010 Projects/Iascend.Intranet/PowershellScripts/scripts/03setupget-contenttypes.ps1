﻿$WebAppHostHeader = "st-Iascend-dev"
$WebAppPort = 81 
$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}
#Get site and web object
$site = Get-SPSite -Identity $SiteCollectionURL
$sourceWeb = $site.RootWeb 
$xmlFilePath = "C:\0-install\Script-SiteContentTypes2.xml"

#Create Export File
New-Item $xmlFilePath -type file -force

#Export Content Types to XML file
Add-Content $xmlFilePath "<?xml version=`"1.0`" encoding=`"utf-8`"?>"
Add-Content $xmlFilePath "`n<ContentTypes>"
$sourceWeb.ContentTypes | ForEach-Object {
    if ($_.Group -eq "Iascend") {
        Add-Content $xmlFilePath $_.SchemaXml
    }
}
Add-Content $xmlFilePath "</ContentTypes>"

$sourceWeb.Dispose()

