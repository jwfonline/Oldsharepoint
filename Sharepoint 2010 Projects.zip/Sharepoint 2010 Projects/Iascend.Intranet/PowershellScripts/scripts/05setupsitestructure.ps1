﻿$WebAppHostHeader = "st-Iascend-dev"
$WebAppPort = 80 
$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}

function RemoveSPWebRecursively(
    [Microsoft.SharePoint.SPWeb] $web)
{
    Write-Debug "Removing site ($($web.Url))..."
    
    $subwebs = $web.GetSubwebsForCurrentUser()
    
    foreach($subweb in $subwebs)
    {
        RemoveSPWebRecursively($subweb)
        $subweb.Dispose()
    }
    
    $DebugPreference = "SilentlyContinue"
    Remove-SPWeb $web -Confirm:$false
    $DebugPreference = "Continue"
}





#Get site and web object
Write-Host $SiteCollectionURL


$site = Get-SPSite -Identity $SiteCollectionURL
$sourceWeb = $site.RootWeb



#does top IT site exist
$siteurl = ($SiteCollectionURL + "/IT")
$web = Get-SPWeb $siteurl
#delete site for testing
#RemoveSPWebRecursively $web


$spweb = Get-SPWeb $siteurl -ErrorAction:SilentlyContinue
if ($spweb -eq $null)
{
	Write-Host "creating IT site"
	new-SPWeb $siteurl `
		-template "BLANKINTERNET#2" `
		-addtotopnav `
		-useparenttopnav `
		-name "Information Technology" 
	enable-spfeature -Identity TeamCollab -url $siteurl -ErrorAction SilentlyContinue
}
$siteurl = ($SiteCollectionURL + "/IT/SesiIT")
$spweb = Get-SPWeb $siteurl -ErrorAction:SilentlyContinue
if ($spweb -eq $null)
{
	Write-Host "creating Sesi IT site"
	new-SPWeb $siteurl `
		-template "BLANKINTERNET#2" `
		-addtotopnav `
		-useparenttopnav `
		-name "SeSI Information Technology" 
	enable-spfeature -Identity TeamCollab -url $siteurl -ErrorAction SilentlyContinue
}
[xml]$s = get-content sitestructure.xml 
foreach ($e in $s.Setup.Sites)
{
	$topsite = $e.TopSiteName.title
	$topurl = $e.TopSiteName.url    
	$lcid = $e.TopSiteName.lcid
	$template = $e.TopSiteName.template   
	$subsites = $e.SubSiteName
	$baseurl = "$siteurl/$topurl"

	Write-Host ("top site " + $topsite)
	Write-Host ("url " + $topurl)
	$topspweb = Get-SPWeb $topurl -ErrorAction:SilentlyContinue
	if ($topspweb -eq $null)
	{
		new-SPWeb $baseurl `
			-template $template `
			-addtotopnav `
			-Language $lcid `
			-useparenttopnav `
			-name $topsite 
		enable-spfeature -Identity TeamCollab -url $baseurl -ErrorAction SilentlyContinue
	}
	if($subsites.Length -gt 0) 
	{ 
		foreach ($subsite in $subsites)
		{ 
			$suburl = ($baseurl + "/" + $subsite.url)
			$sublcid = $subsite.lcid
			$subtemplate = $subsite.template   
			$subsite = $subsite.title
			
			Write-Host ("sub site " + $subsite)
			Write-Host ("---url " + $suburl)
			$subspweb = Get-SPWeb $suburl -ErrorAction:SilentlyContinue
			if ($subspweb -eq $null)
			{
				new-SPWeb $suburl `
					-template $subtemplate `
					-name $subsite `
					-AddToQuickLaunch `
					-useparenttopnav 
			}
		} 
	} 
}

