﻿$WebAppHostHeader = "st-Iascend-dev"
$WebAppPort = 80
$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}
#Get site and web object
$site = Get-SPSite -Identity $SiteCollectionURL
$web = $site.RootWeb 

#Assign fieldXML variable with XML string for site column
$fieldXML = '<Field Type="Choice"
Name="DocumentType"
Description="Settings for document types used in lists and libraries."
DisplayName="Document Type"
StaticName="DocumentType"
Group="Iascend"
Hidden="FALSE"
Required="FALSE"
Sealed="FALSE"
ShowInDisplayForm="TRUE"
ShowInEditForm="TRUE"
ShowInListSettings="TRUE"
ShowInNewForm="TRUE">
<Default></Default>
<CHOICES>
<CHOICE>FAQ</CHOICE>
<CHOICE>InternalDocuments</CHOICE>
<CHOICE>BusinessManagement</CHOICE>
<CHOICE>News</CHOICE>
<CHOICE>Other</CHOICE>
</CHOICES></Field>' 
$fieldXML2 = '<Field Type="Number"
Name="SortOrder"
Description="Settings for SortOrder used web parts."
DisplayName="Sort Order"
StaticName="SortOrder"
Group="Iascend"
Hidden="FALSE"
Required="FALSE"
Sealed="FALSE"
ShowInDisplayForm="TRUE"
ShowInEditForm="TRUE"
ShowInListSettings="TRUE"
ShowInNewForm="TRUE"></Field>' 
#Output XML to console
write-host $fieldXML 

#Create site column from XML string
$web.Fields.AddFieldAsXml($fieldXML) 
$web.Fields.AddFieldAsXml($fieldXML2) 

##Example of changing the site column settings after creation
##Configure Test Date column to be Date Only instead of Date & Time
#$dtField = $web.Fields["Test Date"]
#$dtField.DisplayFormat = "DateOnly"
#$dtField.Update() 

#Dispose of Web and Site objects
$web.Dispose()
$site.Dispose() 

