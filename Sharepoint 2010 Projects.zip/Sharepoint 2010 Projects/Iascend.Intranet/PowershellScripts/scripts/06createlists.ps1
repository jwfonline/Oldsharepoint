﻿$WebAppHostHeader = "st-Iascend-dev"
$WebAppPort = 80
$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}
$SPAssignment = Start-SPAssignment
$siteurl = ($SiteCollectionURL + "/IT")
$SPWeb = Get-SPWeb $siteurl -AssignmentCollection $spAssignment
$SPWeb2 = Get-SPWeb $SiteCollectionURL -AssignmentCollection $spAssignment

$announcementlist = $SPWeb.Lists["Tickers"]
if ($announcementlist -eq $null)
{
	$spContentType = $SPWeb2.ContentTypes["AlertsTicker"]
	$SPTemplate = $SPWeb.ListTemplates["Announcements"]
	$SPWeb.Lists.Add("Tickers","Alert Ticker List for displaying IT outages on external-internal pages",$SPTemplate)
	$announcementlist = $SPWeb.Lists["Tickers"]
	$announcementlist.ContentTypesEnabled = $true
	$announcementlist.ContentTypes.Add($spContentType)
	$announcementlist.OnQuickLaunch = "True"
	$announcementlist.Update()
	#$spFieldType = [Microsoft.SharePoint.SPFieldType]::Checkbox 
	$announcementlist.Fields.Add("Open", "Boolean", $false)
	$announcementlist.Fields.Add("AlertSent", "Boolean", $false)
	#$spFieldType = [Microsoft.SharePoint.SPFieldType]::DateTime 
	$announcementlist.Fields.Add("AlertSentDate", "DateTime", $false)
	$announcementlist.Update()
	$spView = $spweb.GetViewFromUrl("/IT/Lists/Tickers/AllItems.aspx") 
	$spField = $announcementlist.Fields["Open"] 
	$spView.ViewFields.Add($spField) 
	$spField = $announcementlist.Fields["AlertSent"] 
	$spView.ViewFields.Add($spField) 
	$spField = $announcementlist.Fields["AlertSentDate"] 
	$spView.ViewFields.Add($spField) 
	$spView.Update() 
}

$calendarlist = $SPWeb.Lists["EventsCalendar"]
if ($calendarlist -eq $null)
{
	$SPTemplate = $SPWeb.ListTemplates["Calendar"]
	$SPWeb.Lists.Add("EventsCalendar","Calendar List for displaying IT outages on external-internal pages",$SPTemplate)
	$calendarlist = $SPWeb.Lists["EventsCalendar"]
	$calendarlist.ContentTypesEnabled = $true
	$calendarlist.OnQuickLaunch = "True"
	$calendarlist.Update()
}

$footerlist = $SPWeb2.Lists["Footer"]
if ($footerlist -eq $null)
{
	$SPTemplate = $SPWeb2.ListTemplates["Custom List"]
	$SPWeb2.Lists.Add("Footer","Footer List for displaying site footer information",$SPTemplate)
	$footerlist = $SPWeb2.Lists["Footer"]
	$footerlist.ContentTypesEnabled = $true
	$footerlist.OnQuickLaunch = "False"
	$footerlist.Update()
	$footerlist.Fields.Add("FooterUrl", "URL", $true)
	$footerlist.Update()
}

$cmlist = $SPWeb.Lists["ChangeManagement"]
if ($cmlist -eq $null)
{
	Write-Host "Adding Content Management List"
	$SPTemplate = $SPWeb.ListTemplates["Issue Tracking"]
	$SPWeb.Lists.Add("ChangeManagement","Change Management List for displaying change management items.",$SPTemplate)
	$cmlist = $SPWeb.Lists["ChangeManagement"]
	$cmlist.ContentTypesEnabled = $true
	$cmlist.OnQuickLaunch = "True"
	$cmlist.Update()
	$cmlist.Fields.Add("IncidentNumber", "text", $true)
	$cmlist.Fields.Add("OpenDate", "DateTime", $false)
	$cmlist.Fields.Add("CloseDate", "DateTime", $false)
	$cmlist.Update()
	$spView = $spweb.GetViewFromUrl("/IT/Lists/ChangeManagement/AllItems.aspx") 
	$spField = $cmlist.Fields["IncidentNumber"] 
	$spView.ViewFields.Add($spField) 
	$spField = $cmlist.Fields["OpenDate"] 
	$spView.ViewFields.Add($spField) 
	$spField = $cmlist.Fields["CloseDate"] 
	$spView.ViewFields.Add($spField) 
	$spView.Update() 
}

$customlist = $SPWeb.Lists["OutageEmailTemplate"]
if ($customlist -eq $null)
{
	$SPTemplate = $SPWeb.ListTemplates["Custom List"]
	$SPWeb.Lists.Add("OutageEmailTemplate","Email Template for Alerts Webpart",$SPTemplate)
	$customlist = $SPWeb.Lists["OutageEmailTemplate"]
	$customlist.ContentTypesEnabled = $true
	$customlist.OnQuickLaunch = "False"
	$customlist.Update()
	$spFieldMode = [Microsoft.SharePoint.SPRichTextMode]::FullHtml
	$customlist.Fields.Add("EmailTemplate", "Note", $true)
	$customlist.Fields["EmailTemplate"].RichText = $true
	$customlist.Fields["EmailTemplate"].RichTextMode = $spFieldMode
	$customlist.Fields["EmailTemplate"].IsolateStyles = $false
	$customlist.Fields["EmailTemplate"].Update()
	$customlist.Update()
	$customlist.Fields.Add("EmailTo", "text", $true)
	$customlist.Fields.Add("EmailFrom", "text", $true)
	$customlist.Update()
	$spView = $spweb.GetViewFromUrl("/IT/Lists/OutageEmailTemplate/AllItems.aspx") 
	$spField = $customlist.Fields["EmailTemplate"] 
	$spView.ViewFields.Add($spField) 
	$spField = $customlist.Fields["EmailTo"] 
	$spView.ViewFields.Add($spField) 
	$spField = $customlist.Fields["EmailFrom"] 
	$spView.ViewFields.Add($spField) 
	$spView.Update() 
}

$rddoclib = $SPWeb.Lists["ResourceDocuments"]
if ($cmdlist -eq $null)
{
	Write-Host "Adding Resource Documents List"
	$SPTemplate = $SPWeb.ListTemplates["Document Library"]
	$SPWeb.Lists.Add("ResourceDocuments","Change Management List for displaying change management items.",$SPTemplate)
	$rddoclib = $SPWeb.Lists["ResourceDocuments"]
	$rddoclib.ContentTypesEnabled = $true
	$rddoclib.Update()
	$spContentType = $SPWeb2.ContentTypes["WhatsNew"]
	$spContentTypeDocs = $SPWeb2.ContentTypes["Documents"]
	$rddoclib.ContentTypes.Add($spContentType)
	$rddoclib.OnQuickLaunch = "True"
	$rddoclib.Update()
	$rddoclib.ContentTypes.Delete($spContentTypeDocs)
	$rddoclib.Update()
	$spView = $spweb.GetViewFromUrl("/IT/Lists/ResourceDocuments/AllItems.aspx") 
	$spField = $rddoclib.Fields["Sort Order"] 
	$spView.ViewFields.Add($spField) 
	$spField = $rddoclib.Fields["Document Type"] 
	$spView.ViewFields.Add($spField) 
	$spView.Update() 
	Write-Host "add Sort order and document type to display list"
}

Stop-SPAssignment $SPAssignment 
