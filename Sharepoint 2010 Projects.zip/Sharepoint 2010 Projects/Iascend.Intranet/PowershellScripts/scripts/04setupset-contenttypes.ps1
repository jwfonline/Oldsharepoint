﻿$WebAppHostHeader = "st-Iascend-dev"
$WebAppPort = 80
$WebAppUrl = ("http://" + $WebAppHostHeader)
if ($WebAppPort -eq "80")
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader)
}
else
{
	$SiteCollectionURL = ("http://" + $WebAppHostHeader + ":" + $WebAppPort)
}
#Get site and web object
$site = Get-SPSite -Identity $SiteCollectionURL
$sourceWeb = $site.RootWeb 
$xmlFilePath = "C:\0-install\Script-SiteContentTypes.xml"

#Create Site Content Types
$ctsXML = [xml](Get-Content($xmlFilePath))
$ctsXML.ContentTypes.ContentType | ForEach-Object {

    #Create Content Type object inheriting from parent
    $spContentType = New-Object Microsoft.SharePoint.SPContentType ($_.ID,$sourceWeb.ContentTypes,$_.Name)
	$ctname = $_.Name
    Write-Host	$_.ID $_.Name $_.Group
    #Set Content Type description and group
    $spContentType.Group = $_.Group

    $_.Fields.Field  | ForEach-Object {
	    if ($_.Name -eq "SortOrder")
		{
			$fieldvar = $sourceWeb.Fields["Sort Order"]
		}
		elseif ($_.Name -eq "DocumentType")
		{
			$fieldvar = $sourceWeb.Fields["Document Type"]
		}
		else
		{
			$fieldvar = $_.Name
		}
        if(!$spContentType.FieldLinks[$fieldvar])
        {
		    write-host "Adding content type column:" $fieldvar
            #Create a field link for the Content Type by getting an existing column
            $spFieldLink = New-Object Microsoft.SharePoint.SPFieldLink ($fieldvar)
        
            #Check to see if column should be Optional, Required or Hidden
            if ($_.Required -eq "TRUE") {$spFieldLink.Required = $true}
            if ($_.Hidden -eq "TRUE") {$spFieldLink.Hidden = $true}
        
            #Add column to Content Type
            $spContentType.FieldLinks.Add($spFieldLink)
			
        }
    }
    
    #Create Content Type on the site and update Content Type object
	if (!$sourceWeb.ContentTypes[$_.Name])
	{
	    write-host "Content type" $ct.Name "has been created"
		$ct = $sourceWeb.ContentTypes.Add($spContentType)
	}
    $spContentType.Update()
}

$sourceWeb.Dispose()


