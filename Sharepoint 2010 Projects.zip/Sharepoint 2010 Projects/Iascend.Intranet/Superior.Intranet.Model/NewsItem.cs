﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class NewsItem
    {
        #region Properties
        public string ID { get; set; }
        public string Headline { get; set; }
        public string ShortDescription { get; set; }
        public string FullDescription { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime PublishDate { get; set; }
        public bool DisplayInWebpart { get; set; }
        public string ImageURL { get; set; }
        #endregion
    }
}
