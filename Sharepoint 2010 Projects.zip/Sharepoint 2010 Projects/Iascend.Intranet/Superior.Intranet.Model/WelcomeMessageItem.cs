﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all videos
    /// </summary>
    [DataContract(Name = "WelcomeMessage")]
    [Serializable]
    public partial class WelcomeMessageItem
    {
        #region Public Properties

        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string welcomeMessage { get; set; }
        [DataMember]
        public string ImageURL { get; set; }

        #endregion
    }
}
