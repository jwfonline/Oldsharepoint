﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Photo Item
    /// </summary>
    [Serializable]
    public class PhotoItem
    {
        #region [properties]

        private string _ImageUrl = "";
        private string _PreviewUrl = "";
        private string _ThumbnailUrl = "";
        private double _DisplayOrder;

        #endregion

        #region [Accessor Methods]

        /// <summary>
        /// File Name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Display On Home Page
        /// </summary>
        public bool DisplayOnHomepage { get; set; }

        /// <summary>
        /// Comment
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// Author
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        /// Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Display Order
        /// </summary>
        public double DisplayOrder { get; set; }

        
        /// <summary>
        /// Preview Url
        /// </summary>
        public string PreviewUrl
        {
            get
            {
                return _PreviewUrl;
            }
        }

        /// <summary>
        /// Thumbnail Url
        /// </summary>
        public string ThumbnailUrl
        {
            get
            {
                return _ThumbnailUrl;
            }
        }

        /// <summary>
        /// Image Url
        /// </summary>
        public string ImageUrl
        {
            get
            {
                return _ImageUrl;
            }
            set
            {
                _ImageUrl = value;
                StringBuilder _strThumImage = new StringBuilder();
                _strThumImage.Append(_ImageUrl.Substring(0, _ImageUrl.LastIndexOf("/")));
                _strThumImage.Append("/_t");
                _strThumImage.Append(_ImageUrl.Substring(_ImageUrl.LastIndexOf("/"), (_ImageUrl.LastIndexOf(".") - _ImageUrl.LastIndexOf("/"))));
                _strThumImage.Append("_");
                _strThumImage.Append(_ImageUrl.Substring(_ImageUrl.LastIndexOf(".") + 1, ((_ImageUrl.Length - 1) - _ImageUrl.LastIndexOf("."))));
                _strThumImage.Append(".jpg");
                _PreviewUrl = _strThumImage.ToString();

                //Changes the tag _t with _w for the medium size image
                _ThumbnailUrl = _strThumImage.ToString().Replace("/_t/", "/_w/");
            }
        }

        #endregion
    }
}
