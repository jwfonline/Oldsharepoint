﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for Ticker Item.
    /// </summary>
    [Serializable()]
    public class TickerItem
    {
        
        #region Properties

        public string URL { get; set; }
        public string Title { get; set; }
        public string DisplayText { get; set; }

        #endregion
    }
}
