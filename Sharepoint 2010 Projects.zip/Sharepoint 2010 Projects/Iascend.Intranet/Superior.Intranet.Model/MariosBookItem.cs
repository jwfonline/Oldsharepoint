﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all videos
    /// </summary>
    [DataContract(Name = "MariosBookItem")]
    [Serializable]
    public partial class MariosBookItem
    {
        #region Public Properties

        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string author { get; set; }
        [DataMember]
        public string imageUrl { get; set; }
        [DataMember]
        public string published { get; set; }
        [DataMember]
        public DateTime created { get; set; }

        #endregion
    }
}
