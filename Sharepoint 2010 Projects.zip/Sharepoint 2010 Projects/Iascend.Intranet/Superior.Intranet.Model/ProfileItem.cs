﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// This CS Wrapper class provides access to a user's profile.  It allows one to update/set/get user properties
    /// inclduing email, password, addreses, credit cards, bank accounts, etc.
    /// </summary>
    [DataContract(Name="UserProfile")]
    [Serializable]
    public partial class ProfileItem
    {
        #region Public Properties

        [DataMember]
        public Guid UserId { get; set; }
        [DataMember]
        public string UserName { get; set; }
        [DataMember]
        public string UserEmail { get; set; }
        [DataMember]
        public string UserPassword { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public List<AddressItem> Addresses { get; set; }
        [DataMember]
        public string PreferredAddressName { get; set; }
        [DataMember]
        public string PreferredCreditCardName { get; set; }
        [DataMember]
        public bool IsRegisteredUser { get; set; }
        [DataMember]
        public string PhoneNumber { get; set; }
        [DataMember]
        public DateTime DateRegistered { get; set; }
        [DataMember]
        public bool ChangePasswordAllowed { get; set; }
        [DataMember]
        public DateTime? DateOfBirth {get;set;}
        [DataMember]
        public bool IsOnMonthlyEmailList { get; set; }
        
        #endregion
    }
}
