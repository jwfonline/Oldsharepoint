﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all the meta data for an article
    /// </summary>
    [DataContract]
    [Serializable]
    public partial class AnnouncementItem
    {
        #region [Public Properties]

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Description { get; set; }
        
        [DataMember]
        public Guid Id { get; set; }
        
        #endregion

        /// <summary>
        /// Constructor logic
        /// </summary>
        public AnnouncementItem()
        {
            this.Id = Guid.NewGuid();
        }
    }
}