﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
     [Serializable()]
   public class StoryItem
    {
        #region Properties
        
        public string Story { get; set; }
        public int ID { get; set; }
       
        #endregion
    }
}
