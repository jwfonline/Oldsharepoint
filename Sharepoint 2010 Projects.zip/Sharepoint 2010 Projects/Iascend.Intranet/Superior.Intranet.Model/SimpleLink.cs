﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Runtime.Serialization;

using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// This class is a wrapper for SharePoint's Simple HyperLink item.
    /// http://www.google.com, Title
    /// </summary>
    [DataContract]
    [Serializable]
    public class SimpleLink
    {
        #region [Public Properties ]

        [DataMember]
        public string HtmlTag { get; set; }
        [DataMember]
        public string DisplayText { get; set; }
        [DataMember]
        public string Url { get; set; }

        #endregion

        #region [Constructors]

        /// <summary>
        /// Simple Link
        /// </summary>
        public SimpleLink()
        {
            HtmlTag = DisplayText = Url = String.Empty;
        }

        /// <summary>
        /// Simple Link
        /// </summary>
        /// <param name="tag"></param>
        public SimpleLink(string tag)
        {
            this.HtmlTag = tag;

            if (!tag.IsNullEmptyOrEmptySpaces())
            {
                List<string> split = tag.ParseSPHyperlinkList();
                Url = (split.Count > 0) ? split[0] : String.Empty;
                DisplayText = (split.Count > 1) ? split[1] : String.Empty;
            }
        }
        
        #endregion

        #region Override Methods

        /// <summary>
        /// To String
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return HtmlTag;
        }

        #endregion 
    }
}
