﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class IndexTabItem : KpiItem
    {
        public string Source { get; set; }
    }
}
