﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class FootnoteItem
    {
        public string Title { get; set; }
        public string Category { get; set; }
    }
}
