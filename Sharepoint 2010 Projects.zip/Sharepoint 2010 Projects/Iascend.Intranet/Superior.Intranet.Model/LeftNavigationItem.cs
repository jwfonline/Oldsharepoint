﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    [DataContract]
    [Serializable]
    public class LeftNavigationItem
    {
        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Url { get; set; }

        [DataMember]
        public string Category { get; set; }

        // NewWindow is a string data type because sharepoint is return a string for yes/no data field.
        [DataMember]
        public string NewWindow { get; set; }
    }
}
