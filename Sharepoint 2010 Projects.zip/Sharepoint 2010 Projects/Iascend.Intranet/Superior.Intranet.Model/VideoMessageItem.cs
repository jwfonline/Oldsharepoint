﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class VideoMessageItem
    {
        public string Title { get; set; }
        public string FileName { get; set; }
        public string AlternateThumbnailUrl { get; set; }
        public string ShortDescription { get; set; }
        public string FullDescription { get; set; }
        public string VideoURL { get; set; }
        public Int32 VideoHeightInPixels { get; set; }
        public Int32 VideoWidthInPixels { get; set; }
        public bool DisplayOnHomepage { get; set; }

    }
}
