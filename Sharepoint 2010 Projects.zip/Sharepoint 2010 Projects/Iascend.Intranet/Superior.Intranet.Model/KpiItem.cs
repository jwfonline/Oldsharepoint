﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class KpiItem
    {
        public string Title { get; set; }
        public string Location { get; set; }
        public string CurrentPeriod { get; set; }
        public string PriorPeriod { get; set; }
        public string PercentageChanged { get; set; }
        public string DirectionalImage { get; set; }
    }
}
