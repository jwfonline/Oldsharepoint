﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Iascend.Intranet.Model
{
    [Serializable()]
   public class ImageRotatorItem
    {
        #region Properties

        public string altText { get; set; }
        public string src { get; set; }
        public  string imgUrl { get; set; }
        public string link { get; set; }
        public int ID { get; set; }

        #endregion
    }
}
