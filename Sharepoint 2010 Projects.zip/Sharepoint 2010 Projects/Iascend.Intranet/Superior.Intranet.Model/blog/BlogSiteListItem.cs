﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Interface.Model;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for BlogSiteListItem.
    /// </summary>
    [Serializable()]
    public class BlogSiteListItem
    {
        #region Properties

        public string SiteName { get; set; }
        public string Title { get; set; }
        public string BlogUrl { get; set; }

        #endregion
    }
}
