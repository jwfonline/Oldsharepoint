﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Interface.Model;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for BlogItem.
    /// </summary>
    [Serializable()]
    public class BlogPostItem
    {
        #region Properties

        public string SiteName { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public string BlogUrl { get; set; }
        public string BlogListUrl { get; set; }
        public string NumComments { get; set; }
        public string PostCategory { get; set; }
        public DateTime PublishedDate { get; set; }
        public string VideoPictureTitle { get; set; }
        public string VideoPictureUrl { get; set; }
        public string FeaturedBlog { get; set; }
        public string Author { get; set; }
        public string AuthorProfileUrl { get; set; }
        public string AuthorPictureUrl { get; set; }
        public string AuthorDisplayName { get; set; }
        public int PostID { get; set; }
        public string AssignedTeam { get; set; }
        public string AssignedClient { get; set; }

        #endregion
    }
}
