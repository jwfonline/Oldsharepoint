﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Interface.Model;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for BlogPostMediaItem.
    /// </summary>
    [Serializable()]
    public class BlogPostMediaItem
    {
        #region Properties

        public string URL { get; set; }
        public string Title { get; set; }

        #endregion
    }
}
