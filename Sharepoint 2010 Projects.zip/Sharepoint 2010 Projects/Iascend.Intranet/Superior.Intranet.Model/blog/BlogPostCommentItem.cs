﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Interface.Model;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for BlogPostCommentItem.
    /// </summary>
    [Serializable()]
    public class BlogPostCommentItem
    {
        #region Properties
        public string Title { get; set; }
        public string Body { get; set; }
        public string CommentUrl { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Author { get; set; }
        public string AuthorProfileUrl { get; set; }
        public string AuthorPictureUrl { get; set; }
        public string AuthorDisplayName { get; set; }
        #endregion
    }
}
