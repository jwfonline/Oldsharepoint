﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.Serialization;
namespace Iascend.Intranet.Model
{
    [DataContract(Name = "MariosWelcomeMessage")]
    [Serializable]
    public class MariosWelcomeMessageItem: WelcomeMessageItem
    {
        [DataMember]
        public string SignatureURL { get; set; }
    }
}
