﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    public class LinksListItem
    {
        #region Properties

        public string URL { get; set; }
        public string DisplayText { get; set; }

        #endregion
    }
}
