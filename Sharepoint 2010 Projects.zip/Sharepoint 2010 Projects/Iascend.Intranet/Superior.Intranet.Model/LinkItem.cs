﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all the meta data for an article
    /// </summary>
    [DataContract]
    [Serializable]
    public partial class LinkItem
    {
        #region Public Properties

        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public SimpleLink Url { get; set; }

        #endregion
    }
}