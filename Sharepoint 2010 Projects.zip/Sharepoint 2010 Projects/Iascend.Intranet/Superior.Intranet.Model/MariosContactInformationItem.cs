﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all videos
    /// </summary>
    [DataContract(Name = "WelcomeMessage")]
    [Serializable]
    public partial class MariosContactInformationItem
    {
        #region Public Properties

        [DataMember]
        public string emailAddress { get; set; }
        [DataMember]
        public string officePhone { get; set; }
        [DataMember]
        public string mobilePhone { get; set; }

        #endregion
    }
}
