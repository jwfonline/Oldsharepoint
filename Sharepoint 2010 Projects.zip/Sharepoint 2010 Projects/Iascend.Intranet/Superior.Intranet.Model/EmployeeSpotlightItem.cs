﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class EmployeeSpotlightItem
    {
        #region Properties
        public string EmployeeName { get; set; }
        public string EmployeePictureURL { get; set; }
        public string EmployeeEmail { get; set; }
        public string Headline { get; set; }
        public string ShortDescription { get; set; }
        public string FullDescription { get; set; }
        public bool CurrentSpotlight { get; set; }
        #endregion




    }
}
