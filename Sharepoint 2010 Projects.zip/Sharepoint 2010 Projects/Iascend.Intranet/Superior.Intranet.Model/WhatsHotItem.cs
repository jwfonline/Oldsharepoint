﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Interface.Model;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for WhatsHotItem.
    /// </summary>
    [Serializable()]
    public class WhatsHotItem
    {
        #region Properties

        public string Title { get; set; }
        public string Description { get; set; }
        public string Link { get; set; }
        public string LinkTitle { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Author { get; set; }
        public string AuthorProfileUrl { get; set; }
        public string AuthorPictureUrl { get; set; }
        public string AuthorDisplayName { get; set; }

        #endregion
    }
}
