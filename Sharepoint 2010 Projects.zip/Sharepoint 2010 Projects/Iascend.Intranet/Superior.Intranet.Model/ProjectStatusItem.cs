﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Project Status Item
    /// </summary>
    [Serializable()]
    public class ProjectStatusItem
    {
        #region [Properties]

        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime PlannedStartDate { get; set; }
        public DateTime EstimatedCompletionDate { get; set; }
        public string ProjectManager { get; set; }
        public Double ProjectPercentageComplete { get; set; }
        public Int32 ID { get; set; }

        #endregion
    }
}
