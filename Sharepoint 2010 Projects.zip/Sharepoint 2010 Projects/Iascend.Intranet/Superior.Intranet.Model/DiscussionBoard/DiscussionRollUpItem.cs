﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Model
{
    [DataContract(Name = "DiscussionRollUpItem")]
    [Serializable]
    public partial class DiscussionRollUpItem
    {
        [DataMember]
        public string Title { get; set; }
    }
}
