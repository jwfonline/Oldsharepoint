﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class DiscussionItem
    {
        public string Author { get; set; }
        public DateTime Created { get; set; }
        public string Subject { get; set; }
        public int Replies { get; set; }
    }
}
