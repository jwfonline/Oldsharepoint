﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    [Serializable]
    public class DiscussionBoardItem
    {
        public double DisplayOrder { get; set; }
        public string ImageURL { get; set; }
        public string BoardURL { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int PostCount { get; set; }
        public string LastPostSubject { get; set; }
        public string LastPostMonth { get; set; }
        public string LastPostAuthor { get; set; }
        public string PostURL { get; set; }

    }
}
