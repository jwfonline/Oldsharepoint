﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Runtime.Serialization;

using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// This class is a wrapper for SharePoint's Simple HyperLink item.
    /// http://www.google.com, Title
    /// </summary>
    [DataContract(Name = "SharePointImage")]
    [Serializable]
    public class PictureLibraryImage
    {
        #region Public Properties

        [DataMember]
        public string SmallUrl { get; set; }
        [DataMember]
        public string MediumUrl { get; set; }
        [DataMember]
        public string NormalUrl { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Picture Library Image
        /// </summary>
        /// <param name="tag"></param>
        public PictureLibraryImage(string tag)
        {
            if (tag != null)
            {
                SimpleLink link = new SimpleLink(tag);

                this.NormalUrl = link.Url;
                //This black inserts the tag /_t/ , change the file type to .jpg and change the name of the picure to Name_Ext. The format of Thumbnail image from sharepoint.
                this.NormalUrl = link.Url;
                StringBuilder _strThumImage = new StringBuilder();
                _strThumImage.Append(link.Url.Substring(0, link.Url.LastIndexOf("/")));
                _strThumImage.Append("/_t");
                _strThumImage.Append(link.Url.Substring(link.Url.LastIndexOf("/"), (link.Url.LastIndexOf(".") - link.Url.LastIndexOf("/"))));
                _strThumImage.Append("_");
                _strThumImage.Append(link.Url.Substring(link.Url.LastIndexOf(".") + 1, ((link.Url.Length - 1) - link.Url.LastIndexOf("."))));
                _strThumImage.Append(".jpg");
                this.SmallUrl = _strThumImage.ToString();

                //Changes the tag _t with _w for the medium size image
                this.MediumUrl = _strThumImage.ToString().Replace("/_t/", "/_w/");
            }
        }

        #endregion 
    }
}
