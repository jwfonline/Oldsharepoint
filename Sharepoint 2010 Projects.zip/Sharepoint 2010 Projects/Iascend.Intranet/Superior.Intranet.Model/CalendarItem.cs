﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for CalendarItem.
    /// </summary>
    [Serializable()]
    public class CalendarItem
    {
        #region Properties
        public DateTime EndDate { get; set; }
        public string ID { get; set; }
        public string Title { get; set; }
        public DateTime EventDate { get; set; }        
        public string Location { get; set; }
        public string URL { get; set; }
        #endregion
    }
}
