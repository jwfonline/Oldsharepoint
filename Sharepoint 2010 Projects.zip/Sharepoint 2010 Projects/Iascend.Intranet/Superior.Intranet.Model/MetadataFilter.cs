﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Model to store all posible values from a metadata field 
    /// </summary>
    [DataContract(Name = "MetadataFilter")]
    [Serializable]
    public partial class MetadataFilter
    {
        #region Public Properties
        [DataMember]
        public string FieldName { get; set; }
        [DataMember]
        public List<string> Values { get; set; }
        #endregion
    }
}