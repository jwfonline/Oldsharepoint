﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for ApplinkLinksItem.
    /// </summary>
    [Serializable()]
    public class AppLinksItem: LinksListItem
    {
       
    }
}
