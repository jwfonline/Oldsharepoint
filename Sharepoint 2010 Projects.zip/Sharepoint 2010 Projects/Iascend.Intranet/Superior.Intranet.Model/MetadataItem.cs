﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for MetadataItem.
    /// </summary>
    [Serializable()]
    public class MetadataItem
    {
        #region Properties

        public string ClientUrl { get; set; }
        public string AssignedTeam { get; set; }
        public string AssignedBrand { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string AccountLeadName { get; set; }
        public string AccountLeadEmail { get; set; }
        public string AccountLeadPhone { get; set; }
        public string ClientContactName { get; set; }
        public string ClientContactEmail { get; set; }
        public string ClientContactPhone { get; set; }

        #endregion
    }
}
