﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Model
{
    /// <summary>
    /// Class file for QuickLinksItem.
    /// </summary>
    [Serializable()]
    public class QuickLinksItem: LinksListItem
    {
        
    }
}
