﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Iascend.Intranet.Webparts;
using Microsoft.SharePoint.WebPartPages;
using Iascend.Intranet.Enums.Enumerations;

namespace Iascend.Intranet.Webparts.RandomStoryRotater
{
    /// <summary>
    /// Options to determine the rotation behavior.
    /// </summary>
    public enum RotationOption
    {
        /// <summary>
        /// Display one random Story on page load.
        /// </summary>
        Random,
        /// <summary>
        /// Cycle through multiple Story without forcing the user to refresh their browser.
        /// </summary>
        Slider
    }
    [ToolboxItemAttribute(false)]
    public class RandomStoryRotater : System.Web.UI.WebControls.WebParts.WebPart
    {
        [
        Personalizable(PersonalizationScope.Shared),
        Browsable(true),
        Category("Iascend Settings"),
        DefaultValue(""),
        WebPartStorage(Storage.Shared),
        FriendlyName("Rotation"),
        Description("Options to determine the rotation behavior."),
        WebBrowsable(true),
        WebDisplayName("Rotation"),
        WebDescription("Options to determine the rotation behavior.")
       ]
        public RotationOption Rotation { get; set; }

        [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("List Site"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("List Site"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public string ListSite { get; set; }

        [
            Personalizable(PersonalizationScope.Shared),
            Browsable(true),
            Category("Iascend Settings"),
            DefaultValue(""),
            WebPartStorage(Storage.Shared),
            FriendlyName("List Name"),
            Description("Name of the List to pull from"),
            WebBrowsable(true),
            WebDisplayName("List Name"),
            WebDescription("Name of the List to pull from")
        ]
        public string ListName { get; set; }



        [
           Personalizable(PersonalizationScope.Shared),
           Browsable(true),
           Category("Iascend Settings"),
           DefaultValue(""),
           WebPartStorage(Storage.Shared),
           FriendlyName("Keep Story(Number of days)"),
           Description("Keep the same story for selected number of days"),
           WebBrowsable(false),
           WebDisplayName("Keep Story(Number of days)"),
           WebDescription("Keep the same story for selected number of days")
       ]
        public int StoryDays { get; set; }

        [
      Personalizable(PersonalizationScope.Shared),
      Browsable(true),
      Category("Iascend Settings"),
      DefaultValue(""),
      WebPartStorage(Storage.Shared),
      FriendlyName("Random Story"),
      Description("Picks a random story"),
      WebBrowsable(false),
      WebDisplayName("Random Story"),
      WebDescription("Picks a random story")
     ]
        public bool Random { get; set; }

         [
      Personalizable(PersonalizationScope.Shared),
      Browsable(false),
        WebPartStorage(Storage.Shared)
     ]
      public int storyId
        { get; set; }


         [
      Personalizable(PersonalizationScope.Shared),
      Browsable(false),
        WebPartStorage(Storage.Shared)
     ]
         public DateTime StoryDisplayDate
         { get; set; }
        
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
         private const string _ascxPath = @"~/_CONTROLTEMPLATES/Iascend.Intranet.Webparts/RandomStoryRotater/RandomStoryRotaterUserControl.ascx";

        protected override void CreateChildControls()
        {
            RandomStoryRotaterUserControl control = (RandomStoryRotaterUserControl) Page.LoadControl(_ascxPath);
            if (control != null)
            {
                //this always us to set the webpart properties
                control.WebPart = this;
            }
            Controls.Add(control);
        }
    }
}
