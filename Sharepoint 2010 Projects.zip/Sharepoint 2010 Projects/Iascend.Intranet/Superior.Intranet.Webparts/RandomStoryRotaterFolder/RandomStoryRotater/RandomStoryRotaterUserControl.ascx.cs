﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Linq;

using System.Globalization;
using System.Collections.Generic;
using System.Text;

using Iascend.Intranet.Model;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Business;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.EnumsAndConstants;
using Iascend.Intranet.Framework.Logging;


using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace Iascend.Intranet.Webparts.RandomStoryRotater
{
    public partial class RandomStoryRotaterUserControl : UserControl
    {
        
        public string ListSite
        { get; set; }
        public string ListName
        { get; set; }
        //picks a random story
        public bool Random
        { get; set; }
        //number of days to display a story
        public int StoryDays
        { get; set; }
        //date a story gets displayed
        private DateTime StoryDisplayDate
        { get; set; }



        //private int _storyID;

        public int storyId
        { get; set; }

        public int oldstoryId
        { get; set; }


        /// <summary>
        /// Gets or sets the selected date.
        /// </summary>
        /// <value>The selected date.</value>
        //public DateTime SelectedDate
        // {
        //get
        //{
        //    if (ViewState["SelectedDate"] == null) ViewState["SelectedDate"] = DateTime.Now;

        //    return (DateTime)ViewState["SelectedDate"];
        //}

        //set { ViewState["SelectedDate"] = value; }
        // }

        public RandomStoryRotater WebPart { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (this.WebPart != null)
            {
                this.ListSite = this.WebPart.ListSite;
                this.ListName = this.WebPart.ListName;
                this.Random = this.WebPart.Random;
                this.StoryDays = this.WebPart.StoryDays;
                this.storyId = this.WebPart.storyId;
                this.WebPart.Random = true;
            }

            long displaydaynumber = StoryDisplayDate.AddDays(this.StoryDays).Date.Ticks;
            ////if the displaydaynumber = today then get a new article
            //if (displaydaynumber == DateTime.Now.Date.Ticks)
            //{
            //    StoryDisplayDate = DateTime.Now.Date;
            //    oldstoryId = this.storyId;
            //    this.storyId = 0;
            //}

            // if (this.storyId != 0)
            //{
            //    Literal1.Text = GetStorybyId();
            //}
            //else
            //{
            if (this.ListName != null)
                Literal1.Text = GetStory();
            //}

            StringBuilder sb = new StringBuilder();

            if (ListSite != null && ListSite != string.Empty)
            {
                ListSite = ListSite.Trim('/');
                //  sb.Append("~/");
                sb.Append(ListSite);

            }
            else
            {
                ListSite = SPContext.Current.Web.Url.Trim('/');
                sb.AppendFormat("{0}", SPContext.Current.Web.Url); //SPContext.Current.Site.Url
            }


            // sb.Append(ListSite);

            sb.AppendFormat("/Lists/{0}", ListName);

            this.lnkFullStory.NavigateUrl = sb.ToString();


        }


        private string GetStory()
        {
            string StoryString = "";
            List<StoryItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.ListSite == string.Empty || this.ListSite == null)
            {
                items = RandomStoryRotaterManager.GetStory(SPContext.Current.Web.Url, this.ListName);
            }
            else
            {
                items = RandomStoryRotaterManager.GetStory(this.ListSite, this.ListName);
            }
            //make random equal true we can change if we add the property back to we part properties
            Random = true;

            //dispaly a random story
            if (Random == true)
            {
                items = (List<StoryItem>)items.Shuffle();
            }
            if (items.Count > 0)
            StoryString = items[0].Story;

            //int itemindex = 0;
            ////this is nasty clean up later
            //foreach (var item in items)
            //{
            //    itemindex += 1;
            //    if (item.ID == oldstoryId)
            //    {
            //        //if you reach the last index start from begingning
            //        if (itemindex > items.Count)
            //            itemindex = 0;
            //        break;
            //    }

            //}

            //// if story days is sent setup properties to manage it
            //if (StoryDays != 0)
            //{
            //    StoryDisplayDate = DateTime.Now.Date;
            //    this.WebPart.storyId = items[itemindex].ID;
            //    this.WebPart.StoryDisplayDate = this.StoryDisplayDate;
            //    SavewebpartProperties();
            //}
            //if (oldstoryId != 0)
            //{
            //    StoryString = items[itemindex].Story;
            //}
            //else
            //{
            //    StoryString = items[0].Story;
            //}

            return StoryString;
        }

        private string GetStorybyId()
        {
            string StoryString = "";
            List<StoryItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.ListSite == string.Empty)
            {
                items = RandomStoryRotaterManager.GetStoryByID(SPContext.Current.Web.Url, this.ListName, storyId);
            }
            else
            {
                items = RandomStoryRotaterManager.GetStoryByID(this.ListSite, this.ListName, storyId);
            }


            StoryString = items[0].Story;
            return StoryString;
        }

        private bool SavewebpartProperties()
        {
            string weburl;
         
                weburl = SPContext.Current.Web.Url;
           


            using (SPSite spSiteTest = new SPSite(weburl))
            {

                using (SPWeb spWebTest = spSiteTest.OpenWeb())
                {
                    string pagename = System.Web.HttpContext.Current.Request.Path.Split('/').Last();
                    SPLimitedWebPartManager webpartmanager = spWebTest.GetLimitedWebPartManager(System.Web.HttpContext.Current.Request.Path, PersonalizationScope.Shared);

                    foreach (System.Web.UI.WebControls.WebParts.WebPart wp in webpartmanager.WebParts)
                    {
                        //get reference to webpart
                        //Microsoft.SharePoint.WebPartPages.WebPart weppartsm = webpartmanager[k];

                        //check webpart Title to find webpart whose value is to be changed
                        if (wp.Title == this.WebPart.Title)
                        {
                            //wp = (Iascend.Intranet.Webparts.RandomStoryRotater.RandomStoryRotater)wp;
                            ////set new property values of the webpart object
                            //wp.storyId = this.WebPart.storyId;
                            ////Call SaveChanges method of SPWebPartCollection object
                            //webpartmanager.SaveChanges(wp);

                            //update spWeb object 
                           // spWebTest.Update();
                           
                        }
 
                    }
return true;
                }
            }

        }


    }
}

