﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Collections.Generic;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.Office.Server.SocialData;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Model;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.WebProject.WebParts.WhatsHotWebPart
{
    public partial class WhatsHotWebPartUserControl : UserControl
    {
        private int _NumberOfItems;
        public int NumberOfItems
        {
            get { return _NumberOfItems; }
            set { _NumberOfItems = value; }
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {

                    BindData();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Write(ex.ToString());
                    ULSLogHelper.LogErrorMessage("Failed to load Current Events", ex.ToString());
                }
            }
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindData()
        {
            //Get List of What's Hot Items
            List<WhatsHotItem> items = Iascend.Intranet.Manager.WebPartManager.GetAllWhatsHotItems(Locales.English);

            if (NumberOfItems > 0)
                items = items.Take(NumberOfItems).ToList<WhatsHotItem>();

            rptWhatsHotItems.DataSource = items;
            rptWhatsHotItems.DataBind();

        }


        public bool ShowReadMore(object oWhatsHotItem)
        {
            WhatsHotItem i = (WhatsHotItem)oWhatsHotItem;

            return !String.IsNullOrEmpty(i.Link);
        }


        public string GetDescription(object oWhatsHotItem)
        {
            WhatsHotItem i = (WhatsHotItem)oWhatsHotItem;

            return i.Description.StripHTML();
        }
    }
}
