﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace Iascend.Intranet.WebProject.WebParts.WhatsHotWebPart
{
    [ToolboxItemAttribute(false)]
    public class WhatsHotWebPart : System.Web.UI.WebControls.WebParts.WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/Iascend.Intranet.WebProject.WebParts/WhatsHotWebPart/WhatsHotWebPartUserControl.ascx";

        protected override void CreateChildControls()
        {
            WhatsHotWebPartUserControl control = (WhatsHotWebPartUserControl)Page.LoadControl(_ascxPath);
            control.NumberOfItems = this.NumberOfItems;
            Controls.Add(control);
        }

        [WebBrowsable]
        [WebDisplayName("Number of Items")]
        [WebDescription("Number of Items")]
        [Personalizable(PersonalizationScope.Shared)]
        [WebPartStorage(Storage.Shared)]
        [DefaultValue(10)]
        public int NumberOfItems
        {
            get;
            set;
        }

    }
}
