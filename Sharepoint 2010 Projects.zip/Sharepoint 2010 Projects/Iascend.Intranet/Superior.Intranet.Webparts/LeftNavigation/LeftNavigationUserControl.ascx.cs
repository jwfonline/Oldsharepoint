﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Collections.Generic;
using Iascend.Intranet.Model;
using Iascend.Intranet.Business;
using System.Linq;

namespace Iascend.Intranet.Webparts.LeftNavigation
{
    public partial class LeftNavigationUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadLeftNavigation();
            }
        }

        private void LoadLeftNavigation()
        {

            List<LeftNavigationItem> links = LeftNavigationManager.GetLeftNavigationItems();

            BindDocumentLinks(links);
            BindReportsLinks(links);
            BindApplicationLinks(links);
            BindrptOurTeamLinks(links);

        }

        private void BindDocumentLinks(List<LeftNavigationItem> links)
        {

            try
            {
                List<LeftNavigationItem> items = links.Where(l => l.Category == "Documents").ToList();
                rptDocuments.DataSource = items;
                rptDocuments.DataBind();
            }
            catch
            {
                rptDocuments.DataSource = new List<LeftNavigationItem>();
                rptDocuments.DataBind();
            }

        }

        private void BindReportsLinks(List<LeftNavigationItem> links)
        {

            try
            {
                List<LeftNavigationItem> items = links.Where(l => l.Category == "Reports").ToList();
                rptReports.DataSource = items;
                rptReports.DataBind();
            }
            catch
            {
                rptReports.DataSource = new List<LeftNavigationItem>();
                rptReports.DataBind();
            }


        }

        private void BindApplicationLinks(List<LeftNavigationItem> links)
        {
            try
            {

                List<LeftNavigationItem> items = links.Where(l => l.Category == "Application Links").ToList();
                rptApplicationLinks.DataSource = items;
                rptApplicationLinks.DataBind();
            }
            catch
            {
                rptApplicationLinks.DataSource = new List<LeftNavigationItem>();
                rptApplicationLinks.DataBind();
            }

        }

        private void BindrptOurTeamLinks(List<LeftNavigationItem> links)
        {
            try
            {
                List<LeftNavigationItem> items = links.Where(l => l.Category == "Our Team").ToList();
                rptOurTeam.DataSource = items;
                rptOurTeam.DataBind();
            }
            catch
            {
                rptOurTeam.DataSource = new List<LeftNavigationItem>();
                rptOurTeam.DataBind();
            }

        }

        public string RenderLinkItem(object link)
        {
            string result = String.Empty;

            LeftNavigationItem item = link as LeftNavigationItem;
            if (item != null)
            {
                if (!String.IsNullOrEmpty(item.NewWindow) && item.NewWindow.Trim() == "1")
                {
                    result = "<li><a target='_blank' href='" + item.Url + "'>" + item.Title + "</a></li>";
                }
                else
                {
                    result = "<li><a href='" + item.Url + "'>" + item.Title + "</a></li>";
                }
            }

            return result;
        }
    }
}
