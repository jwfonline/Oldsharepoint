﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

using Iascend.Intranet.Model;
using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.WebParts.BLPListWebPart
{
    public partial class BLPListWebPartUserControl : UserControl
    {
        private const int PostsPerPage = 3;

        private int RowCount
        {
            get
            {
                if (ViewState["RowCount"] == null) return 0;
                return (int)ViewState["RowCount"];
            }
            set
            {
                ViewState["RowCount"] = value;
            }
        }

        private string ClientName
        {
            get
            {
                if (ViewState["ClientName"] == null) return "";
                return (string)ViewState["ClientName"];
            }
            set
            {
                ViewState["ClientName"] = value;
            }
        }
        
        private string TeamName
        {
            get
            {
                if (ViewState["TeamName"] == null) return "";
                return (string)ViewState["TeamName"];
            }
            set
            {
                ViewState["TeamName"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["TeamName"] != null)
                    TeamName = Request.QueryString["TeamName"].ToString();

                if (Request.QueryString["ClientName"] != null)
                    ClientName = Request.QueryString["ClientName"].ToString();

                BindData(PostsPerPage, 0);
            }
            else
            {
                CreatePagingControl();
            }
        }

        private void CreatePagingControl()
        {
            Dictionary<int, int> Pages = new Dictionary<int, int>();

            for (int i = 0; i < (RowCount / PostsPerPage) + 1; i++)
            {

                Pages.Add(i, i + 1);
            }

            rptPager.DataSource = Pages;
            rptPager.DataBind();

        }

        protected void ChangePage_Click(object sender, EventArgs e)
        {
            LinkButton lnk = sender as LinkButton;
            int currentPage = int.Parse(lnk.Text);
            int take = currentPage * PostsPerPage;
            int skip = currentPage == 1 ? 0 : take - PostsPerPage;
            BindData(take, skip);
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindData(int take, int pageSize)
        {
            //Get List of Blog Posts
            List<BlogPostItem> items = new List<BlogPostItem>();

            if (TeamName.Length > 0)
            {
                items = Iascend.Intranet.Business.BlogManager.GetAllBlogPostItems(TeamName);
            }
            else if (ClientName.Length > 0)
            {
                var posts = Iascend.Intranet.Business.BlogManager.GetAllBlogPostItems();

                items = posts.Where(bpi => bpi.AssignedClient == ClientName).ToList<BlogPostItem>();
            }
            else
            {
                items = Iascend.Intranet.Business.BlogManager.GetAllBlogPostItems();
            }

            var query = from i in items
                       .OrderByDescending(o => o.PublishedDate)
                       .Take(take)
                       .Skip(pageSize)
                        select i;

            PagedDataSource page = new PagedDataSource();
            page.AllowCustomPaging = true;
            page.AllowPaging = true;
            page.DataSource = query;
            page.PageSize = PostsPerPage;

            rptBlogEntries.DataSource = page;
            rptBlogEntries.DataBind();

            if (!IsPostBack)
            {
                RowCount = items.Count;
                CreatePagingControl();
            }
        }

        public string GetBlogContent(object oBlogPostItem)
        {
            BlogPostItem bpi = (BlogPostItem)oBlogPostItem;

            string content = bpi.Body.StripHTML();

            if (content.Length > 150) return content.Substring(0, 147) + "...";

            return content;

        }

        public string GetEmbeddedMedia(object oBlogPostItem)
        {
            BlogPostItem bpi = (BlogPostItem)oBlogPostItem;

            return Iascend.Intranet.Business.BlogManager.GetEmbeddedViewer(bpi.VideoPictureUrl, bpi.VideoPictureTitle);
        }

        public string GetComments(object oBlogPostItem)
        {
            BlogPostItem bpi = (BlogPostItem)oBlogPostItem;

            string strNumberOfComments = "";

            if (bpi.NumComments == "1")
                strNumberOfComments = "1 Comment";
            else
                strNumberOfComments = String.Format("{0} Comments", bpi.NumComments);

            return strNumberOfComments;
        }
    }
}
