﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Iascend.Intranet.Model;
using System.Collections.Generic;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Framework.Logging;

namespace Iascend.Intranet.WebParts.BlogRecentCommentsWebPart
{
    public partial class BlogRecentCommentsWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            //Get List of Blog Posts
            List<BlogPostCommentItem> items = Iascend.Intranet.Business.BlogManager.GetCurrentSiteRecentBlogPostCommentItems().OrderByDescending(bpi => bpi.CreatedDate).Take(5).ToList<BlogPostCommentItem>();

            rptRecentPostComments.DataSource = items;
            rptRecentPostComments.DataBind();

        }

        /// <summary>
        /// Renders the activity date.
        /// </summary>
        /// <param name="oActivityDate">The o activity date.</param>
        /// <returns></returns>
        public string RenderActivityDate(object oActivityDate)
        {
            string ActivityDate = "";

            try
            {
                ActivityDate = String.Format("{0}", DisplayRelativeTime(oActivityDate.ToString()));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Error rendering activity date", ex.ToString());
            }

            return ActivityDate;
        }

        /// <summary>
        /// Displays the relative time of the activity, such as "about one minute ago".
        /// </summary>
        /// <param name="inDateTime">The in date time.</param>
        /// <returns></returns>
        private string DisplayRelativeTime(string inDateTime)
        {
            try
            {
                DateTime dttime = DateTime.Parse(inDateTime.ToString());

                TimeSpan timeDiff = DateTime.Now.Subtract(dttime);

                if (timeDiff.TotalMinutes < 1) return "less than a minute ago";
                else if (timeDiff.TotalMinutes < 2) return "about one minute ago";
                else if (timeDiff.TotalMinutes < 60) return String.Format("about {0:N0} minutes ago", timeDiff.TotalMinutes);
                else if (timeDiff.TotalHours < 2) return "about an hour ago";
                else if (timeDiff.TotalHours < 12) return String.Format("about {0:N0} hours ago", timeDiff.TotalHours);
                else if (timeDiff.TotalDays < 365) return dttime.ToString("MMM d");
                else return dttime.ToString("MMM d, yyyy");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Error parsing datetime", ex.ToString());
            }

            return "";
        }
    }
}
