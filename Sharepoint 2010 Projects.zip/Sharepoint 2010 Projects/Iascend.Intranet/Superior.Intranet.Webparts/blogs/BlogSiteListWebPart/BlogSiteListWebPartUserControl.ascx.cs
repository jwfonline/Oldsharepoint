﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Iascend.Intranet.Model;
using System.Collections.Generic;

namespace Iascend.Intranet.WebPartsiteListWebPart
{
    public partial class BlogSiteListWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            List<BlogSiteListItem> items = Iascend.Intranet.Business.BlogManager.GetAllBlogSiteListItems(true);

            rptBlogSiteList.DataSource = items;
            rptBlogSiteList.DataBind();

        }
    }
}
