﻿namespace LatinWorks.SharePoint.WebProject.WebParts.Blogs.VisualWebPart1
{
    public partial class VisualWebPart1UserControl
    {
    }
}
