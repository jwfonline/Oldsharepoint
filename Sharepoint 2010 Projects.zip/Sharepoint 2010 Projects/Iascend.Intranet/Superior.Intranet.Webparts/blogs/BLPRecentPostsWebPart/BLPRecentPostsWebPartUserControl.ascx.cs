﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Iascend.Intranet.Model;
using System.Collections.Generic;
using Iascend.Intranet.Framework;

namespace Iascend.Intranet.WebParts.BLPRecentPostWebPart
{
    public partial class BLPRecentPostWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            //Get List of Blog Posts
            List<BlogPostItem> items = Iascend.Intranet.Business.BlogManager.GetAllBlogPostItems("").OrderByDescending(bpi => bpi.PublishedDate).Take(8).ToList<BlogPostItem>();

            rptRecentBlogList.DataSource = items;
            rptRecentBlogList.DataBind();

        }
    }
}
