﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using Iascend.Intranet.Model;

namespace Iascend.Intranet.WebParts.BlogDetailWebPart
{
    public partial class BlogDetailWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindData()
        {
            if (Request.QueryString["ID"] != null)
            {
                int PostID = Int32.Parse(Request.QueryString["ID"]);

                //Get List of Blog Posts
                BlogPostItem bpi = Iascend.Intranet.Business.BlogManager.GetCurrentSiteBlogPostItems().FirstOrDefault(b => b.PostID == PostID);

                //If we have posts...
                if (bpi != null)
                {
                    TeamBlogEmbeddedViewer.Text = Iascend.Intranet.Business.BlogManager.GetEmbeddedViewer(bpi.VideoPictureUrl, bpi.VideoPictureTitle);

                    //lblBlogAuthorBy.Text = "by ";
                    lnkBlogAuthor.NavigateUrl = bpi.AuthorProfileUrl;
                    lnkBlogAuthor.Text = bpi.Author;

                    lblBlogTitle.Text = bpi.Title;
                    lblContent.Text = bpi.Body ?? "";
                    lblPublishedDate.Text = bpi.PublishedDate.ToString("MMM dd yyyy");

                    imgProfilePhoto.ImageUrl = bpi.AuthorPictureUrl;
                    lnkProfilePhoto.NavigateUrl = bpi.AuthorProfileUrl;

                }
                else
                {
                    //No Blog Posts were found
                    pnlMain.Visible = false;
                }
            }
        }
    }
}
