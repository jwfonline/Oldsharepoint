﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Iascend.Intranet.Webparts;
using Microsoft.SharePoint.WebPartPages;
using Iascend.Intranet.Enums.Enumerations;
namespace Iascend.Intranet.Webparts.Alerts
{
    [ToolboxItemAttribute(false)]
    public class Alerts : System.Web.UI.WebControls.WebParts.WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/Iascend.Intranet.Webparts/Alerts/AlertsUserControl.ascx";

        //property to assign list name
     
        private string lname = string.Empty;
           [
           Personalizable(PersonalizationScope.Shared),
           Browsable(true),
           Category("Iascend Settings"),
           DefaultValue(""),
           WebPartStorage(Storage.Shared),
           FriendlyName("List Name"),
           Description("Name of the List to pull from"),
           WebBrowsable(true),
           WebDisplayName("List Name"),
           WebDescription("Name of the List to pull from")
       ]
        public string ListName
        {
            get { 
               // if (lname == string.Empty)
              // lname = "Tickers";
               
                return lname;
            }
            set { lname = value; }
        }

        [
        Personalizable(PersonalizationScope.Shared),
        Browsable(true),
        Category("Iascend Settings"),
        DefaultValue(""),
        WebPartStorage(Storage.Shared),
        FriendlyName("List Site"),
        Description("Site that the List resides on. Leave blank will default to site collection. Specify full path otherwise."),
        WebBrowsable(true),
        WebDisplayName("List Site"),
        WebDescription("Site that the List resides on. Leave blank will default to site collection. Specify full path otherwise.")
       ]
        public string ListSite { get; set; }

        protected override void CreateChildControls()
        {
            AlertsUserControl control = (AlertsUserControl)Page.LoadControl(_ascxPath);
            if (control != null)
            {
                control.WebPart = this;
            }
            Controls.Add(control);
        }
    }
}
