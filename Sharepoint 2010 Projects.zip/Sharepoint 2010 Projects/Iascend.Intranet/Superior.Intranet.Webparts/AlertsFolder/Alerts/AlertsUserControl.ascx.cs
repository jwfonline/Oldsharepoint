﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Text;
using System.Collections.Generic;
using Iascend.Intranet.Model;
using Iascend.Intranet.Business;
using Iascend.Intranet.Framework.Extensions;
using Microsoft.SharePoint;



namespace Iascend.Intranet.Webparts.Alerts
{
    public partial class AlertsUserControl : UserControl
    {
        public string ListName
        { get; set; }

        public string ListSite { get; set; }

        public Alerts WebPart { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.WebPart != null)
            {
               
                this.ListName = this.WebPart.ListName;
                this.ListSite = this.WebPart.ListSite;
            }
            try
            {
 Marquee.Text = String.Format("{0}", GetTickers());
            }
            catch (Exception ex)
            {
                
                Iascend.Intranet.Framework.Logging.ULSLogHelper.LogErrorMessage("alert user conrtol error", ex.ToString());
                    
            }
           
        }

        private string GetTickers()
        {
            string TickerString = "";
            List<TickerItem> items;
            // get a list of all events
          //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.ListSite == string.Empty || this.ListSite == null)
            {
               items = TickerManager.GenerateTickerListItems(SPContext.Current.Web.Url, this.ListName);
            }
            else
            {
              items = TickerManager.GenerateTickerListItems(this.ListSite, this.ListName);
            }
           

            StringBuilder sb = new StringBuilder();

            bool AddDivider = false;
            if (items.Count != 0)
            {
                foreach (TickerItem item in items.Shuffle())
                {
                    if (AddDivider)
                        //sb.Append("<span>&nbsp;<img src=\"/style%20library/images/Iascend/dividerMarq.gif\" />&nbsp;</span>");
                    sb.Append("<span> | </span>");

                    sb.AppendFormat("<a style='color:red;text-decoration:none;' href=\"{0}\">{1}</a>", item.URL, item.Title);
                        
                        AddDivider = true;
                }
            }
            else
            {
                //if the items dont contain anything display this
                sb.Append("No Active Alerts");
            }

            TickerString = sb.ToString();

            return TickerString;
        }


    }
}
