﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Security.Permissions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Iascend.Intranet.Webparts;
using Microsoft.SharePoint.WebPartPages;

using Iascend.Intranet.Model;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Business;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.EnumsAndConstants;
using Iascend.Intranet.Framework.Logging;


namespace Iascend.Intranet.Webparts.ImageRotator
{
	/// <summary>
	/// Options to determine how the JavaScript libraries will be served.
	/// </summary>
	public enum ContentDeliveryOption
	{
        /// <summary>
		/// Served from the Microsoft CDN
		/// </summary>
		Microsoft,
		/// <summary>
		/// Served from a local resource.
		/// </summary>
		Internal,
		/// <summary>
		/// Not served at all (must already be included on the page).
		/// </summary>
		None,
		/// <summary>
		/// Served from the Edgecast CDN
		/// </summary>
		Edgecast,
		/// <summary>
		/// Served from the Google CDN
		/// </summary>
		Google
		
	}

	/// <summary>
	/// Options to determine the rotation behavior.
	/// </summary>
	public enum RotationOption
	{
		/// <summary>
		/// Display one random image on page load.
		/// </summary>
		Once,
		/// <summary>
		/// Cycle through multiple images without forcing the user to refresh their browser.
		/// </summary>
		Multiple
	}

    public enum TransitionEffect
    {
       
       zoom,
       turnDown,
       fade,
       curtainX
    }
}

namespace Iascend.Intranet.Webparts.ImageRotator
{

    [ToolboxItemAttribute(false)]
    public class ImageRotator : System.Web.UI.WebControls.WebParts.WebPart
    {
        #region Constants
        const string MAIN_CATEGORY = @"Ad Rotator";
        const string CYCLE_CATEGORY = @"Cycle Settings";
        #endregion


        #region Public Properties

         [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("Rotation"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("Rotation"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public Iascend.Intranet.Webparts.ImageRotator.RotationOption Rotation { get; set; }

         [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("JavaScriptDeliveryMethod"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("JavaScriptDeliveryMethod"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
         public Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption JavaScriptDeliveryMethod { get; set; }

     [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("ListSite"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("ListSite"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
         public string ListSite { get; set; }

     [
     Personalizable(PersonalizationScope.Shared),
     Browsable(true),
     Category("Iascend Settings"),
     DefaultValue(""),
     WebPartStorage(Storage.Shared),
     FriendlyName("List Name"),
     Description("Name of the List to pull from"),
     WebBrowsable(true),
     WebDisplayName("List Name"),
     WebDescription("Name of the List to pull from")
 ]
     public string ListName { get; set; }


       [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("CustomCssClass"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(false),
          WebDisplayName("CustomCssClass"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public string CustomCssClass { get; set; }

    [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("RotationSpeed"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("RotationSpeed"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public int RotationSpeed { get; set; }

      [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("TransitionEffect"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("TransitionEffect"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public Iascend.Intranet.Webparts.ImageRotator.TransitionEffect TransitionEffect { get; set; }

       [
          Personalizable(PersonalizationScope.Shared),
          Browsable(true),
          Category("Iascend Settings"),
          DefaultValue(""),
          WebPartStorage(Storage.Shared),
          FriendlyName("PauseOnHover"),
          Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
          WebBrowsable(true),
          WebDisplayName("PauseOnHover"),
          WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
         ]
        public bool PauseOnHover { get; set; }

        #endregion
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
       private const string _ascxPath = @"~/_CONTROLTEMPLATES/Iascend.Intranet.Webparts/ImageRotator/ImageRotatorUserControl.ascx";

        //protected override void CreateChildControls()
        //{
        //    if (this.WebPartManager.DisplayMode.AllowPageDesign)
        //    {
        //        CssRegistration.Register("controls.css");
        //        this.Controls.Add(new LiteralControl(String.Format(CultureInfo.CurrentCulture, "<p class=\"wp-content description\">This Web Part does not have a list configured. To configure this Web Part, <a href=\"#\" onclick=\"javascript:MSOTlPn_ShowToolPane2('Edit','{0}');\">open the tool pane</a>.</p>", new string[] { this.ID })));
        //    }
        //    ImageRotatorUserControl control = (ImageRotatorUserControl)Page.LoadControl(_ascxPath);
        //    if (control != null)
        //    {
        //        //this always us to set the webpart properties
        //        control.WebPart = this;
        //    }
        //    Controls.Add(control);
        //}

        #region Event Handlers
        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            try
            {
              

                switch (this.Rotation)
                {
                    case Iascend.Intranet.Webparts.ImageRotator.RotationOption.Multiple:
                        this.AddJavaScript();
                        this.CreateRotatingImages();
                        break;

                    case Iascend.Intranet.Webparts.ImageRotator.RotationOption.Once:
                    default:
                        this.Controls.Add(GetRandomImage());
                        break;
                }

                this.CssClass = "adRotator";		// TODO: Investigate why SharePoint is overriding this when it is in the constructor.
                if (!String.IsNullOrEmpty(this.CustomCssClass))
                    this.CssClass += " " + this.CustomCssClass;

            }
            catch (Exception ex)
            {
                this.Controls.Add(new LiteralControl(ex.ToString()));
                Iascend.Intranet.Framework.Logging.ULSLogHelper.LogErrorMessage("iAscend user conrtol error", ex.ToString());
            }

            this.ChildControlsCreated = true;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Returns one random image from a SharePoint list.
        /// </summary>
        /// <returns>An image control, or a literal control if no images were found.</returns>
        protected virtual Control GetRandomImage()
        {
            Control returnValue = null;
            List<ImageRotatorItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.ListSite == string.Empty || this.ListSite == null)
            {
                items = ImageRotaterManager.GetRandomImage(SPContext.Current.Web.Url, this.ListName);
            }
            else
            {
                items = ImageRotaterManager.GetRandomImage(this.ListSite, this.ListName);
            }
            int imageCount = items.Count;

            if (imageCount > 0)
            {

                items = (List<ImageRotatorItem>)items.Shuffle();

                if (imageCount > 0)
                {
                    HtmlImage imgRandom = new HtmlImage();
                    Random rnd = new Random(DateTime.Now.Millisecond);

                    //SPListItem randomItem = adImages[rnd.Next(0, imageCount)];
                    //string altText = randomItem[SPBuiltInFieldId.Comments] as string;
                    //imgRandom.Alt = altText;
                    //if (String.IsNullOrEmpty(altText))
                    //    imgRandom.Attributes.Add("alt", "");

                    imgRandom.Src = items[0].imgUrl;

                    returnValue = imgRandom;

                    // Check to see if the image has the URL column associated with it for us to build a link
                    // TODO: Check the list to make sure the URL column is there, don't use try/catch

                    //split the value
                        string[] linkurl = items[0].link.Split(',');
                     HtmlAnchor imgLink = new HtmlAnchor();
                    //if the link value is empty link to the picture
                        if (linkurl[0].ToString() == string.Empty)
                        {
                             imgLink.HRef = items[0].imgUrl;
                        }
                        else
                        {
                            imgLink.HRef = linkurl[0].ToString();
                        }
                           // SPFieldUrlValue imgUrl = new SPFieldUrlValue((string)urlValue);
                           
                            //imgLink.HRef = imgUrl.Url;
                            imgLink.Controls.Add(returnValue);

                            returnValue = imgLink;
                        }
                    
                }
                else
                {
                    returnValue = new LiteralControl("No images were found.");
                }
            return returnValue;
            }

            
        

        /// <summary>
        /// Adds the JavaScript and CSS needed to drive the jQuery Cycle plugin
        /// </summary>
        [System.Security.Permissions.FileIOPermission(SecurityAction.LinkDemand)]
        protected virtual void AddJavaScript()
        {
            switch (this.JavaScriptDeliveryMethod)
            {
                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Internal:
                    ScriptLink.Register(this.Page, "jquery-1.4.2.min.js", false, false);
                    ScriptLink.Register(this.Page, "jquery.cycle.all.min.js", false, false);
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.None:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Edgecast:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://code.jquery.com/jquery-1.4.2.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Google:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Microsoft:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://ajax.microsoft.com/ajax/jquery/jquery-1.4.2.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;
            }

            string cssOptions = null;

            if (this.Width != Unit.Empty)
            {
                cssOptions = "width:" + this.Width.ToString(CultureInfo.CurrentCulture) + ";";
            }

            if (this.Height != Unit.Empty)
            {
                cssOptions += "height:" + this.Height.ToString(CultureInfo.CurrentCulture) + ";";
            }

            Page.ClientScript.RegisterClientScriptBlock(typeof(ImageRotator), this.ClientID, @"
<script type=""text/javascript"">
//<![CDATA[
$(document).ready(function() {
    jQuery('#" + this.ClientID + @"').cycle({
		fx: '" + this.TransitionEffect + @"',
		timeout: '" + this.RotationSpeed.ToString(CultureInfo.CurrentCulture) + @"',
		pause: " + this.PauseOnHover.ToString().ToLower(CultureInfo.CurrentCulture) + @"
	});
});
//]]>
</script>
<style type=""text/css"">
	#" + this.ClientID + @" img { border: 0;" + cssOptions + @" }
	.adRotator .notFirst { display: none; }
</style>
");
        }

        /// <summary>
        /// Adds the images used for cycling images using the jQuery cycle plugin
        /// </summary>
        protected virtual void CreateRotatingImages()
        {
            List<ImageRotatorItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.ListSite == string.Empty || this.ListSite == null)
            {
                items = ImageRotaterManager.GetRandomImage(SPContext.Current.Web.Url, this.ListName);
            }
            else
            {
                items = ImageRotaterManager.GetRandomImage(this.ListSite, this.ListName);
            }         

                bool isFirst = true;

                 foreach (ImageRotatorItem listItem in items)
                {
                    string imageSource = listItem.imgUrl;
                   // string altText = listItem[SPBuiltInFieldId.Comments] as string;

                    HtmlImage adImage = new HtmlImage();
                  //  adImage.Alt = altText;
                    adImage.Src = imageSource;
    
                            //split the value
                                    string[] linkurl = listItem.link.Split(',');
                                   HtmlAnchor imgLink = new HtmlAnchor();
                                    //if the link value is empty link to the picture
                                    if (linkurl[0].ToString() == string.Empty)
                                    {
                                        imgLink.HRef = listItem.imgUrl;
                                    }
                                    else
                                    {
                                        imgLink.HRef = linkurl[0].ToString(); ;
                                    }
                            imgLink.Controls.Add(adImage);

                            //if (items[0].ID == listItem.ID)
                            //    isFirst = true;
                            //else
                            //    isFirst = false;

                            if (!isFirst)
                                imgLink.Attributes.Add("class", "notFirst");
                            else
                                isFirst = false;

                            this.Controls.Add(imgLink);
                           // continue;

                        
                   

                    //if (!isFirst)
                    //    adImage.Attributes.Add("class", "notFirst");
                    //else
                    //    isFirst = false;

                    //this.Controls.Add(adImage);
                }
            }
        }

        /// <summary>
        /// Parses the ListUrl property into two parts, a Web URL and a list name.
        /// </summary>
        //struct WebListUrl
        //{
        //    public string WebUrl { get; private set; }
        //    public string ListUrl { get; private set; }

        //    public WebListUrl(string fullUrl)
        //        : this()
        //    {
        //        int lastSlash = fullUrl.LastIndexOf('/') + 1;
        //        this.WebUrl = fullUrl.Substring(0, lastSlash);
        //        this.ListUrl = fullUrl.Substring(lastSlash);
        //    }
        //}
        #endregion

        //#region IWebEditable Members

        //public override EditorPartCollection CreateEditorParts()
        //{
        //    List<EditorPart> editorParts = new List<EditorPart>();
        //    editorParts.Add(new ImageRotator());

        //    return new EditorPartCollection(editorParts);
        //}

        //public override object WebBrowsableObject
        //{
        //    get
        //    {
        //        return this;
        //    }
        //}
        //#endregion

        //#region IDesignTimeHtmlProvider Members

        //public string GetDesignTimeHtml()
        //{
        //    return "<p>Ad Rotator Web Part</p>";
        //}

        //#endregion

    }



