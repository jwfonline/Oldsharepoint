﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Security.Permissions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;


using System.Linq;

using Iascend.Intranet.Model;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Business;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.EnumsAndConstants;
using Iascend.Intranet.Framework.Logging;

namespace Iascend.Intranet.Webparts.ImageRotator
{
    public partial class ImageRotatorUserControl : UserControl
    {

        public ImageRotator WebPart { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            switch (this.WebPart.Rotation)
            {
                case Iascend.Intranet.Webparts.ImageRotator.RotationOption.Multiple:
                   this.AddJavaScript();
                   this.CreateRotatingImages();
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.RotationOption.Once:
                default:
                    GetRandomImage();
                    break;
            }

         
        }

        /// <summary>
        /// Adds the JavaScript and CSS needed to drive the jQuery Cycle plugin
        /// </summary>
        [System.Security.Permissions.FileIOPermission(SecurityAction.LinkDemand)]
        protected virtual void AddJavaScript()
        {
            switch (this.WebPart.JavaScriptDeliveryMethod)
            {
                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Internal:
                    ScriptLink.Register(this.Page, "jquery-1.4.2.min.js", false, false);
                    ScriptLink.Register(this.Page, "jquery.cycle.all.min.js", false, false);
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.None:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Edgecast:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://code.jquery.com/jquery-1.4.2.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Google:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;

                case Iascend.Intranet.Webparts.ImageRotator.ContentDeliveryOption.Microsoft:
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQuery", "http://ajax.microsoft.com/ajax/jquery/jquery-1.4.2.min.js");
                    Page.ClientScript.RegisterClientScriptInclude(typeof(ImageRotator), "jQueryCycle", "~/_layouts/jquery.cycle.all.min.js");
                    break;
            }

            string cssOptions = null;

            if (this.WebPart.Width != Unit.Empty)
            {
                cssOptions = "width:" + this.WebPart.Width.ToString(CultureInfo.CurrentCulture) + ";";
            }

            if (this.WebPart.Height != Unit.Empty)
            {
                cssOptions += "height:" + this.WebPart.Height.ToString(CultureInfo.CurrentCulture) + ";";
            }

            Page.ClientScript.RegisterClientScriptBlock(typeof(ImageRotator), this.ClientID, @"
<script type=""text/javascript"">
//<![CDATA[
$(document).ready(function() {
    $('#" + this.WebPart.ClientID + @"').cycle({
		fx: '" + this.WebPart.TransitionEffect + @"',
		timeout: '" + this.WebPart.RotationSpeed.ToString(CultureInfo.CurrentCulture) + @"',
		pause: " + this.WebPart.PauseOnHover.ToString().ToLower(CultureInfo.CurrentCulture) + @"
	});
});
//]]>
</script>
<style type=""text/css"">
	#" + this.WebPart.ClientID + @" img { border: 0;" + cssOptions + @" }
	.adRotator .notFirst { display: none; }
</style>
");
        }

        /// <summary>
        /// Returns one random image from a SharePoint list.
        /// </summary>
        /// <returns>An image control, or a literal control if no images were found.</returns>
        protected bool  GetRandomImage()
        {
            List<ImageRotatorItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.WebPart.ListSite == string.Empty || this.WebPart.ListSite == null)
            {
                items = ImageRotaterManager.GetRandomImage(SPContext.Current.Web.Url, this.WebPart.ListName);
            }
            else
            {
                items = ImageRotaterManager.GetRandomImage(this.WebPart.ListSite, this.WebPart.ListName);
            }           
                int imageCount = items.Count;

                if (imageCount > 0)
                {              
                   
                    items = (List<ImageRotatorItem>)items.Shuffle();
                
                    imgRandom.ImageUrl = items[0].imgUrl;

                    //split the value
                        string[] linkurl = items[0].link.Split(',');
                    //if the link value is empty link to the picture
                        if (linkurl[0].ToString() == string.Empty)
                        {
                            imgRandom.PostBackUrl = items[0].imgUrl;
                        }
                        else
                        {
                            imgRandom.PostBackUrl = linkurl[0].ToString();
                        }
                           
                        
                    }
              
            return true;
        }

        /// <summary>
        /// Adds the images used for cycling images using the jQuery cycle plugin
        /// </summary>
        protected virtual void CreateRotatingImages()
        {
            List<ImageRotatorItem> items;
            // get a list of all events
            //  List<TickerItem> items = TickerManager.GetAllTickers(SPContext.Current.Site.Url);
            if (this.WebPart.ListSite == string.Empty || this.WebPart.ListSite == null)
            {
                items = ImageRotaterManager.GetRandomImage(SPContext.Current.Web.Url, this.WebPart.ListName);
            }
            else
            {
                items = ImageRotaterManager.GetRandomImage(this.WebPart.ListSite, this.WebPart.ListName);
            }         
                 

                bool isFirst = true;

                foreach (ImageRotatorItem listItem in items)
                {
                    
                    //imgRandom.ImageUrl = listItem.imgUrl; 
                   
                            
                            HtmlImage adImage = new HtmlImage();

                            adImage.Src = listItem.imgUrl;

                                                       
                                    //split the value
                                    string[] linkurl = listItem.link.Split(',');
                                   HtmlAnchor imgLink = new HtmlAnchor();
                                    //if the link value is empty link to the picture
                                    if (linkurl[0].ToString() == string.Empty)
                                    {
                                        imgLink.HRef = listItem.imgUrl;
                                    }
                                    else
                                    {
                                        imgLink.HRef = linkurl[0].ToString(); ;
                                    }
                                    
                                    //imgLink.HRef = imgUrl.Url;
                                    imgLink.Controls.Add(adImage);

                                    if (!isFirst)
                                        imgLink.Attributes.Add("class", "notFirst");
                                    else
                                        isFirst = false;

                                    this.Controls.Add(imgLink);

                                    
                              
                           

                            if (!isFirst)
                                adImage.Attributes.Add("class", "notFirst");
                            else
                                isFirst = false;

                            this.Controls.Add(adImage);
                }

                   
                }
            
        }
    }

