﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Globalization;
using System.Collections.Generic;
using System.Text;


using Iascend.Intranet.Model;
using Iascend.Intranet.Framework;
using Iascend.Intranet.Business;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.EnumsAndConstants;
using Iascend.Intranet.Framework.Logging;


using Microsoft.SharePoint;
namespace Iascend.Intranet.Webparts.UpcomingEvents
{
    public partial class UpcomingEventsUserControl : UserControl
    {
        //[
        //    Personalizable(PersonalizationScope.Shared),
        //    Browsable(true),
        //    Category("HAS Settings"),
        //    DefaultValue(""),
        //    WebPartStorage(Storage.Shared),
        //    FriendlyName("List Site"),
        //    Description("Site that the List resides on. Leave blank if it's the current site."),
        //    WebBrowsable(true),
        //    WebDisplayName("List Site"),
        //    WebDescription("Site that the List resides on. Leave blank if it's the current site.")
        //]
        public string ListSite
        { get; set; }
        //[
        //    Browsable(true),
        //    Category("HAS Settings"),
        //    DefaultValue(""),
        //    WebPartStorage(Storage.Shared),
        //    FriendlyName("List Name"),
        //    Description("Name of the List to pull from"),
        //    WebBrowsable(true),
        //    WebDisplayName("List Name"),
        //    WebDescription("Name of the List to pull from")
        //]
        public string ListName
        { get; set; }

        public bool SiteRollUp { get; set; }
        
        /// <summary>
        /// Gets or sets the selected date.
        /// </summary>
        /// <value>The selected date.</value>
        public DateTime SelectedDate
        {
            get
            {
                if (ViewState["SelectedDate"] == null) ViewState["SelectedDate"] = DateTime.Now;
                
                return (DateTime)ViewState["SelectedDate"];
            }

            set { ViewState["SelectedDate"] = value; }
        }



        public UpcomingEvents WebPart { get; set; }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {

            if (this.WebPart != null)
            {
                this.ListSite = this.WebPart.ListSite;
                this.ListName = this.WebPart.ListName;
                this.SiteRollUp = this.WebPart.SiteRollUp;
            }

            //LoadWeek();
            if (!IsPostBack)
            {
               LoadWeek();

                //highlight the correct linkbutton based on date
               foreach (Control ctrl in pnlWeek.Controls)
               {
                   if (ctrl is LinkButton)
                   {
                       LinkButton linkb = (LinkButton)ctrl;
                       if (linkb.Text.Trim() == Convert.ToString(DateTime.Now.Day))
                           linkb.BackColor = System.Drawing.Color.Gray;
                   }

               }
          
            }
            //this.lnkFullCalendar.NavigateUrl = SPContext.Current.Site.Url + "/Lists/EventsCalendar/calendar.aspx";

        }


        /// <summary>
        /// Gets selected date and beginning of the week.
        /// Changes the Month Display
        /// Renders all of the daily links with appropriate CSS classes
        /// </summnary>
        private void LoadWeek()
        {

            DisplayUpcomingEvents();            
            
            DateTime CurrentSelectedDate = SelectedDate;
            DateTime BeginningOfWeek = CurrentSelectedDate.StartOfWeek(DayOfWeek.Sunday);

            string monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(CurrentSelectedDate.Month);

            lblMonth.Text = monthName;

            //Set Text
            lnkDay1.Text = BeginningOfWeek.Day.ToString();
            lnkDay2.Text = BeginningOfWeek.AddDays(1).Day.ToString();
            lnkDay3.Text = BeginningOfWeek.AddDays(2).Day.ToString();
            lnkDay4.Text = BeginningOfWeek.AddDays(3).Day.ToString();
            lnkDay5.Text = BeginningOfWeek.AddDays(4).Day.ToString();
            lnkDay6.Text = BeginningOfWeek.AddDays(5).Day.ToString();
            lnkDay7.Text = BeginningOfWeek.AddDays(6).Day.ToString();

            //Set Command Args
            lnkPreviousWeek.CommandArgument = CurrentSelectedDate.AddDays(-7).ToString();
            lnkNextWeek.CommandArgument = CurrentSelectedDate.AddDays(7).ToString();
            lnkDay1.CommandArgument = BeginningOfWeek.ToString();
            lnkDay2.CommandArgument = BeginningOfWeek.AddDays(1).ToString();
            lnkDay3.CommandArgument = BeginningOfWeek.AddDays(2).ToString();
            lnkDay4.CommandArgument = BeginningOfWeek.AddDays(3).ToString();
            lnkDay5.CommandArgument = BeginningOfWeek.AddDays(4).ToString();
            lnkDay6.CommandArgument = BeginningOfWeek.AddDays(5).ToString();
            lnkDay7.CommandArgument = BeginningOfWeek.AddDays(6).ToString();

            lnkDay1.CssClass = "LW_UEC_DateLink";
            lnkDay2.CssClass = "LW_UEC_DateLink";
            lnkDay3.CssClass = "LW_UEC_DateLink";
            lnkDay4.CssClass = "LW_UEC_DateLink";
            lnkDay5.CssClass = "LW_UEC_DateLink";
            lnkDay6.CssClass = "LW_UEC_DateLink";
            lnkDay7.CssClass = "LW_UEC_DateLink";

            //Set HasEvents To CSS Class if date contains events
            lnkDay1.CssClass = HasEvents(BeginningOfWeek) ? "LW_UEC_DateLink lw_events_active_event" : lnkDay1.CssClass;
            lnkDay2.CssClass = HasEvents(BeginningOfWeek.AddDays(1)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay2.CssClass;
            lnkDay3.CssClass = HasEvents(BeginningOfWeek.AddDays(2)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay3.CssClass;
            lnkDay4.CssClass = HasEvents(BeginningOfWeek.AddDays(3)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay4.CssClass;
            lnkDay5.CssClass = HasEvents(BeginningOfWeek.AddDays(4)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay5.CssClass;
            lnkDay6.CssClass = HasEvents(BeginningOfWeek.AddDays(5)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay6.CssClass;
            lnkDay7.CssClass = HasEvents(BeginningOfWeek.AddDays(6)) ? "LW_UEC_DateLink HAS_Outline" : lnkDay7.CssClass;

            //Set SelectedDate To CSS Class if date is the currently selected date
            lnkDay1.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.ToString("d") ? "LW_UEC_DateLink lw_events_selected" : lnkDay1.CssClass);
            lnkDay2.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(1).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay2.CssClass);
            lnkDay3.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(2).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay3.CssClass);
            lnkDay4.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(3).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay4.CssClass);
            lnkDay5.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(4).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay5.CssClass);
            lnkDay6.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(5).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay6.CssClass);
            lnkDay7.CssClass = (CurrentSelectedDate.ToString("d") == BeginningOfWeek.AddDays(6).ToString("d") ? "LW_UEC_DateLink HAS_Selected" : lnkDay7.CssClass);
        
            //Binds Events for Given Date
            BindEvents();

        }

        private void DisplayUpcomingEvents()
        {
            if (ListName != null && ListName != string.Empty)
            {
                ListName = ListName.Trim('/');
            }
            else
                ListName = Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue();


            StringBuilder sb = new StringBuilder();

            if (ListSite != null && ListSite != string.Empty)
            {
                ListSite = ListSite.Trim('/');
                //  sb.Append("~/");
                sb.Append(ListSite);

            }
            else
            {
                ListSite = SPContext.Current.Web.Url.Trim('/');
                sb.AppendFormat("{0}", SPContext.Current.Web.Url); //SPContext.Current.Site.Url
            }


            // sb.Append(ListSite);

            sb.AppendFormat("/Lists/{0}", ListName);

            this.lnkFullCalendar.NavigateUrl = sb.ToString();

            //this.lnkFullCalendar.Text = string.Format("{0} {1}", this.lnkFullCalendar.Text, DisplayTitle);

        }


        /// <summary>
        /// Determines whether the specified date has events.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns>
        /// 	<c>true</c> if the specified date has events; otherwise, <c>false</c>.
        /// </returns>
        private bool HasEvents(DateTime date)
        {
            try
            {
                // get a list of all QuickLinks items
                List<CalendarItem> items = UpcomingEventsManager.GetEventsForDate(ListSite, ListName, date);

                if (items.Count > 0) return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                //ULSLogHelper.LogErrorMessage("Failed to load Current Events", ex.ToString());
            }

            
            return false;
        }

        /// <summary>
        /// Binds the events to the repeater.
        /// </summary>
        private void BindEvents()
        {
            try
            {
                List<CalendarItem> items;
                // get a list of all events
                //if siterollup is true then get events for entire sitecollection
                if (SiteRollUp == true)
                {
                    //
                   items = UpcomingEventsManager.GetAllUpcomingEventsForSiteCollectionSubSites(ListSite, Iascend.Intranet.EnumsAndConstants.Enumerations.SharePointLists.EventsCalendar.GetStringValue(), SelectedDate);
                }
                else
                {
                    //use the properties when not a siteroolup
                  items = UpcomingEventsManager.GetUpcomingEvents(ListSite, ListName, SelectedDate);
                }

    
                // bind to data source
                rptEvents.DataSource = items;
                rptEvents.DataBind();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                ULSLogHelper.LogErrorMessage("Failed to load Current Events", ex.ToString());
            }
        }

        /// <summary>
        /// Renders the calendar item.
        /// </summary>
        /// <param name="oCalendarItem">The o calendar item.</param>
        /// <returns></returns>
        public string RenderCalendarItem(object oCalendarItem)
        {
            CalendarItem ci = (CalendarItem)oCalendarItem;

            //return String.Format("<div class='LW_UEC_DataItem_Title'>{0}</div><div class='LW_UEC_DataItem_Location'>{1}</div>", ci.Title, ci.Location);
            //return String.Format("<div class='LW_UEC_DataItem_Title'><a href='"+ ListSite + "/Lists/" + ListName + "/DispForm.aspx?ID="+ ci.ID +"'>{0}</a></div><div class='LW_UEC_DataItem_Date'>{1}</div>", ci.Title, ci.EventDate.ToShortDateString());
            return String.Format("<div class='LW_UEC_DataItem_Title'><a href=" + ci.URL + ">{0}</a></div><div class='LW_UEC_DataItem_Date'>{1}</div>", ci.Title, ci.EventDate.ToShortDateString());
        }

        /// <summary>
        /// Changes the date.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void ChangeDate(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;

            SelectedDate = DateTime.Parse(lb.CommandArgument);
            
            //clear the background of all linkbuttons in pln week
            this.clearLinkbuttonBG();
           

            lb.BackColor = System.Drawing.Color.Gray;
            LoadWeek();
        }

        private void clearLinkbuttonBG()
        {
            foreach (Control ctrl in pnlWeek.Controls)
            {
                if (ctrl is LinkButton)
                {
                    LinkButton linkb = (LinkButton)ctrl;
                    linkb.BackColor = System.Drawing.Color.Empty;
                }

            }
        }
    }

    /// <summary>
    /// Extensions for Datetime to find start of the week
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Starts the of week.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <param name="startOfWeek">The start of week.</param>
        /// <returns></returns>
        public static DateTime StartOfWeek(this DateTime date, DayOfWeek startOfWeek)
        {
            int diff = date.DayOfWeek - startOfWeek;
            if (diff < 0)
            {
                diff += 7;
            }

            return date.AddDays(-1 * diff).Date;
        }

      

    }
}
