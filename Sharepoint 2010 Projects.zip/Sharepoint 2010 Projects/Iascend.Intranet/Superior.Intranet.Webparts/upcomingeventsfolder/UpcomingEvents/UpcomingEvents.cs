﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Iascend.Intranet.Webparts;
using Microsoft.SharePoint.WebPartPages;
using Iascend.Intranet.Enums.Enumerations;
namespace Iascend.Intranet.Webparts.UpcomingEvents
{
    [ToolboxItemAttribute(false)]
    public class UpcomingEvents : System.Web.UI.WebControls.WebParts.WebPart
    {
        [
         Personalizable(PersonalizationScope.Shared),
         Browsable(true),
         Category("Iascend Settings"),
         DefaultValue(""),
         WebPartStorage(Storage.Shared),
         FriendlyName("List Site"),
         Description("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise."),
         WebBrowsable(true),
         WebDisplayName("List Site"),
         WebDescription("Site that the List resides on. Leave blank if it's the current site. Specify full path otherwise.")
        ]
        public string ListSite { get; set; }

        [
            Personalizable(PersonalizationScope.Shared),
            Browsable(true),
            Category("Iascend Settings"),
            DefaultValue(""),
            WebPartStorage(Storage.Shared),
            FriendlyName("List Name"),
            Description("Name of the List to pull from"),
            WebBrowsable(true),
            WebDisplayName("List Name"),
            WebDescription("Name of the List to pull from")
        ]
        public string ListName { get; set; }

        [
        Personalizable(PersonalizationScope.Shared),
        Browsable(true),
        Category("Iascend Settings"),
        DefaultValue(""),
        WebPartStorage(Storage.Shared),
        FriendlyName("Site Roll Up(Will overide list name and List Site)"),
        Description("determines whether the calendar will include other entries in the calendar from other sites"),
        WebBrowsable(false),
        WebDisplayName("Site Roll Up(Will overide list name and List Site)"),
        WebDescription("determines whether the calendar will include other entries in the calendar from other sites.")
       ]
        public bool SiteRollUp { get; set; }

        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/Iascend.Intranet.Webparts/UpcomingEvents/UpcomingEventsUserControl.ascx";

        protected override void CreateChildControls()
        {
            UpcomingEventsUserControl control = (UpcomingEventsUserControl)Page.LoadControl(_ascxPath);
            if (control != null)
            {
                control.WebPart = this;
            }

            Controls.Add(control);
        }
    }
}
