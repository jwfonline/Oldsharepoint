﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web;
using System.Web.Security;
using System.Web.UI.HtmlControls;
namespace Iascend.Intranet.Webparts.Footer
{
    public partial class FooterUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string searchUser = System.Web.Configuration.WebConfigurationManager.AppSettings["SearchAccount"].ToString();
            //if (Context.User.Identity.IsAuthenticated)
            //{
            //    if (Context.User.Identity.Name.ToString().ToLower() == searchUser.ToLower())
            //    {
            //        this.Visible = false;
            //        return;
            //    }
            //}
        }
    }
}
