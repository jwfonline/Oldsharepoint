﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Iascend.Intranet.Webparts.jQueryRoundedCorners
{
    public partial class jQueryRoundedCornersUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
