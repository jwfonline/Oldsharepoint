﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Xml;
using System.IO;

namespace Iascend.Intranet.Webparts.StockTicker
{
    public partial class StockTickerUserControl : UserControl
    {

        public DateTime sLastDate { get; set; }
        public Single sOpen { get; set; }
        public Single sTrade { get; set; }
        public Single sChange { get; set; }
        public double percChange { get; set; }
        public string span_class { get; set; }
        public string bgClass { get; set; }
        public string img { get; set; }
        public string alt { get; set; }
        private string _q = "\"";
        public string q
        {
            get { return _q; }
            set { _q = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            // CHANGE compID TO '132066' FOR DEVELOPMENT CHANGE compID TO '97570' FOR Prod
            //string compID = "132066";
            //string sUrl = "http://xml.corporate-ir.net/irxmlclient.asp?compid=" + compID + "&reqtype=quotes";
            string sUrl = "http://Iascendenergy.com/xml/spn_stock_quote.xml";

            XmlTextReader oXmlReader = new XmlTextReader(sUrl);

            // Load the document and set the root element.
            XmlDocument doc = new XmlDocument();
            doc.Load(oXmlReader);
            XmlNode root = doc.DocumentElement;
            sOpen = Convert.ToSingle(root.FirstChild.FirstChild.SelectSingleNode("Open").InnerXml);
            sTrade = Convert.ToSingle(root.FirstChild.FirstChild.SelectSingleNode("Trade").InnerXml);
            sChange = Convert.ToSingle(root.FirstChild.FirstChild.SelectSingleNode("Change").InnerXml);
            sLastDate = Convert.ToDateTime( root.FirstChild.FirstChild.SelectSingleNode("Date").InnerXml);

            //percChange = Convert.ToInt32((sChange / (sTrade + sChange)) * 10000 + 0.5) / 100;
            percChange = Math.Round((sTrade - sOpen) / sOpen * 100, 2);
          
            if (sChange < 0)
            {
                span_class = "red";
                img = "down_arrow.gif";
                alt = "Stock is down";
                bgClass = "bgRed";
            }
            else
            {
                span_class = "green";
                img = "up_arrow.gif";
                alt = "Stock is up";
                bgClass = "bgGreen";
            }

            LitsLastDate.Text = Convert.ToString( sLastDate.ToShortDateString());
            LitsTrade.Text = Convert.ToString(sTrade);
            LitpercChange.Text = Convert.ToString(percChange);
            //LitsChange.Text = "<span class=" + q + span_class + q + " > " + sChange + "</span>";
            LitsChange.Text = "<span class='" + span_class + "'>" + Convert.ToString(sChange) + "</span>";
            LitbgClass.Text = "<td rowspan="  + q + 2 + q + " class=" + q + bgClass + q + ">&nbsp;&nbsp;&nbsp;</td>";

            oXmlReader.Close();
        }
    }
}
