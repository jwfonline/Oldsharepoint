﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Interface.Model
{
    /// <summary>
    /// Simple Interface for all of our Model objects to share.
    /// Helps us uniformly load/save/manipulate data via custom methods on each object
    /// beyond any default manipulation done by reflection
    /// </summary>
    public interface IModel
    {
        void Translate();
    }
}
