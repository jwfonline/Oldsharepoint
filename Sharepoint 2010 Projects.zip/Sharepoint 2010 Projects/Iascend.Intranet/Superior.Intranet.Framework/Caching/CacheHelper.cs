﻿using System;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Caching;

using Iascend.Intranet.Framework.Caching;
using Iascend.Intranet.Framework.Services;

namespace Iascend.Intranet.Framework.Caching
{
    /// <summary>
    /// Helper class to manage the app cache.
    /// Provides static helper methods to get/set Caching data
    /// </summary>
    public class CacheHelper
    {
        #region Private Static Variables

        private static Cache cache = new Cache();

        #endregion

        #region Public Properties

        public static Cache CacheManager
        {
            get
            {
                if (HttpContext.Current != null &&
                    HttpContext.Current.Cache != null)
                {
                    cache = HttpContext.Current.Cache;
                }

                return cache;
            }
        }

        #endregion

        #region Cache Item Getters

        /// <summary>
        /// Gets an item of Type T from the cache based on the key value provided
        /// </summary>
        /// <typeparam name="T">The data type of the object to return</typeparam>
        /// <param name="key">The string key used as an index in the cache for the particular item</param>
        /// <returns>Returns an object of type T from the cache or a default(T) if it does not exist</returns>
        public static T GetCacheItem<T>(string key)
        {
            if (String.IsNullOrEmpty(key))
            {
                throw new NullReferenceException("Could not store value in cache.  Cache key cannot be null");
            }

            T cacheItem = default(T);

            if (CacheContainsKey<T>(key))
            {
                object cacheValue = CacheManager[key];
                if (cacheValue != null && cacheValue is T)
                {
                    cacheItem = (T)cacheValue;
                }
                else { }
            }
            else { }

            return cacheItem;
        }

        #endregion

        #region Cache Item Setters

        /// <summary>
        /// Sets an item in the cache of Type T with the key as the index value
        /// </summary>
        /// <typeparam name="T">The data type of the object to store in the cache</typeparam>
        /// <param name="key">The string key used as an index in the cache for the particular item</param>
        /// <param name="item">The object being stored in the cache</param>
        public static void SetCacheItem<T>(string key, T item)
        {
            DateTime cacheExpiration = DateTime.Now.AddMinutes(Convert.ToDouble(ConfigurationService.ShortCachingDuration));
            SetCacheItem<T>(key, item, cacheExpiration);
        }

        /// <summary>
        /// Sets an item in the cache of Type T with the key as the index value
        /// </summary>
        /// <typeparam name="T">The data type of the object to store in the cache</typeparam>
        /// <param name="key">The string key used as an index in the cache for the particular item</param>
        /// <param name="item">The object being stored in the cache</param>
        /// <param name="cacheExpiration">The cache duration</param>
        public static void SetCacheItem<T>(string key, T item, DateTime cacheExpiration)
        {
            SetCacheItem<T>(key, item, cacheExpiration, true);
        }

        /// <summary>
        /// Sets an item in the cache of Type T with the key as the index value
        /// </summary>
        /// <typeparam name="T">The data type of the object to store in the cache</typeparam>
        /// <param name="key">The string key used as an index in the cache for the particular item</param>
        /// <param name="item">The object being stored in the cache</param>
        /// <param name="cacheExpiration">The cache duration</param>
        /// <param name="replace">Flag to replace existing value</param>
        public static void SetCacheItem<T>(string key, T item, DateTime cacheExpiration, bool replace)
        {
            SetCacheItem<T>(key, item, cacheExpiration, replace, null);
        }

        /// <summary>
        /// Sets an item in the cache of Type T with the key as the index value
        /// </summary>
        /// <typeparam name="T">The data type of the object to store in the cache</typeparam>
        /// <param name="key">The string key used as an index in the cache for the particular item</param>
        /// <param name="item">The object being stored in the cache</param>
        /// <param name="cacheExpiration">The cache duration</param>
        /// <param name="replace">Flag to replace existing value</param>
        /// <param name="dependency">A cache dependency</param>
        public static void SetCacheItem<T>(string key, T item, DateTime cacheExpiration,
                                           bool replace, CacheDependency dependency)
        {
            //lock the cache for adding items
            lock (cache)
            {
                if (CacheContainsKey<T>(key))
                {
                    if (replace)
                    {
                        CacheManager.Remove(key);
                        CacheManager.Add(key, item, dependency, cacheExpiration,
                                         Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
                    }
                    else
                    {
                        throw new Exception("The Cache key '" + key + "' already exist. If you want to override existing value, use SetCacheItem function with OverrideValue parameter True");
                    }
                }
                else
                {
                    CacheManager.Add(key, item, dependency, cacheExpiration,
                                     Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Checks the cache to determine if an item of a particular type is stored
        /// </summary>
        /// <typeparam name="T">The data type of the object</typeparam>
        /// <param name="key">The index used for the object</param>
        /// <returns>True if the cache contains the item and false if it does not</returns>
        public static bool CacheContainsKey<T>(string key)
        {
            if (String.IsNullOrEmpty(key))
            {
                throw new NullReferenceException("Could not validate Cache key.  Cache key cannot have a null or empty value");
            }

            return (CacheManager[key] != null && CacheManager[key] is T);
        }

        /// <summary>
        /// This method generates a cache key based on object parameters and type passed in
        /// </summary>
        /// <typeparam name="T">The Generic Object Type to generate a key for</typeparam>
        /// <param name="p">List of parameters for key generation</param>
        /// <returns>A String Cache Key</returns>
        public static string GetCacheKey<T>(params object[] p)
        {
            if (p == null)
            {
                throw new NullReferenceException("Could not store value in cache.  Parameter object cannot be null");
            }

            StringBuilder key = new StringBuilder();

            p.Select(c =>
            {
                if (c != null)
                {
                    key.Append(c.ToString());
                }
                else
                {
                    key.Append(String.Empty);
                }
                return c;
            }).ToList();
            return String.Format("{0}_{1}", typeof(T), key.ToString());
        }
        #endregion
    }
}

