﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Framework.ExceptionHandling
{
    /// <summary>
    /// ArchitecturalException: Specific to the Architectural layer of services.
    /// </summary>
    public class ArchitecturalException : ExceptionBase
    {
        #region Constructor Logic

        /// <summary>
        ///  Base constructor
        /// </summary>
        public ArchitecturalException()
            : base()
        {
            initialize();
        }

        /// <summary>
        ///  Constructor setting message
        /// </summary>
        /// <param name="message">Exception message</param>
        public ArchitecturalException(string message)
            : base(message)
        {
            initialize();
        }

        /// <summary>
        ///  Constructor setting message and including an inner Exception
        /// </summary>
        /// <param name="message">Exception message</param>
        /// <param name="inner">Inner Exception</param>
        public ArchitecturalException(string message, Exception inner)
            : base(message, inner)
        {
            initialize();
        }

        /// <summary>
        /// Constructor used for serialization.
        /// ExtendedProperties are populated specifically
        /// by an overload of initialize method.
        /// </summary>
        /// <param name="info">SerializationInfo</param>
        /// <param name="context">StreamingContext</param>
        protected ArchitecturalException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            initialize();
        }

        #endregion :::Constructors:::

        /// <summary>
        /// Initialize this Exception
        /// </summary>
        protected override void initialize()
        {
            base.initialize();
            this.ExceptionType = "ArchitecturalException";
            this.ExceptionPolicyName = "ArchitecturalPolicy";
        }
    }
}
