﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Reflection;

namespace Iascend.Intranet.Framework.ExceptionHandling
{
    /// <summary>
    /// Use this as the base exception object for inheritance.
    /// Not intended for direct use.
    /// </summary>
    [Serializable]
    public class ExceptionBase : ApplicationException
    {
        #region Constructor Logic
        /// <summary>
        ///  Base constructor
        /// </summary>
        public ExceptionBase()
            : base()
        {
            initialize();
        }
        /// <summary>
        ///  Constructor setting message
        /// </summary>
        /// <param name="message">Exception message</param>
        public ExceptionBase(string message)
            : base(message)
        {
            initialize();
        }
        /// <summary>
        ///  Constructor setting message and including an inner Exception
        /// </summary>
        /// <param name="message">Exception message</param>
        /// <param name="inner">Inner Exception</param>
        public ExceptionBase(string message, Exception inner)
            : base(message, inner)
        {
            initialize();
        }
        /// <summary>
        /// Constructor used for serialization.
        /// ExtendedProperties are populated specifically
        /// by an overload of initialize method.
        /// </summary>
        /// <param name="info">SerializationInfo</param>
        /// <param name="context">StreamingContext</param>
        protected ExceptionBase(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            // TODO: Code the load of info into extendedProperties
            //initialize(info);
        }
        #endregion

        #region Protected members

        /// <summary>
        /// Extended information about the exception.
        /// </summary>
        protected Dictionary<string, object> extendedProperties;
        /// <summary>
        /// Notify() has been called.
        /// </summary>
        protected bool beenNotified = false;
        #endregion

        #region public Properties
        /// <summary>
        /// Notify() has been called.
        /// </summary>
        public bool BeenNotified
        {
            get { return beenNotified; }
        }
        /// <summary>
        /// Extended information about the exception.
        /// </summary>
        public Dictionary<string, object> ExtendedProperties
        {
            get { return extendedProperties; }
            set { extendedProperties = value; }
        }

        public string ApplicationName
        {
            get { return (string)extendedProperties["ApplicationName"]; }
        }

        public string ExceptionType
        {
            get
            {
                return (string)extendedProperties["ExceptionType"];
            }
            set
            {
                if (extendedProperties.ContainsKey("ExceptionType"))
                    extendedProperties["ExceptionType"] = value;
                else
                    extendedProperties.Add("ExceptionType", value);
            }
        }

        public string ExceptionPolicyName
        {
            get
            {
                return (string)extendedProperties["ExceptionPolicy"];
            }
            set
            {
                if (extendedProperties.ContainsKey("ExceptionPolicy"))
                    extendedProperties["ExceptionPolicy"] = value;
                else
                    extendedProperties.Add("ExceptionPolicy", value);
            }
        }
        #endregion

        #region public methods
        public object GetProperty(string propertyName)
        {
            return extendedProperties[propertyName];
        }

        public void SetProperty(string propertyName, object propertyValue)
        {
            if (extendedProperties.ContainsKey(propertyName))
                extendedProperties[propertyName] = propertyValue;
            else
                extendedProperties.Add(propertyName, propertyValue);
        }

        public void SetExceptionSource(object classForType)
        {
            this.Source = ExceptionHelper.GetExceptionSource(classForType);
        }
        public void SetExceptionSource(string className)
        {
            this.Source = ExceptionHelper.GetExceptionSource(className);
        }

        /// <summary>
        /// Method to invoke ExceptionPolicy.HandleException
        /// </summary>
        /// <returns>bool</returns>
        public bool Notify()
        {
            StringBuilder sb = new StringBuilder();
            foreach (string key in this.ExtendedProperties.Keys)
            {
                try { sb.Append(key + " = " + this.ExtendedProperties[key].ToString() + "\n\r"); }
                catch { }
            }

            this.HelpLink = sb.ToString();

            beenNotified = true;
            return ExceptionPolicy.HandleException(this, (string.IsNullOrEmpty(this.ExceptionPolicyName) ? this.ExceptionType + "Policy" : this.ExceptionPolicyName));
        }

        public string GetFormattedMessage()
        {
            StringBuilder sb = new StringBuilder();
            Exception e = this;
            sb.Append(this.Message);
            while (e.InnerException != null)
            {
                sb.Append("-->");
                sb.Append(e.InnerException.Message);
                e = e.InnerException;
            }

            return sb.ToString();
        }
        #endregion

        #region protected methods
        /// <summary>
        /// Initialize this Exception
        /// </summary>
        protected virtual void initialize()
        {
            extendedProperties = new Dictionary<string, object>();
        }

        /// <summary>
        /// Populate the details of this Exception
        /// </summary>
        protected virtual void populateDetails()
        {
            StackTrace trace = new StackTrace();
            StackFrame frame = trace.GetFrame(1);
            MethodBase method = frame.GetMethod();
        }
        #endregion
    }	
}
