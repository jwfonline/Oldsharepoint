﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Security.Principal;
using System.Diagnostics;
using System.Reflection;
using Iascend.Intranet.Framework.Enumerations;



namespace Iascend.Intranet.Framework.ExceptionHandling
{
    /// <summary>
    /// ExceptionHelper: A helper class for exception handling.
    /// 
    /// </summary>
    public class ExceptionHelper
    {
        #region privates
        private static string securityInfoFormat = "Principal Values for current thread:" +
                                                    "\n\nPrincipal Name: {0}" +
                                                    "Principal Type: {1}" +
                                                    "Principal IsAuthenticated: {2}" +
                                                    "\n\nIdentity Values for current thread:" +
                                                    "Identity Name: {3}" +
                                                    "Identity Type: {4}" +
                                                    "Identity Token: {5}";
        #endregion

        #region properties
        public static string SecurityInfoFormat
        {
            get { return ExceptionHelper.securityInfoFormat; }
            set { ExceptionHelper.securityInfoFormat = value; }
        }
        #endregion

        #region public Handler method (HandleException)
        /// <summary>
        /// HandleException: As a means to handle an exception by Type().
        /// The Exception.GetType() will map to the applicable ExpPolicy enum
        /// and thus mapping to the applicable Enterprise Library Policy.
        /// Available mapping:
        /// ExpPolicy.Architecture
        /// ExpPolicy.DataAccess
        /// ExpPolicy.DataAccessCritical
        /// ExpPolicy.General
        /// ExpPolicy.Security
        /// ExpPolicy.Service
        /// ExpPolicy.UserInterface        
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - Rethrow</returns>
        public static bool HandleException(Exception ex)
        {
            string exceptionType = ex.GetType().ToString().Replace(ex.GetType().Namespace, String.Empty).ToLower();
            switch (exceptionType)
            {
                case "security":
                    return handleSecurityException(ex);

                case "sqlexception":
                case "dbconcurrencyexception":
                    return handleDataAccessCriticalException(ex);

                default:
                    return handleGeneralException(ex);

            }
        }
        /// <summary>
        /// HandleException: As a means to handle an exception by ExpPolicy enum
        /// and thus mapping to the applicable Enterprise Library Policy.
        /// Available mapping:
        /// ExpPolicy.Architecture
        /// ExpPolicy.DataAccess
        /// ExpPolicy.DataAccessCritical
        /// ExpPolicy.General
        /// ExpPolicy.Security
        /// ExpPolicy.Service
        /// ExpPolicy.UserInterface        
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <param name="policy">ExpPolicy enum</param>
        /// <returns>bool - Rethrow</returns>
        public static bool HandleException(Exception ex, ExpPolicy policy)
        {
            switch (policy)
            {
                case ExpPolicy.Architectural:
                    return handleCachingException(ex);

                case ExpPolicy.DataAccess:
                    return handleDataAccessException(ex);

                case ExpPolicy.DataAccessCritical:
                    return handleDataAccessCriticalException(ex);

                case ExpPolicy.General:
                    return handleGeneralException(ex);

                case ExpPolicy.UserInterface:
                    return handleUserInterfaceException(ex);

                case ExpPolicy.Service:
                    return handleServiceException(ex);

                case ExpPolicy.Security:
                    return handleSecurityException(ex);

                default:
                    return handleGeneralException(ex);

            }
        }
        #endregion

        #region handleException protected methods
        /// <summary>
        /// Handle Caching exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleCachingException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.Architectural) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }

        /// <summary>
        /// Handle DataAccess exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleDataAccessException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.DataAccess) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }

        /// <summary>
        /// Handle DataAccessCritical exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleDataAccessCriticalException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.DataAccessCritical) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }

        /// <summary>
        /// Handle General exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleGeneralException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.General) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }
        /// <summary>
        /// Handle UserInterface exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleUserInterfaceException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.UserInterface) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }

        /// <summary>
        /// Handle Service exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleServiceException(Exception ex)
        {
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(ex, Enum.GetName(typeof(ExpPolicy), ExpPolicy.Service) + "Policy", out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }
        /// <summary>
        /// Handle Security exceptions
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>bool - rethrow</returns>
        protected static bool handleSecurityException(Exception ex)
        {


            Exception exp = new Exception(getExceptionInfo(ex) + ExceptionHelper.GetIdentityInfo(), ex);
            Exception toThrow;
            bool rethrow = ExceptionPolicy.HandleException(exp, Enum.GetName(typeof(ExpPolicy), ExpPolicy.Security), out toThrow);
            if (rethrow)
            {
                if (!(toThrow == null))
                    throw toThrow;
                else
                    throw ex;
            }
            return rethrow;
        }
        #endregion

        #region public helper methods
        /// <summary>
        /// Supplies a formatted set of Principal and Identity informational items. 
        /// </summary>
        /// <returns>string - formatted.</returns>
        public static string GetIdentityInfo()
        {
            try
            {
                //Get the current identity and put it into an identity object.
                WindowsIdentity myIdentity = WindowsIdentity.GetCurrent();

                //Put the previous identity into a principal object.
                WindowsPrincipal myPrincipal = new WindowsPrincipal(myIdentity);

                //Principal values.
                string principalName = myPrincipal.Identity.Name;
                string principalType = myPrincipal.Identity.AuthenticationType;
                string principalAuth = myPrincipal.Identity.IsAuthenticated.ToString();

                //Identity values.
                string identName = myIdentity.Name;
                string identType = myIdentity.AuthenticationType;
                string identToken = myIdentity.Token.ToString();

                //Print the values.
                return String.Format(securityInfoFormat,
                                    principalName, principalType, principalAuth,
                                    identName, identType, identToken);
            }
            catch { return String.Empty; }
        }

        public static string GetExceptionSource(object classType)
        {
            StackTrace stackTrace = new StackTrace();
            StackFrame stackFrame = new StackFrame(1);
            MethodBase methodBase = stackFrame.GetMethod();
            return classType.GetType().ToString() + "::" + stackFrame.GetMethod().Name;
        }
        public static string GetExceptionSource(string className)
        {
            StackTrace stackTrace = new StackTrace();
            StackFrame stackFrame = new StackFrame(1);
            MethodBase methodBase = stackFrame.GetMethod();
            return className + "::" + stackFrame.GetMethod().Name;
        }
        #endregion

        #region protected helper methods
        /// <summary>
        /// Using and extension of Ent Lib's TextExceptionFormatter, AppTextExceptionFormatter, 
        /// format the exception content.
        /// </summary>
        /// <param name="ex">Exception to format</param>
        /// <returns>string - Fomatted context</returns>
        protected static string getExceptionInfo(Exception ex)
        {
            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);

            // TODO: Excluded-working
            //AppTextExceptionFormatter formatter = new AppTextExceptionFormatter(writer, ex);

            //// Format the exception
            //formatter.Format();

            return sb.ToString();
        }

        #endregion
    }
}
