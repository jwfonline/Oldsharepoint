using System;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace Iascend.Intranet.Framework.Services
{
    /// <summary>
    /// This class extends the IConfigurationSectionHandler.  It allows a generic section to be read out of the
    /// web.config and the type to be specified in the actual config file.
    /// </summary>
	public class XmlConfigurator : System.Configuration.IConfigurationSectionHandler
	{
		#region Constructors, destructors and initializers

		public XmlConfigurator()
		{
		}

		#endregion

		#region Public methods

        /// <summary>
        /// This method attempts to create a settings object
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="configContext"></param>
        /// <param name="section"></param>
        /// <returns></returns>
		public object Create(object parent, object configContext, System.Xml.XmlNode section)
		{
			object settings = null;

			if (section == null) { return settings; }

			XPathNavigator navigator = section.CreateNavigator();
			String typeName = (string)navigator.Evaluate("string(@type)");
			Type sectionType = Type.GetType(typeName);

			XmlSerializer xs = new XmlSerializer(sectionType);
			XmlNodeReader reader = new XmlNodeReader(section);

			try
			{
				settings = xs.Deserialize(reader);
			}
			catch(Exception ex)
			{
                throw 
                    new InvalidCastException(
                        "Could not cast xml configuration block to object, check xml properties", ex);
			}


			return settings;
		}


		#endregion
	}
}