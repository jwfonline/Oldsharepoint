﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Iascend.Intranet.Framework.Services
{
    /// <summary>
    /// Simple encryption/decryption class.
    /// Provides consistent encryption/decryption functionality using 
    /// embedded, immutable key and salt values.  So data encryption and decryption
    /// can span multiple sessions and multiple days.
    /// </summary>
    public class CryptoService
    {
        private byte[] _strPrivateKey = { 73, 58, 50, 30, 79, 72, 75, 49, 56, 8, 31, 9, 26, 18, 81, 13 };

        private byte[] _strSalt = { 86, 75, 41, 24, 53, 27, 49, 58, 20, 37, 8, 30, 83, 68, 11, 55 };


        /// <summary>
        /// Property for PrivateKey Value
        /// </summary>
        private Byte[] PrivateKey
        {
            get
            {
                return _strPrivateKey;
            }
        }

        /// <summary>
        /// Property for the Salt Value
        /// </summary>
        private Byte[] Salt
        {
            get
            {
                return _strSalt;
            }
        }

        /// <summary>
        /// Encrypt the passed string
        /// </summary>
        /// <PARAM name="plainTextString"></PARAM>
        /// String to Encrypt
        public string EncryptString(string plainTextString)
        {
            string strValue = String.Empty;

            try
            {
                System.Security.Cryptography.RijndaelManaged cryptObj = new RijndaelManaged();

                if (plainTextString != string.Empty)
                {
                    MemoryStream ms = new MemoryStream();
                    CryptoStream cs = new CryptoStream(ms, cryptObj.CreateEncryptor(PrivateKey, Salt), CryptoStreamMode.Write);
                    StreamWriter sw = new StreamWriter(cs);
                    sw.Write(plainTextString);
                    sw.Flush();
                    cs.FlushFinalBlock();
                    ms.Flush();
                    strValue = Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
                }
                else
                {
                    strValue = string.Empty;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to Encrypt string: \r\n\r\n " + ex.Message.ToString());
            } // Return the Encrypted String

            return strValue;
        }

        /// <summary>
        /// Decrypt the passed string
        /// </summary>
        /// <PARAM name="encryptTextString"></PARAM>
        /// String to Decrypt
        public string DecryptString(string encodedTextString)
        {
            string strValue = String.Empty;

            try
            {
                System.Security.Cryptography.RijndaelManaged cryptObj = new RijndaelManaged();
                //cryptObj.Padding = PaddingMode.None;
                //cryptObj.Mode = CipherMode.CBC;

                if (encodedTextString != string.Empty)
                {
                    byte[] buf = Convert.FromBase64String(encodedTextString.Trim());
                    MemoryStream ms = new MemoryStream(buf);
                    ms.Position = 0;
                    CryptoStream cs = new CryptoStream(ms, cryptObj.CreateDecryptor(PrivateKey, Salt), CryptoStreamMode.Read);
                    StreamReader sr = new StreamReader(cs);
                    strValue = sr.ReadToEnd();
                }
                else
                {
                    strValue = String.Empty;
                }
            }
            catch (Exception ex)
            {
                // Make sure that the application that is consuming this
                // .DLL gets the message returned so it can be displayed.
                throw new Exception("Unable to Decrypt string: \r\n\r\n " + ex.Message.ToString());
            }

            // Return the decrypted text
            return strValue;
        }

        /// <summary>
        /// Encode the passed string
        /// </summary>
        /// <PARAM name="encryptedTextString"></PARAM>
        /// Encrypted String to Encode
        public string EncodeString(string encryptedTextString)
        {
            // Local Declarations
            byte[] baValue = null;
            string strValue = String.Empty;

            try
            {
                // Encode the Passed String
                baValue = Encoding.Unicode.GetBytes(encryptedTextString);
                strValue = Convert.ToBase64String(baValue);
            }
            catch (Exception ex)
            {
                // Make sure that the application that is consuming this
                // .DLL gets the message returned so it can be displayed.
                throw new Exception("Unable to Encode string: \r\n\r\n " + ex.Message.ToString());
            }

            // Return the Encoded Value
            return strValue;
        }

        /// <summary>
        /// Decode the passed string
        /// </summary>
        /// <PARAM name="encodedTextString"></PARAM>
        /// Encoded String to Decode
        public string DecodeString(string encodedTextString)
        {
            // Local Declarations
            byte[] baValue = null;
            string strValue = String.Empty;
            try
            {
                // Decode the Passed String
                baValue = Convert.FromBase64String(encodedTextString);
                strValue = Encoding.Unicode.GetString(baValue);
            }
            catch (Exception ex)
            {
                // Make sure that the application that is consuming this
                // .DLL gets the message returned so it can be displayed.
                throw new Exception("Unable to Decode string: \r\n\r\n " + ex.Message.ToString());
            }

            // Return the Decoded String
            return strValue;
        }

    }
}
