﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Helpers;

namespace Iascend.Intranet.Framework.Services
{
    public static class ConfigurationService
    {
        #region Public Static Helper Properties

        public static double GetDoubleValue(string key)
        {
            double retval = default(double);
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                double.TryParse(ConfigurationHelper.GetFromAppSettings(key).Trim(), out retval);
            }
            return retval;
        }

        public static string GetStringValue(string key)
        {
            string retval = string.Empty;
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                 retval = ConfigurationHelper.GetFromAppSettings(key).Trim();
            }
            return retval;
        }

        public static void SetStringValue(string key, string value)
        {
            string retval = string.Empty;
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                ConfigurationManager.AppSettings[key] = value;
            }
        }

        public static int GetIntValue(string key)
        {
            int retval = default(int);
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                int.TryParse(ConfigurationHelper.GetFromAppSettings(key).Trim(), out retval);
            }
            return retval;
        }

        public static long GetLongValue(string key)
        {
            long retval = default(long);
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                long.TryParse(ConfigurationHelper.GetFromAppSettings(key).Trim(), out retval);
            }
            return retval;
        }

        public static bool GetBoolValue(string key)
        {
            bool retval = default(bool);
            if (!ConfigurationHelper.GetFromAppSettings(key).IsNullEmptyOrEmptySpaces())
            {
                bool.TryParse(ConfigurationHelper.GetFromAppSettings(key).Trim(), out retval);
            }
            return retval;
        }

        public static string GetUrlValue(string key)
        {
            string retval = ConfigurationHelper.GetFromAppSettings(key);

            if (!retval.IsNullEmptyOrEmptySpaces())
            {
                if (retval.Trim().EndsWith("/"))
                {
                    retval = retval.Substring(0, retval.Length - 1);
                }
                else
                {
                    retval = retval.Trim();
                }
            }
            return retval;
        }

        public static Dictionary<string, string> GetDictionary(string key)
        {
            Dictionary<string, string> retval = new Dictionary<string, string>();
            string values = ConfigurationHelper.GetFromAppSettings(key).ToString();

            if (!values.IsNullEmptyOrEmptySpaces())
            {
                string[] data = values.Split(',');
                if (data.Length > 0)
                {
                    foreach (string item in data)
                    {
                        string trimmed = item.Trim();
                        if (!retval.ContainsKey(trimmed))
                        {
                            retval.Add(trimmed, trimmed);
                        }
                    }
                }
            }
            return retval;
        }

        public static List<string> GetList(string key)
        {
            List<string> retval = new List<string>();
            string values = ConfigurationHelper.GetFromAppSettings(key).ToString();

            if (!values.IsNullEmptyOrEmptySpaces())
            {
                string[] data = values.Split(',');
                if (data.Length > 0)
                {
                    foreach (string item in data)
                    {
                        retval.Add(item.Trim());
                    }
                }
            }
            return retval;
        }

        #endregion

        #region Public Static AppSettings Properties

        public static List<string> AllowedUploadDemographicExtensions
        {
            get
            {
                return GetList("AllowedUploadDemographicExtensions");
            }
        }

        public static List<string> AllowedUploadPayrollExtensions
        {
            get
            {
                return GetList("AllowedUploadPayrollExtensions");
            }
        }

        public static double AnnualSalaryIncrease
        {
            get
            {
                return GetDoubleValue("AnnualSalaryIncrease");
            }
        }

        public static double ShortCachingDuration
        {
            get
            {
                return GetDoubleValue("ShortCachingDuration");
            }
        }

        public static double LongCachingDuration
        {
            get
            {
                return GetDoubleValue("LongCachingDuration");
            }
        }

        public static string ChartErrorImage
        {
            get
            {
                return GetStringValue("ChartErrorImage");
            }
        }

        public static string ErrorUrl
        {
            get
            {
                return GetStringValue("ErrorUrl");
            }
        }

        public static string ChartSkinPath
        {
            get
            {
                return GetStringValue("ChartSkinPath");
            }
        }

        /// <summary>
        /// This expects to return the maximum file size in KB
        /// </summary>
        public static long DemographicUploadMaxFileSize
        {
            get
            {
                return GetLongValue("DemographicUploadMaxFileSize");
            }
        }

        public static double InflationRate
        {
            get
            {
                return GetDoubleValue("InflationRate");
            }
        }

        public static double InterestRate
        {
            get
            {
                return GetDoubleValue("InterestRate");
            }
        }

        public static int EstimatorMaximumYearsOfService
        {
            get
            {
                return GetIntValue("EstimatorMaximumYearsOfService");
            }
        }

        public static int EstimatorStartingSalary
        {
            get
            {
                return GetIntValue("EstimatorStartingSalary");
            }
        }

        public static int EstimatorMinimumSalary
        {
            get
            {
                return GetIntValue("EstimatorMinimumSalary");
            }
        }

        public static int EstimatorMaximumSalary
        {
            get
            {
                return GetIntValue("EstimatorMaximumSalary");
            }
        }

        public static int EstimatorStartingAge
        {
            get
            {
                return GetIntValue("EstimatorStartingAge");
            }
        }

        public static int EstimatorMinimumAge
        {
            get
            {
                return GetIntValue("EstimatorMinimumAge");
            }
        }

        public static int EstimatorMaximumAge
        {
            get
            {
                return GetIntValue("EstimatorMaximumAge");
            }
        }

        public static int EstimatorDefaultEmployerNumber
        {
            get
            {
                return GetIntValue("EstimatorDefaultEmployerNumber");
            }
        }

        public static int EstimatorRetirementAge
        {
            get
            {
                return GetIntValue("EstimatorRetirementAge");
            }
        }

        public static string SharepointSiteUrl
        {
            get
            {
                if (!GetUrlValue("SharepointSiteUrl").IsNullEmptyOrEmptySpaces())
                {
                    return GetUrlValue("SharepointSiteUrl");
                }

                return null;
            }
        }

        public static string MemberTCDRSSite
        {
            get
            {
                return GetUrlValue("MemberTCDRSSite");
            }
        }

        public static string EmployerTCDRSSite
        {
            get
            {
                return GetUrlValue("EmployerTCDRSSite");
            }
        }

        public static string MemberSignOutUrl
        {
            get
            {
                return GetUrlValue("MemberSignOutUrl");
            }
        }

        public static string EmployerSignOutUrl
        {
            get
            {
                return GetUrlValue("EmployerSignOutUrl");
            }
        }

        public static string PublicTCDRSSite
        {
            get
            {
                return GetUrlValue("PublicTCDRSSite");
            }
        }

        public static bool IsSecuredSite
        {
            get
            {
                return GetBoolValue("IsSecuredSite");
            }
        }

        public static string CustomerServiceEmail
        {
            get
            {
                return GetStringValue("CustomerServiceEmail");
            }
        }

        /// <summary>
        /// This expects to return the maximum file size in KB
        /// </summary>
        public static long PayrollUploadMaxFileSize
        {
            get
            {
                return GetLongValue("PayrollUploadMaxFileSize");
            }
        }

       
        public static string MonthYearPattern
        {
            get
            {
                return GetStringValue("MonthYearPattern");
            }
        }

        public static string ShortDatePattern
        {
            get
            {
                return GetStringValue("ShortDatePattern");
            }
        }

        public static string EmployerFilesLocation
        {
            get
            {
                return GetStringValue("EmployerFilesLocation");
            }
        }

        public static string Domain
        {
            get
            {
                return GetStringValue("Domain");
            }
        }

        public static string CookieDomain
        {
            get
            {
                return GetStringValue("CookieDomain");
            }
        }

        public static int AuthenticationReminderInterval
        {
            get
            {
                return GetIntValue("AuthenticationReminderInterval");
            }
        }

        public static bool AuthenticationAutoRevalidate
        {
            get
            {
                return GetBoolValue("AuthenticationAutoRevalidate");
            }
        }

        public static string SmtpServer
        {
            get
            {
                return GetStringValue("SmtpServer");
            }
        }

        public static string SmtpUser
        {
            get
            {
                return GetStringValue("SmtpUser");
            }
        }

        public static string SmtpPassword
        {
            get
            {
                return GetStringValue("SmtpPassword");
            }
        }


        public static int ActivationLinkExpirationDays
        {
            get
            {
                return GetIntValue("ActivationLinkExpirationDays");
            }
        }
        #endregion

    }
}
