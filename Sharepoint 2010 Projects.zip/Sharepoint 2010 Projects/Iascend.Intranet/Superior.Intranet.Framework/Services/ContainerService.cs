﻿using System;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;


namespace Iascend.Intranet.Framework.Services
{
    /// <summary>
    /// ContainerService is an abstraction of the functionality used
    /// to retrieve interface and object instances and dependencies from
    /// the dependency injection framework.  The current implementation
    /// uses Microsoft Unity Application Block as the dependency injection
    /// framework for this application
    /// </summary>
    public class ContainerService
    {
        private readonly UnityContainer _UnityContainer;

        #region Thread-safe, lazy Singleton

        private ContainerService()
        {
            _UnityContainer = new UnityContainer();

            FileConfigurationSource unityConfigSource = 
                new FileConfigurationSource("Unity.config");

            UnityConfigurationSection section = 
                (UnityConfigurationSection)unityConfigSource.GetSection("unity");

            section.Containers.Default.Configure(_UnityContainer);
        }

        public static ContainerService Instance
        {
            get
            {
                return Nested.instance;
            }
        }

        class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly ContainerService instance = new ContainerService();
        }

        #endregion


        #region Generic Unity retrieval method

        /// <summary>
        /// Retrieves an instance of type T 
        /// </summary>
        /// <typeparam name="T">the type of instance(object) to return</typeparam>
        /// <returns>
        /// returns an instance of type T 
        /// </returns>
        public T Retrieve<T>()
        {
            return _UnityContainer.Resolve<T>();
        }

        /// <summary>
        /// Retrieves an instance of the specified type
        /// </summary>
        /// <param name="type">the type to return</param>
        /// <returns>
        /// returns an instance of the specified type
        /// </returns>
        public object Retrieve(Type type)
        {
            return _UnityContainer.Resolve(type);
        }

        #endregion
    }
}
