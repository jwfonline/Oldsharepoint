﻿using System.Collections.Generic;
using Iascend.Intranet.Framework.Model.Attributes;

namespace Iascend.Intranet.Framework.Constants
{
    public enum TracingEvent
    {
        MethodStart = 1,
        MethodEnd = 2,
    }

    public enum ErrorCategory
    {
        Unhandled = 1,
        WebApp = 2,
        Service = 3,
        Data = 4,
    }

    public enum LogCategory
    {
        ApplicationLayer,
        ServiceLayer,
        DataLayer,
    }

    public enum LogPriority
    {
        VeryLow = 1,
        Low = 2,
        Medium = 3,
        High = 4,
        VeryHigh = 5,
    }


    public enum ExceptionType
    {
        General = 0,
        Database = 1,

    }

    public enum SerializerType
    {
        JavaScriptSerializer = 1,
        DataContractSerializer = 2
    }

    /// <summary>
    /// Activities types that need logging.
    /// </summary>
    public enum ActivityType
    {
        [StringValue("Not Set")]
        NotSet = 0,

        #region Payroll

        [StringValue("View All Payroll Records")]
        ViewAllPayrollRecords = 1,
        [StringValue("View Payroll Record")]
        ViewPayrollRecord = 2,
        [StringValue("Add Payroll Record")]
        AddPayrollRecord = 3,
        [StringValue("Update Payroll Record")]
        UpdatePayrollRecord = 4,
        [StringValue("Delete Payroll Record")]
        DeletePayrollRecord = 5,
        [StringValue("Payroll File Uploaded")]
        PayrollFileUploaded = 6,
        [StringValue("Payroll File Deleted")]
        PayrollFileDeleted = 7,

        #endregion

        #region Demographic

        [StringValue("View All Demographic Records")]
        ViewAllDemographicRecords = 51,
        [StringValue("View Demographic Record")]
        ViewDemographicRecord = 52,
        [StringValue("Add Demographic Record")]
        AddDemographicRecord = 53,
        [StringValue("Update Demographic Record")]
        UpdateDemographicRecord = 54,
        [StringValue("Delete Demographic Record")]
        DeleteDemographicRecord = 55,
        [StringValue("Demographic File Uploaded")]
        DemographicFileUploaded = 56,
        [StringValue("Demographic File Deleted")]
        DemographicFileDeleted = 57,

        #endregion

        #region Contacts

        [StringValue("View All Contact Records")]
        ViewAllContactRecords = 101,
        [StringValue("View Contact Record")]
        ViewContactRecord = 102,
        [StringValue("Add Contact Record")]
        AddContactRecord = 103,
        [StringValue("Update Contact Record")]
        UpdateContactRecord = 104,
        [StringValue("Delete Contact Record")]
        DeleteContactRecord = 105,

        #endregion

        #region Other

        [StringValue("Disable Login")]
        DisableLogin = 151,
        [StringValue("Login")]
        Login = 152,
        [StringValue("Registration Completed")]
        RegistrationCompleted = 153,
        [StringValue("User Activated")]
        UserActivated = 154,
        [StringValue("Email Send To User")]
        EmailSendToUser = 155,
        [StringValue("Password Reset Requested")]
        PasswordResetRequested = 156,
        [StringValue("Password Reset Completed")]
        PasswordResetCompleted = 157,
        [StringValue("Estimator Receipt")]
        EstimatorReceipt = 158,
        [StringValue("Annuity Verification")]
        AnnuityVerification = 159,
        [StringValue("Employee Lookup")]
        EmployeeLookup = 160,
        [StringValue("User Profile Updated")]
        UserProfileUpdated = 161,

        #endregion
    }
}
