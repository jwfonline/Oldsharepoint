﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using Iascend.Intranet.Framework.Enumerations;

namespace Iascend.Intranet.Framework.Model.SharePoint
{
    /// <summary>
    /// This is a filter class for SharePoint Queries.  It provides flexible storage for
    /// the field name, the value, and the value type
    /// </summary>
    [DataContract]
    public class FilterField
    {
        [DataMember]
        public string FieldName{get; set;}
        [DataMember]
        public string FieldValue{get; set;}
        [DataMember]
        public FieldValueType FieldValueType { get; set; }
        [DataMember]
        public IndividualQueryOperation OperationType { get; set; }
    }
}
