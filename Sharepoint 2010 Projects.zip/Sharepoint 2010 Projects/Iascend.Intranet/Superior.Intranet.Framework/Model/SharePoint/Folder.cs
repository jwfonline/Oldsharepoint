﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Iascend.Intranet.Framework.Model.SharePoint
{
    [DataContract]
    public class Folder
    {
        [DataMember]
        public string FolderName { get; set; }
    }
}
