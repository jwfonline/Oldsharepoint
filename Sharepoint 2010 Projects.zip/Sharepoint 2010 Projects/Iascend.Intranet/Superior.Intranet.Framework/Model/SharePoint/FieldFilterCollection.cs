﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using Iascend.Intranet.Framework.Enumerations;

namespace Iascend.Intranet.Framework.Model.SharePoint
{
    /// <summary>
    /// This class contains a collection of filter fields with a sub collection of
    /// filter fields for multi-aggregate operations
    /// Example, to perform an Or check within an And check,
    /// 1) Create a top level field filter collection with all individual elements for AND
    /// 2) Set top level FFC QueryOperation property to AND
    /// 3) Add all OR elements to the FFC ChildFilterCollection
    /// 4) Set FFC ChildFilterCollection Query Operation property to OR
    /// </summary>
    [DataContract]
    public class FieldFilterCollection : List<FilterField>
    {
        private FieldFilterCollection _ChildFilterCollection;
        /// <summary>
        /// This property returns a child filter collection of objects
        /// This providers unlimited recursive support for complicated sharepoint queries.
        /// </summary>
        [DataMember]
        public FieldFilterCollection ChildFilterCollection
        {
            get
            {
                if (_ChildFilterCollection == null)
                {
                    _ChildFilterCollection = new FieldFilterCollection();
                }
                return _ChildFilterCollection;
            }
        }
        [DataMember]
        public AggregateQueryOperation QueryOperation { get; set; }
    }
}
