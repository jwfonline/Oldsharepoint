﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Model
{
    /// <summary>
    /// This class providers a link list wrapper functionality for another class
    /// Great for use with Linq when you need access to previous or next elements and
    /// still retain performance
    /// </summary>
    /// <typeparam name="T">The object type being wrapped/stored</typeparam>
    public class ElementWithContext<T>
    {
        public T Previous { get; private set; }
        public T Current { get; private set; }
        public T Next { get; private set; }
        public int Index { get; private set; }

        // These two properties could become performance hits with large lists
        public IEnumerable<T> Preceding { get; private set; }
        public IEnumerable<T> Following { get; private set; }

        public ElementWithContext(T previous, T current, T next,
                                  int index, IEnumerable<T> preceding, 
                                  IEnumerable<T> following)
        {
            Current = current;
            Previous = previous;
            Next = next;
            Index = index;
            Preceding = preceding;
            Following = following;
        }
    }
}
