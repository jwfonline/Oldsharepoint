﻿using System.Collections.Specialized;

namespace Iascend.Intranet.Framework.Model.Configuration
{
    public interface IAppConfig
    {
        NameValueCollection AppSettings {get;}
        
    }
}
