﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Model.Attributes
{
    public class SortOrderAttribute : Attribute
    {
        #region Properties

        /// <summary>
        /// Holds the object value for a value in an enum.
        /// </summary>
        public object SortOrder { get; protected set; }
        public Type SortOrderType { get; protected set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor used to init a ObjectValue Attribute
        /// </summary>
        /// <param name="value"></param>
        public SortOrderAttribute(Type type, object value)
        {
            this.SortOrderType = type;
            this.SortOrder = value;
        }

        #endregion
    }
}
