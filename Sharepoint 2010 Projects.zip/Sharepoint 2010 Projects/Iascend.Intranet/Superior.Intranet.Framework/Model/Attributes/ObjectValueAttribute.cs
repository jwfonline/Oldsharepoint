﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Model.Attributes
{
    public class ObjectValueAttribute : Attribute
    {
        #region Properties

        /// <summary>
        /// Holds the object value for a value in an enum.
        /// </summary>
        public object ObjectValue { get; protected set; }
        public Type ObjectType { get; protected set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor used to init a ObjectValue Attribute
        /// </summary>
        /// <param name="value"></param>
        public ObjectValueAttribute(Type type, object value)
        {
            this.ObjectType = type;
            this.ObjectValue = value;
        }

        #endregion
    }
}
