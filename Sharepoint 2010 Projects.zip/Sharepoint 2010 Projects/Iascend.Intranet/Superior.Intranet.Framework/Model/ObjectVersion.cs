﻿using System;

namespace Iascend.Intranet.Framework.Model
{
    [Serializable]
    public class ObjectVersion
    {

        /// <summary>
        /// Constructor which sets both values, previous and current.
        /// </summary>
        /// <param name="previousValue">Object's property previous value</param>
        /// <param name="currentValue">Object's property current value</param>
        public ObjectVersion(string previousValue, string currentValue)
        {
            this.PreviousValue = previousValue;
            this.CurrentValue = currentValue;
        }

        /// <summary>
        /// Object's property previous value
        /// </summary>
        public string PreviousValue { get; set; }
        /// <summary>
        /// Object's property current value
        /// </summary>
        public string CurrentValue { get; set; }
    }
}
