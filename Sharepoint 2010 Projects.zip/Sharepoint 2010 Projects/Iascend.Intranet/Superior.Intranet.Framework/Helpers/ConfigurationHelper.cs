﻿using System;
using System.Collections.Specialized;
using System.Configuration;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Helper class to manage the application configuration values.
    /// Provides static helper methods to get/set config values from configuration files.
    /// </summary>
    public static class ConfigurationHelper
    {
        /// <summary>
        /// This method attempts to get a value from a specified section name in the config
        /// </summary>
        /// <param name="sectionName">The name of the section to lookup</param>
        /// <param name="keyName">The key to look a section up</param>
        /// <returns>Section Value as String</returns>
        public static string GetValueFromSection(string sectionName, string keyName)
        {
            string val = String.Empty;

            if (!string.IsNullOrEmpty(sectionName) && !string.IsNullOrEmpty(keyName))
            {
                NameValueCollection nvc = (NameValueCollection)ConfigurationManager.GetSection(sectionName);

                if (nvc == null)
                {
                    throw (new NullReferenceException("Section Name not found : " + sectionName));
                }
                else
                {
                    // do nothing
                }

                val = nvc.Get(keyName);
            }

            return val;
        }

        /// <summary>
        /// This method gets an appsettings value by key name
        /// </summary>
        /// <param name="key">The key to lookup by</param>
        /// <returns>The value from the configuration via the key</returns>
        public static string GetFromAppSettings(string key)
        {
            string val = String.Empty;

            if(!string.IsNullOrEmpty(key))
            {
                val = ConfigurationManager.AppSettings[key];
            }
            else
            {
                // do nothing
            }

            return val;
        }
    }
}
