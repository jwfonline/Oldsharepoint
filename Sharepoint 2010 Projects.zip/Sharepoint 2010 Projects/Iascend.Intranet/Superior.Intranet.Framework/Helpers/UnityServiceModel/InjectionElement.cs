﻿using System;
using System.Configuration;
using System.ServiceModel.Configuration;

using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace Iascend.Intranet.Framework.Helpers.UnityServiceModel
{
    /// <summary>
    /// Injection element class representing a behavior extension configuration tag.
    /// </summary>
    public class InjectionElement : BehaviorExtensionElement
    {
        /// <summary>
        /// Default Unity configuration section path.
        /// </summary>
        private const string DefaultUnityConfigurationSectionPath = "unity";

        /// <summary>
        /// Initializes a new instance of the InjectionElement class.
        /// </summary>
        public InjectionElement()
        {
            this.UnityConfigurationSectionPath = DefaultUnityConfigurationSectionPath;
        }

        /// <summary>
        /// Gets the type of behavior.
        /// </summary>
        /// <value>Behavior type.</value>
        public override Type BehaviorType
        {
            get
            {
                return typeof(InjectionBehavior);
            }
        }
        
        /// <summary>
        /// Gets or sets the injection container name.
        /// </summary>
        /// <value>Container name.</value>
        [ConfigurationProperty("containerName")]
        public string ContainerName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Unity configuration section path to read configuration from.
        /// </summary>
        /// <value>Configuration path.</value>
        [ConfigurationProperty("unityConfigurationSectionPath", DefaultValue = DefaultUnityConfigurationSectionPath)]
        public string UnityConfigurationSectionPath
        {
            get;
            set;
        }

        /// <summary>
        /// Creates a behavior extension based on the current configuration settings.
        /// </summary>
        /// <returns>The behavior extension.</returns>
        protected override object CreateBehavior()
        {
            var unitySection = ConfigurationManager.GetSection(this.UnityConfigurationSectionPath) as UnityConfigurationSection;
            IUnityContainer container = new UnityContainer();

            if (this.ContainerName == null)
            {
                unitySection.Containers.Default.Configure(container);
            }
            else
            {
                unitySection.Containers[this.ContainerName].Configure(container);
            }

            return new InjectionBehavior(container);
        }
    }
}
