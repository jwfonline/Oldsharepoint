﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using Microsoft.Practices.Unity;

namespace Iascend.Intranet.Framework.Helpers.UnityServiceModel
{
    /// <summary>
    /// Injection instance provider for new service instances.
    /// </summary>
    internal sealed class InjectionInstanceProvider : IInstanceProvider
    {
        /// <summary>
        /// Injection container.
        /// </summary>
        private IUnityContainer container;

        /// <summary>
        /// Type of the service implementation.
        /// </summary>
        private Type instanceType;

        /// <summary>
        /// Initializes a new instance of the InjectionInstanceProvider class.
        /// </summary>
        /// <param name="container">Injection container.</param>
        /// <param name="instanceType">Type of the service implementation.</param>
        public InjectionInstanceProvider(IUnityContainer container, Type instanceType)
        {
            this.container = container;
            this.instanceType = instanceType;
        }

        /// <summary>
        /// Returns a service object given the specified System.ServiceModel.InstanceContext object.
        /// </summary>
        /// <param name="instanceContext">The current System.ServiceModel.InstanceContext object.</param>
        /// <param name="message">The message that triggered the creation of a service object.</param>
        /// <returns>The service object.</returns>
        public object GetInstance(InstanceContext instanceContext, Message message)
        {
            return this.container.Resolve(this.instanceType);
        }

        /// <summary>
        /// Returns a service object given the specified System.ServiceModel.InstanceContext object.
        /// </summary>
        /// <param name="instanceContext">The current System.ServiceModel.InstanceContext object.</param>
        /// <returns>The service object.</returns>
        public object GetInstance(InstanceContext instanceContext)
        {
            return this.GetInstance(instanceContext, null);
        }

        /// <summary>
        /// Called when an System.ServiceModel.InstanceContext object recycles a service object.
        /// </summary>
        /// <param name="instanceContext">The service's instance context.</param>
        /// <param name="instance">The service object to be recycled.</param>
        public void ReleaseInstance(InstanceContext instanceContext, object instance)
        {
            this.container.Teardown(instance);
        }
    }
}
