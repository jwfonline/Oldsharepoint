using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Iascend.Intranet.Framework.Logging;
using Iascend.Intranet.EnumsAndConstants.Constants;

namespace Iascend.Intranet.Framework.Helpers
{

    /// <summary>
    /// Encapsulates some generic routines which aid in working with xml
    /// </summary>
    public class XMLHelper
    {

        /// <summary>
        /// Returns string of last node in xpath
        /// </summary>
        /// <param name="XPath"></param>
        /// <param name="NodeCount"></param>
        /// <returns></returns>
        public static string GetLastNodeInXPath(string XPath, int NodeCount)
        {
            string[] Nodes = XPath.Split('/');
            return Nodes[(Nodes.Length - 1) - NodeCount];
        }

        /// <summary>
        /// Builds the path to the node passed in
        /// </summary>
        /// <param name="Node"></param>
        /// <returns></returns>
        public static string BuildXPath(XmlNode Node, string XPath)
        {

            XPath = XPath.Equals("") ? Node.Name : Node.Name + "/" + XPath;

            if (Node.ParentNode != null && Node.ParentNode.NodeType == XmlNodeType.Element)
                return BuildXPath(Node.ParentNode, XPath);

            return XPath;
        }

        /// <summary>
        /// Create/Updates node in path.  Returns the node that was updated
        /// </summary>
        /// <param name="Xml"></param>
        /// <param name="ParentNode"></param>
        /// <param name="XPath"></param>
        /// <param name="Value"></param>
        /// <param name="Sequence"></param>
        /// <param name="ParentRequiresCount"></param>
        /// <returns></returns>
        public static void UpdateXmlNode(ref System.Xml.XmlDocument Xml, string XPath, string Value, int Sequence, bool ParentRequiresCount)
        {

            try
            {

                XmlNode Node = null;
                XmlNodeList Nodes = null;
                XmlNode ParentNode = Xml.DocumentElement;

                if (Sequence == 1)
                {

                    // This is easy, we need only 1 of these nodes.  Select it using xpath, then update the value
                    Node = ParentNode.SelectSingleNode(XPath);

                    if (Node == null)
                    {
                        XMLHelper.CreateNodesInPath(ref Xml, XPath, null);
                        Node = Xml.SelectSingleNode(XPath);
                    }

                    if (!Value.Equals(WebKeys.LIST_PLACEHOLDER))
                        Node.InnerXml = Value;

                }
                else
                {

                    // This is more difficult.  We have many of these nodes (ie.  PartyList/Party)                    

                    // Select Nodes for parent. (ie: PartyList/Party)
                    string TempXPath = XPath.Substring(0, XPath.LastIndexOf("/"));
                    Nodes = Xml.SelectNodes(TempXPath);

                    if (Nodes == null || Nodes.Count < Sequence)
                    {

                        // Get the parent node (ie: PartyList)
                        Node = Xml.SelectNodes(TempXPath)[0];

                        // Create new node under list node                
                        XmlNode p = Xml.CreateNode(XmlNodeType.Element, XMLHelper.GetLastNodeInXPath(XPath, 1), "");
                        XmlNode c = Xml.CreateNode(XmlNodeType.Element, XMLHelper.GetLastNodeInXPath(XPath, 0), "");

                        if (!Value.Equals(WebKeys.LIST_PLACEHOLDER))
                            c.InnerXml = Value;

                        p.AppendChild(c);
                        Node.ParentNode.AppendChild(p);

                    }
                    else
                    {

                        // Parent node already exists under list.  Get the parent (ie. PartyList\Party)
                        Node = Xml.SelectNodes(TempXPath)[Sequence - 1];

                        // Create the Node under parent (ie.  Party\FirstName)
                        XmlNode c = Xml.CreateNode(XmlNodeType.Element, XMLHelper.GetLastNodeInXPath(XPath, 0), "");
                        if (!Value.Equals(WebKeys.LIST_PLACEHOLDER))
                            c.InnerXml = Value;

                        Node.AppendChild(c);
                    }
                }

                // Make sure the parent node has the <count/> node with the correct # of child nodes
                if (ParentRequiresCount)
                {

                    string CountXPath = XMLHelper.BuildXPath(Node.ParentNode.ParentNode, "") + "/Count";
                    XmlNode Temp = Xml.SelectSingleNode(CountXPath);

                    if (Temp == null)
                    {
                        Temp = Xml.CreateNode(XmlNodeType.Element, "Count", "");
                        if (Node.ParentNode.ParentNode.HasChildNodes)
                            Node.ParentNode.ParentNode.InsertBefore(Temp, Node.ParentNode.ParentNode.FirstChild);
                        else
                            Node.ParentNode.ParentNode.AppendChild(Temp);
                    }
                    Xml.SelectSingleNode(CountXPath).InnerXml = Convert.ToString(Node.ParentNode.ParentNode.ChildNodes.Count - 1);
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Creates all the nodes in the XPath passed in
        /// </summary>
        /// <param name="Xml"></param>
        /// <param name="XPath"></param>
        /// <param name="Value"></param>
        public static void CreateNodesInPath(ref System.Xml.XmlDocument Xml, string XPath, string Value)
        {
            XmlNode ParentNode = Xml.DocumentElement;
            XmlNode Node = ParentNode.SelectSingleNode(XPath);

            // No need to do anthing if XPath query finds a node
            if (Node != null)
                return;

            // Start creating nodes in path
            string[] Nodes = XPath.Split('/');

            for (int x = 0; x < Nodes.Length; x++)
            {

                if (ParentNode.Name.Equals(Nodes[x]))
                    continue;

                Node = ParentNode.SelectSingleNode(Nodes[x]);

                if (Node == null)
                {
                    Node = Xml.CreateNode(XmlNodeType.Element, Nodes[x], "");
                    ParentNode.AppendChild(Node);
                }
                ParentNode = Node;
            }

            if (Value != null && !Value.Equals(WebKeys.LIST_PLACEHOLDER))
                ParentNode.InnerXml = Value;
        }

        /// <summary>
        /// Build nodes in path starting from Parent Node.
        /// </summary>
        /// <param name="ParentNode"></param>
        /// <param name="XPath"></param>
        public static void CreateNodesInPath(ref XmlNode ParentList, string XPath, string Value, int Sequence)
        {
            // Get XPath of parent node
            string ParentXPath = BuildXPath(ParentList, "");

            // Build XPath which is to be built starting from parent node            
            string XPathToBuild = "";
            string[] Nodes = XPath.Split('/');
            string[] ParentNodes = ParentXPath.Split('/');

            for (int x = 0; x < Nodes.Length; x++)
            {
                if (x >= ParentNodes.Length || Nodes[x] != ParentNodes[x])
                    XPathToBuild += XPathToBuild.Equals("") ? Nodes[x] : "/" + Nodes[x];
            }

            XmlNode Node = null;
            XmlNode ParentNode = null;
            XmlNodeList NodeList = null;

            string[] NewNodes = XPathToBuild.Split('/');

            // Create the nodes we determined which need to be created starting from Parent Node
            for (int x = 0; x < NewNodes.Length; x++)
            {
                switch (x)
                {
                    case 0:

                        // First item in array should always be list item (ie: SigningLocationList/SigningLocation)
                        NodeList = ParentList.SelectNodes(NewNodes[x]);

                        if (NodeList[Sequence - 1] == null)
                        {
                            Node = ParentList.OwnerDocument.CreateNode(XmlNodeType.Element, NewNodes[x], "");

                            if (Value != null && NewNodes.Length == 1 && !Value.Equals(WebKeys.LIST_PLACEHOLDER))
                                Node.InnerXml = Value;

                            ParentNode = ParentList.AppendChild(Node);

                        }
                        else
                        {
                            ParentNode = NodeList[Sequence - 1];
                        }

                        break;

                    default:

                        Node = ParentNode.OwnerDocument.CreateNode(XmlNodeType.Element, NewNodes[x], "");

                        if (Value != null && x == NewNodes.Length - 1 && !Value.Equals(WebKeys.LIST_PLACEHOLDER))
                            Node.InnerXml = Value;

                        ParentNode = ParentNode.AppendChild(Node);

                        break;
                }
            }
        }

        /// <summary>
        /// Get single node value
        /// </summary>
        /// <param name="RootNode"></param>
        /// <param name="XPath"></param>
        /// <returns></returns>
        public static string GetSingleNodeValue(XmlNode RootNode, string XPath)
        {

            XmlNode ChildNode = RootNode.SelectSingleNode(XPath);
            if (ChildNode != null)
            {
                return ChildNode.InnerText;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
