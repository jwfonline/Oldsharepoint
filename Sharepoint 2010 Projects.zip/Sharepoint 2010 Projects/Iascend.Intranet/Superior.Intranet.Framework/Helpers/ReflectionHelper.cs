﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Globalization;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Provide Reflection assistance.
    /// </summary>
    public static class ReflectionHelper
    {
        #region Get Dictionary
        /// <summary>
        /// Reflect the properties of an object into a dictionary.
        /// </summary>
        /// <param name="obj">object to reflect</param>
        /// <returns>IDictionary of property name and property value</returns>
        public static IDictionary<string, object> GetDictionary(object obj)
        {
            IDictionary<string, object> dictionary = new Dictionary<string, object>();
            PropertyInfo[] props = ReflectionHelper.GetProperties(obj.GetType(), false);
            foreach (PropertyInfo pInfo in props)
            {
                if (IsValidProperty(pInfo))
                {
                    // ReflectionIgnoreAttribute is used to allow a property to be skipped.
                    object[] attribs = pInfo.GetCustomAttributes(typeof(ReflectionIgnoreAttribute), true);
                    if (attribs.Length == 0 ? false : ((ReflectionIgnoreAttribute)attribs[0]).IgnoreProperty)
                        continue;

                    dictionary.Add(pInfo.Name, pInfo.GetValue(obj, null));
                }
            }
            return dictionary;
        }
        #endregion

        #region Get
      
        /// <summary>
        /// Calls Overload 
        /// </summary>
        /// <param name="obj">Object to reflect</param>
        /// <param name="strPropertyName">PropertyInfo.Name to use</param>
        /// <returns>Object value</returns>
        public static object GetObjectElementValue(object obj, String strPropertyName)
        {
            return GetObjectElementValue(obj, strPropertyName, false);
        }

        /// <summary>
        /// Get element value 
        /// </summary>
        /// <param name="obj">Object to reflect</param>
        /// <param name="strPropertyName">PropertyInfo.Name to use</param>
        /// <param name="throwIfInvalid">bool - Throw exception if not a valid property</param>
        /// <returns>Object value</returns>
        public static object GetObjectElementValue(object obj, String strPropertyName, bool throwIfInvalid)
        {
            if (obj == null)
                return null;

            PropertyInfo propObject = ReflectionHelper.GetProperty(obj.GetType(), strPropertyName, false, throwIfInvalid);
            if (propObject == null)
            {
                // Try again ignoring case in search
                propObject = ReflectionHelper.GetProperty(obj.GetType(), strPropertyName, true, throwIfInvalid);
            }

            if (propObject != null)
            {
                if (IsValidProperty(propObject))
                {
                    if (propObject.PropertyType.IsGenericType && propObject.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                    {
                        // TODO: Test this against DateTime?
                        return System.Nullable.GetUnderlyingType(propObject.PropertyType).GetProperty(propObject.Name).GetValue(obj, null);
                    }

                    return propObject.GetValue(obj, null);
                }
                else
                {
                    if (throwIfInvalid)
                    {
                        throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, strPropertyName, obj.GetType().FullName));
                    }
                }
            }

            return null;
        }

        #region GetProp
        /// <summary>
        /// Wrapper around Type.GetProperties        
        /// </summary>
        /// <param name="type">System.Type</param>
        /// <param name="throwIfInvalid">bool - Throw exception if not a valid property</param>
        /// <returns>PropertyInfo array</returns>
        public static PropertyInfo[] GetProperties(Type type, bool throwIfInvalid)
        {
            PropertyInfo[] propertyInfo = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);

            if (!IsValidProperties(propertyInfo))
            {
                if (throwIfInvalid)
                {
                    throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, type.FullName));
                }

                return null;
            }

            return propertyInfo;
        }

        /// <summary>
        /// Gets PropertyInfo
        /// </summary>
        /// <param name="type">System.Type</param>
        /// <param name="propertyName">PropertyInfo.Name value</param>
        /// <returns>PropertyInfo</returns>
        public static PropertyInfo GetProperty(Type type, string propertyName)
        {
            return ReflectionHelper.GetProperty(type, propertyName, false, false);
        }

        /// <summary>
        /// Gets PropertyInfo
        /// </summary>
        /// <param name="type">System.Type</param>
        /// <param name="propertyName">PropertyInfo.Name value</param>
        /// <param name="throwIfInvalid">bool - Throw exception if not a valid property</param>
        /// <returns>PropertyInfo</returns>
        public static PropertyInfo GetProperty(Type type, string propertyName, bool throwIfInvalid)
        {
            return ReflectionHelper.GetProperty(type, propertyName, false, throwIfInvalid);
        }

        /// <summary>
        /// Gets PropertyInfo base method
        /// </summary>
        /// <param name="type">System.Type</param>
        /// <param name="propertyName">PropertyInfo.Name value</param>
        /// <param name="anyCase">Ignore case on search</param>
        /// <param name="throwIfInvalid">bool - Throw exception if not a valid property</param>
        /// <returns>PropertyInfo</returns>
        public static PropertyInfo GetProperty(Type type, string propertyName, bool anyCase, bool throwIfInvalid)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentNullException("propertyName");
            }

            PropertyInfo propertyInfo = null;

            if (anyCase)
                propertyInfo = type.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
            else
                propertyInfo = type.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);

            if (!IsValidProperty(propertyInfo))
            {
                if (throwIfInvalid)
                {
                    throw new ArgumentException(string.Format(CultureInfo.CurrentCulture,
                        type.FullName));
                }
                else
                {
                    return null;
                }
            }

            return propertyInfo;
        }
        #endregion

        #endregion

        #region Set

        /// <summary>
        /// Set Value of Object's property, calls overload and ReflectionHelper.SetValue
        /// </summary>
        /// <param name="obj">Object containing property</param>
        /// <param name="strPropertyName">PropertyInfo.Name</param>
        /// <param name="objectValue">Target value of Property in Object</param>
        /// <param name="checkChange">bool - Check if change was needed and performed</param>
        /// <returns>bool - Property value changed</returns>
        public static bool SetObjectElementValue(object obj, String strPropertyName, object objectValue, bool checkChange)
        {
            return SetObjectElementValue(obj, strPropertyName, objectValue, checkChange, false);
        }

        /// <summary>
        /// Set Value of Object's property. Calls overload and ReflectionHelper.SetValue
        /// </summary>
        /// <param name="obj">Object containing property</param>
        /// <param name="strPropertyName">PropertyInfo.Name</param>
        /// <param name="objectValue">Target value of Property in Object</param>
        /// <param name="checkChange">bool - Check if change was needed and performed</param>
        /// <param name="throwIfInvalid">Throw exception if not a valid property</param>
        /// <returns>bool - Property value changed</returns>
        public static bool SetObjectElementValue(object obj, String strPropertyName, object objectValue, bool checkChange, bool throwIfInvalid)
        {
            PropertyInfo propObject = ReflectionHelper.GetProperty(obj.GetType(), strPropertyName, throwIfInvalid);
            if (propObject == null)
            {
                return false;
            }

            return ReflectionHelper.SetValue(obj, propObject, objectValue, checkChange);
        }
        
        #endregion

        #region SetValue
        /// <summary>
        /// Set the property value within an object using PropertyInfo
        /// </summary>
        /// <param name="obj">object to set the value within</param>
        /// <param name="propInfo">PropertyInfo meta</param>
        /// <param name="objectValue">property new value</param>
        /// <returns>bool - was changed</returns>
        public static bool SetValue(object obj, PropertyInfo propInfo, object objectValue)
        {
            return ReflectionHelper.SetValue(obj, propInfo, objectValue, false);
        }
        /// <summary>
        /// Set the property value within an object using PropertyInfo
        /// </summary>
        /// <param name="obj">object to set the value within</param>
        /// <param name="propInfo">PropertyInfo meta</param>
        /// <param name="objectValue">property new value</param>
        /// <param name="checkChange">track change</param>
        /// <returns>bool - was changed</returns>
        public static bool SetValue(object obj, PropertyInfo propInfo, object objectValue, bool checkChange)
        {
            if (!(propInfo.CanWrite))
                throw new InvalidOperationException("Cannot set a object value using reflection because PropertyInfo.CanWrite is false.");

            try
            {
                object oldValue = null;
                if (checkChange && propInfo.CanRead)
                {
                    if (propInfo.PropertyType.IsValueType)
                    {
                        // TODO: Find out why getting the original fails on enum type
                        //TODO: Code for enum and nullables
                        oldValue = propInfo.GetValue(obj, null);
                    }
                    else
                    {
                        //TODO: Code for nullables
                        oldValue = propInfo.GetValue(obj, null);
                    }
                }

                if (objectValue == null || objectValue == DBNull.Value)
                {
                    if (propInfo.PropertyType.IsValueType)
                    {
                        throw new InvalidOperationException("Cannot set a ValueType object to null.");
                    }
                    try
                    {
                        propInfo.SetValue(obj, null, null);
                    }
                    catch { return false; } // TODO: Log this?
                    return (checkChange ? oldValue == null : true);
                }
                else
                {
                    #region IsValueType
                    if (propInfo.PropertyType.IsValueType && (!(propInfo.PropertyType.IsGenericType && propInfo.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))))
                    {
                        if (objectValue == null)
                        {
                            throw new InvalidOperationException("Cannot set a ValueType object to null.");
                        }
                        else
                        {
                            if (checkChange)
                            {
                                if (propInfo.PropertyType.IsEnum)
                                {
                                    propInfo.SetValue(obj, Enum.Parse(propInfo.PropertyType, objectValue.ToString(), true), null);
                                    return true; // TODO: Find out why getting the original fails on enum type
                                }
                                else
                                {
                                    if (Convert.ChangeType(oldValue, propInfo.PropertyType) == Convert.ChangeType(objectValue, propInfo.PropertyType))
                                    {
                                        // Didn't have to change it.
                                        // If CheckChange indicated, return false (not changed)
                                        // else return true that the property was found by strPropertyName.
                                        return (checkChange ? false : true);
                                    }
                                    else
                                    {
                                        propInfo.SetValue(obj, Convert.ChangeType(objectValue, propInfo.PropertyType), null);
                                        return true;
                                    }
                                }
                            }
                            else
                            {
                                if (propInfo.PropertyType.IsEnum)
                                {
                                    propInfo.SetValue(obj, Enum.Parse(propInfo.PropertyType, objectValue.ToString(), true), null);
                                    return true; // TODO: Find out why getting the original fails on enum type
                                }
                                else
                                {
                                    propInfo.SetValue(obj, Convert.ChangeType(objectValue, propInfo.PropertyType), null);
                                    return true;
                                }
                            }
                        }
                    }
                    #endregion
                    else
                    #region complex types
                    {
                        #region nullables
                        if (propInfo.PropertyType.IsGenericType && propInfo.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            if (checkChange)
                            {
                                if (Convert.ChangeType(oldValue, System.Nullable.GetUnderlyingType(propInfo.PropertyType)) == Convert.ChangeType(objectValue, System.Nullable.GetUnderlyingType(propInfo.PropertyType)))
                                {
                                    // Didn't have to change it.
                                    // If CheckChange indicated, return false (not changed)
                                    // else return true that the property was found by strPropertyName.
                                    return (checkChange ? false : true);
                                }
                                else
                                {
                                    if (System.Nullable.GetUnderlyingType(propInfo.PropertyType) == typeof(System.Guid))
                                    {
                                        propInfo.SetValue(obj, new Guid(objectValue.ToString()), null);
                                    }
                                    else
                                    {
                                        propInfo.SetValue(obj, Convert.ChangeType(objectValue, System.Nullable.GetUnderlyingType(propInfo.PropertyType)), null);
                                    }
                                    return true;
                                }
                            }
                            else
                            {
                                propInfo.SetValue(obj, Convert.ChangeType(objectValue, System.Nullable.GetUnderlyingType(propInfo.PropertyType)), null);
                                return true;
                            }
                        }
                        #endregion
                        else
                        {
                            if (checkChange)
                            {
                                if (Convert.ChangeType(oldValue, propInfo.PropertyType) == Convert.ChangeType(objectValue, propInfo.PropertyType))
                                {
                                    // Didn't have to change it.
                                    // If CheckChange indicated, return false (not changed)
                                    // else return true that the property was found by strPropertyName.
                                    return (checkChange ? false : true);
                                }
                                else
                                {
                                    propInfo.SetValue(obj, Convert.ChangeType(objectValue, propInfo.PropertyType), null);
                                    return true;
                                }
                            }
                            else
                            {

                                propInfo.SetValue(obj, Convert.ChangeType(objectValue, propInfo.PropertyType), null);
                                return true;
                            }
                        }
                    }
                    #endregion
                }
            }
            catch
            {
                return false;
            }

        }

        #endregion

        #region Validity Check

        /// <summary>
        /// Check for null and length
        /// </summary>
        /// <param name="propertyInfoArray">PropertyInfo[]</param>
        /// <returns>bool - not null and length > 0</returns>
        public static bool IsValidProperties(PropertyInfo[] propertyInfoArray)
        {
            if (!(propertyInfoArray == null))
                return (!(propertyInfoArray.Length == 0));
            else
                return false;
        }

        /// <summary>
        /// Check null and CanRead
        /// </summary>
        /// <param name="propertyInfo">PropertyInfo</param>
        /// <returns>bool - not null and CanRead</returns>
        public static bool IsValidProperty(PropertyInfo propertyInfo)
        {
            if (propertyInfo == null)
                return false;
            return propertyInfo.CanRead;
        }
        
        #endregion
    }
}
