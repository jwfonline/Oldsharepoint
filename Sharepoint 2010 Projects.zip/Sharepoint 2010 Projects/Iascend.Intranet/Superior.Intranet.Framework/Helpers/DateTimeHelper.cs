﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DateAndTime = Microsoft.VisualBasic.DateAndTime;
using DateInterval = Microsoft.VisualBasic.DateInterval;
using FirstDayOfWeek = Microsoft.VisualBasic.FirstDayOfWeek;
using FirstWeekOfYear = Microsoft.VisualBasic.FirstWeekOfYear;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Helper class for dealing with DateTime values
    /// </summary>
    public static class DateTimeHelper
    {
        /// <summary>
        /// Date Difference
        /// </summary>
        /// <param name="dateInterval"></param>
        /// <param name="date1"></param>
        /// <param name="date2"></param>
        /// <returns></returns>
        public static long DateDiff(DateInterval dateInterval, DateTime date1, DateTime date2)
        {
            return DateAndTime.DateDiff(dateInterval,
                    date1,
                    date2,
                    FirstDayOfWeek.Sunday,
                    FirstWeekOfYear.Jan1);

        }

        /// <summary>
        /// Get last day of month from date time
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static DateTime GetLastDayOfMonthFromDateTime(DateTime dateTime)
        {
           return _GetLastDayOfMonthFromDateTime(dateTime);
        }

        /// <summary>
        /// Get last day of month from date time
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static DateTime? GetLastDayOfMonthFromDateTime(DateTime? dateTime)
        {
            DateTime? result;

            if (dateTime.HasValue)
            {
                result = _GetLastDayOfMonthFromDateTime(dateTime.Value);
            }
            else
            {
                result = null;
            }

            return result;
        }

        /// <summary>
        /// Get firt date of the month
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static DateTime GetFirstDateOfTheMonth(DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, 1);
        }

        #region Private Methods

        /// <summary>
        /// Get last daqy of month from date time
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        private static DateTime _GetLastDayOfMonthFromDateTime(DateTime dateTime)
        {
            DateTime firstDayOfTheMonth = new DateTime(dateTime.Year, dateTime.Month, 1);
            return firstDayOfTheMonth.AddMonths(1).AddDays(-1);
        }

        #endregion
    }
}
