using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;

using Iascend.Intranet.Enums.Enumerations;
using Iascend.Intranet.Framework.Logging;
using Iascend.Intranet.EnumsAndConstants.Constants;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Helper class for use with sending emails
    /// </summary>
    public class EmailHelper
    {
        /// <summary>
        /// Email helper function used to send emails.
        /// </summary>
        /// <param name="From">The email address sending the email</param>
        /// <param name="To">The email address receiving the email</param>
        /// <param name="MessageSubject">The subject of the email</param>
        /// <param name="MessageBody">The body of the email</param>
        /// <param name="Options">Optional parameters</param>
        public static void SendEmail(string From, string To, string MessageSubject, string MessageBody, EmailOptions Options)
        {
            string MailServer = ConfigurationHelper.GetFromAppSettings(WebKeys.MAIL_SERVER);
            MailAddress ToAddress = new MailAddress(To);
            MailAddress FromAddress = new MailAddress(From);
            MailMessage Message = new MailMessage(FromAddress, ToAddress);
            SmtpClient Client = new SmtpClient(MailServer);

            Message.Subject = MessageSubject;
            Message.Body = MessageBody;

            if (BitmaskHelper.CheckEnum(Options.GetHashCode(), EmailOptions.SendAsHTML.GetHashCode()))
            {
                Message.IsBodyHtml = true;
            }

            //Include the "Do Not Reply" message at the end of the body of the email
            if (BitmaskHelper.CheckEnum(Options.GetHashCode(), EmailOptions.DisplayNoReply.GetHashCode()))
            {
                Message.Body = Message.Body + "\n\n\n\n" + ConfigurationHelper.GetFromAppSettings(WebKeys.MESSAGE_DONOTREPLY);
            }

            try
            {
                Client.Send(Message);
            }
            catch (Exception Ex)
            {
                System.Diagnostics.Debug.Write(Ex.ToString());
                throw Ex;
            }
        }


















    }
}
