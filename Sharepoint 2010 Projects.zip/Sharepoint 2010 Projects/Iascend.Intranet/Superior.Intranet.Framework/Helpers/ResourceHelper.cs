using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Collections.Generic;
using System.Resources;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Aids in getting Resources embedded in the dll
    /// </summary>
    public class ResourceHelper
    {
        /// <summary>
        /// Get string resource
        /// </summary>
        /// <param name="ResourceName"></param>
        /// <returns></returns>
        public static string GetFromResources(string ResourceAssemblyName, string ResourceName)
        {
            Assembly Asm = Assembly.GetExecutingAssembly();
            ResourceName = ResourceAssemblyName + "." + ResourceName;

            using (Stream TheStream = Asm.GetManifestResourceStream(ResourceName))
            {
                try
                {
                    using (StreamReader TheReader = new StreamReader(TheStream))
                    {
                        return TheReader.ReadToEnd();
                    }
                }
                catch (Exception e)
                {
                    throw new ApplicationException("Error retrieving from Resources. Tried '" + ResourceName + "'\r\n" + e.ToString());
                }
            }
        }
    }
}
