﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// ReflectionIgnoreAttribute is a custom attribute that is used
    /// to decorated properties and control the reflection processing.
    /// Used similar to XmlIgnoreAttribute but in control flow processing.
    /// 
    /// <example>
    ///     object[] attribs = propertyInfo.GetCustomAttributes(typeof(ReflectionIgnoreAttribute));
    ///     if (attribs.Length == 0 ? false : ((ReflectionIgnoreAttribute)attribs[0]).IgnoreProperty)
    ///       continue;
    /// </example>
    /// </summary>
    public class ReflectionIgnoreAttribute : Attribute
    {

        private bool ignoreProperty = true;

        /// <summary>
        /// Ignore Property
        /// </summary>
        public bool IgnoreProperty
        {
            get { return ignoreProperty; }
            set { ignoreProperty = value; }
        }
    }
}
