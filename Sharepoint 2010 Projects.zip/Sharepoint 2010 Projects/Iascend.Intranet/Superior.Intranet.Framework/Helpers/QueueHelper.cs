using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Messaging;

using Iascend.Intranet.Framework.Logging;
using Iascend.Intranet.EnumsAndConstants.Constants;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Aids in working with MSMQ Queues
    /// </summary>
    public class QueueHelper
    {
        /// <summary>
        /// Send MSMQ Message to configured Queue
        /// </summary>
        /// <param name="Label"></param>
        /// <param name="Msg"></param>
        /// <returns></returns>
        public static bool SendMSMQMessage(string Label, string Body)
        {

            bool ReturnCode = true;
            MessageQueue Queue = null;

            try
            {

                // Get the Message Queue path from web.config file
                string Path = ConfigurationHelper.GetFromAppSettings(WebKeys.MSMQ_QUEUE);

                Message Msg = new Message();
                Queue = new MessageQueue(Path, QueueAccessMode.Send);

                // Load the string in in Byte array and send as Memory stream so 
                // .net will not attempt to prefix the body with text so it can serialize it
                // as a .net string.  This is done because the Message Processors are NOT .net
                // components and will not be able to rehydrate the object.
                UnicodeEncoding Encoder = new UnicodeEncoding();
                byte[] XmlBytes = Encoder.GetBytes(Body);

                using (MemoryStream Stream = new MemoryStream(XmlBytes))
                {
                    Msg.BodyStream = Stream;
                    Msg.Label = Label;
                    Queue.Send(Msg);
                }

                Queue.Close();

            }
            catch (Exception Ex)
            {
                ReturnCode = false;
                System.Diagnostics.Debug.Write(Ex.ToString());
            }
            finally
            {
                if (Queue != null) Queue.Close();
            }

            return ReturnCode;
        }
    }
}
