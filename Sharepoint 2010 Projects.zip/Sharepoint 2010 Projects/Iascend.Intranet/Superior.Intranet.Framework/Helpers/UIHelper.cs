using System;
using System.Text.RegularExpressions;

namespace Iascend.Intranet.Framework.Helpers
{

	/// <summary>
	/// Used on Date diff function
	/// </summary>
	public enum DateDiffMode : int{
		Ticks = 1,
		Milliseconds,
		Minutes,
		Seconds,
		Days,
		Quarters,
		Years
	}

	/// <summary>
	/// Collection of helper functions for UI tier.
	/// </summary>
	public sealed class UIHelper{

		private UIHelper(){}

		/// <summary>
		/// Return the character value of the given character
		/// </summary>
		/// <param name="ch"></param>
		/// <returns></returns>
		public static int Asc(string s) {		
			return (int)System.Text.Encoding.ASCII.GetBytes(s)[0];
		}

		/// <summary>
		/// Return the character of the given character value
		/// </summary>
		/// <param name="i"></param>
		/// <returns></returns>
		public  static Char Chr(int i) {
			return Convert.ToChar(i);
		}

		/// <summary>
		/// Format object as string
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static string FormatCurrency(object InValue){
			if (InValue == null) return "";
			decimal temp = (decimal)InValue;
			return String.Format("{0:C}", temp);
		}

		/// <summary>
		/// Avoids problems when values are potentially null
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static string NullToEmptyString(object InValue){

			try{
				if (InValue == System.DBNull.Value) return "";
				if (InValue == null) return "";
			}catch{
				return "";
			}
			return Convert.ToString(InValue);
		}

		/// <summary>
		/// Avoids problems when values are potentially null
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static int EmptyStringToInteger(object InValue){

			try{
				if (InValue == System.DBNull.Value) return 0;
				if (((String)InValue) == String.Empty) return 0;
			}catch{
				return 0;
			}
			return Convert.ToInt32(InValue);
		}

		/// <summary>
		/// If value is null replace with value passed in
		/// </summary>
		/// <param name="InValue"></param>
		/// <param name="Replacement"></param>
		/// <returns></returns>
		public static int EmptyStringToInteger(object InValue, int Replacement){

			try{
				if (InValue == System.DBNull.Value) return Replacement;
				if (((String)InValue) == String.Empty) return Replacement;
			}catch{
				return 0;
			}
			return Convert.ToInt32(InValue);
		}

		/// <summary>
		/// return 0 if empty
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static double EmptyStringToDouble(object InValue){

			try{
				if (InValue == System.DBNull.Value) return 0;
				if (((String)InValue) == String.Empty) return 0;
			}catch{
				return 0;
			}
			return Convert.ToDouble(InValue);
		}

		/// <summary>
		/// If value is null return replacement
		/// </summary>
		/// <param name="InValue"></param>
		/// <param name="Replacement"></param>
		/// <returns></returns>
		public static double EmptyStringToDouble(object InValue, double Replacement){

			try{
				if (InValue == System.DBNull.Value) return Replacement;
				if (((String)InValue) == String.Empty) return Replacement;
			}catch{
				return 0;
			}
			return Convert.ToDouble(InValue);
		}

		/// <summary>
		/// Convert bool to 1 or 0
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static string BoolToBit(bool InValue){
			if (InValue == true) 
				return "1";
			else
				return "0";
		}
		
		/// <summary>
		/// Convert bool to Y or N
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static string BoolToChar(bool InValue){
			if (InValue == true) 
				return "Y";
			else
				return "N";
		}

        public static string BoolToString(bool InValue) {
            if (InValue == true)
                return "true";
            else
                return "false";
        }

		/// <summary>
		/// Convert a byte to Y or N string
		/// </summary>
		/// <param name="InValue"></param>
		/// <returns></returns>
		public static string ByteToChar(byte InValue){
			if (InValue == 1) 
				return "Y";
			else
				return "N";
		}	

		/// <summary>
		/// Tests to see if string is a number
		/// </summary>
		/// <param name="v"></param>
		/// <returns></returns>
		public static bool IsInteger(string v) {
			try {
				Convert.ToInt32(v);
				return true;
			} catch {
				return false;
			}
		} 

        /// <summary>
        /// Test passed in value as decimal.
        /// </summary>
        /// <param name="TheValue"></param>
        /// <returns></returns>
        public static bool IsDecimal(string TheValue) {
           
			try {
				Convert.ToDecimal(TheValue);
				return true;
			} catch {
				return false;
			}            
        }

		/// <summary>
        /// Test if object is a date.
		/// </summary>
		/// <param name="v"></param>
		/// <returns></returns>
		public static bool IsDate(object v){
			try{
				Convert.ToDateTime(v);
				return true;
			}catch{
				return false;
			}
		}

		/// <summary>
        /// Test if date is empty.
		/// </summary>
		/// <param name="v"></param>
		/// <returns></returns>
		public static bool IsDateEmpty(DateTime v){
			return (v.Day == 1 && v.Year == 1 && v.Month == 1);
		}

		/// <summary>
		/// Test object to see if it is an array
		/// </summary>
		/// <param name="v"></param>
		/// <returns></returns>
		public static bool IsArray(object v){
			return v.GetType().IsArray;
		}

		/// <summary>
		/// Finds the difference between 2 dates
		/// </summary>
		/// <param name="Mode"></param>
		/// <param name="StartDate"></param>
		/// <param name="EndDate"></param>
		/// <returns></returns>
		public static double DateDiff(DateDiffMode Mode, System.DateTime StartDate, System.DateTime EndDate){
			
			double Diff = 0;
			
			try {

				System.TimeSpan Ts = new System.TimeSpan(EndDate.Ticks - StartDate.Ticks);
				
				switch (Mode) {
					case DateDiffMode.Minutes: 
						Diff = Convert.ToDouble(Ts.TotalMinutes);
						break;
					case DateDiffMode.Seconds:
						Diff = Convert.ToDouble(Ts.TotalSeconds);
						break;
					case DateDiffMode.Ticks:
						Diff = Convert.ToDouble(Ts.Ticks);
						break;
					case DateDiffMode.Milliseconds:
						Diff = Convert.ToDouble(Ts.TotalMilliseconds);
						break;
					case DateDiffMode.Years:
						Diff = Convert.ToDouble(Ts.TotalDays / 365);
						break;
					case DateDiffMode.Quarters:
						Diff = Convert.ToDouble((Ts.TotalDays / 365) / 4);
						break;
					default:
						Diff = Convert.ToDouble(Ts.TotalDays);
						break;
				}
				
			}catch{
				Diff = -1;
			}
			return Diff;
		}

        /// <summary>
        /// Validate the Zip Code format
        /// </summary>
        /// <param name="Zip"></param>
        /// <returns></returns>
        public static bool IsValidZipCode(string Zip) {

            Regex ZipRegEx;
            bool ReturnCode = true;            
            ZipRegEx = new Regex("\\d{5}(-\\d{4})?");

            try {
                Match ZipMatch = ZipRegEx.Match(Zip);
                ReturnCode = ZipMatch.Success;
            } catch {
                ReturnCode = false;
            }
            return ReturnCode;
        }

        /// <summary>
        /// Function to convert a numeric string to 2 digit decimal string.
        /// </summary>
        /// <param name="StringDecimal">the string to be converted</param>
        /// <returns>Return 2 digit decimal string.</returns>
        public static string ConvertTo2DigitDecimalString(string StringDecimal) {

            try {
                return Convert.ToDecimal(StringDecimal).ToString("N2");
            } catch {
                return "";
            }
        }

        /// <summary>
        /// Function to replace a newline string "\r\n" to a space " ".
        /// </summary>
        /// <param name="Text">the text to be checked</param>
        /// <returns>Return a new string after all occurrences of "\r\n" are replaced by a space " ".</returns>
        public static string StripCrLf(string Text) {

            if (Text.Trim().Length != 0) {
                return Text.Replace(System.Environment.NewLine, " ").Trim();
            } else {
                return "";
            }
        }

        /// <summary>
        /// Function to test whether the string is numeric with 2 digit decimals.
        /// #####.##
        /// </summary>
        /// <param name="StringDecimal">the string to test</param>
        /// <returns>Return true if the string is numeric with 2 digit decimals; otherwise, false.</returns>
        public static bool Is2DigitDecimal(string StringDecimal) {

            // Check pattern
            Regex DecimalPattern = new Regex(@"^\d*\.\d{2}$");

            // True if the regular expression finds a match; otherwise, false.
            return DecimalPattern.IsMatch(StringDecimal);
        }

        /// <summary>
        /// Function to test whether the string is numeric.
        /// </summary>
        /// <param name="StringNumber">the string to test</param>
        /// <returns>Return true if the string is numeric; otherwise, false.</returns>
        public static bool IsNumber(string StringNumber) {

            Regex ObjNotNumberPattern = new Regex("[^0-9.-]");
            Regex ObjTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex ObjTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String StrValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String StrValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex ObjNumberPattern = new Regex("(" + StrValidRealPattern + ")|(" + StrValidIntegerPattern + ")");

            return (!ObjNotNumberPattern.IsMatch(StringNumber) && !ObjTwoDotPattern.IsMatch(StringNumber) && !ObjTwoMinusPattern.IsMatch(StringNumber) && ObjNumberPattern.IsMatch(StringNumber));
        }

        /// <summary>
        /// Function to test whether the string is in this format: ##/##/####
        /// </summary>
        /// <param name="StringDate">the string to test</param>
        /// <returns>Return true if the string has the right format; otherwise, false.</returns>
        public static bool IsDate(string StringDate) {

            bool Status = true;

            // Check pattern [valid year is between 1800 to 2099]
            Regex DatePattern = new Regex(@"^(0[1-9]|1[012])/(0[1-9]|[12][0-9]|3[01])/(18|19|20)\d\d$");

            // True if the regular expression finds a match; otherwise, false.
            if (DatePattern.IsMatch(StringDate)) {

                // If a FormatException exception is thrown, this date is not a valid date.
                try {
                    DateTime.Parse(StringDate);
                } catch (FormatException) {
                    Status = false;
                }

            } else {
                Status = false;
            }

            return Status;
        }

        /// <summary>
        /// Function to test whether the string is a valid email.
        /// </summary>
        /// <param name="EmailString">the string to test</param>
        /// <returns>Return true if the string is a valid email; otherwise, false.</returns>
        public static bool IsEmailValid(string EmailString) {

            bool Status = false;

            // Check pattern
            Regex EmailPattern = new Regex(@"^([a-zA-Z0-9_\-])+(\.([a-zA-Z0-9_\-])+)*@((\[(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5]))\]))|((([a-zA-Z0-9])+(([\-])+([a-zA-Z0-9])+)*\.)+([a-zA-Z])+(([\-])+([a-zA-Z0-9])+)*))$");

            // True if the regular expression finds a match; otherwise, false.
            if (EmailPattern.IsMatch(EmailString)) {
                Status = true;
            }

            return Status;
        }

        /// <summary>
        /// Function to test whether the string fulfills the password requirement.
        /// </summary>
        /// <param name="PwdString">the string to test</param>
        /// <param name="ComplexityID">an integer for the complexity level.</param>
        /// <returns>Return true if the string is a valid password; otherwise, false.</returns>
        public static bool IsPasswordValid(string PwdString, int ComplexityID) {

            bool Status = false;

            // Check patterns
            Regex ComplexPwdPattern = new Regex(@"(?=^.{8,21}$)([A-Za-z0-9!\[\]<=>:@#;,/\\$%_\^\&amp;\*\-\.\?+{}()]{7,19})$");
            Regex PwdPattern = new Regex(@"(?!^[0-9!\[\]<=>:@#;,/\\$%_\^\&amp;\*\-\.\?+{}()]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9!\[\]<=>:@#;,/\\$%_\^\&amp;\*\-\.\?+{}()]{6,15})$");

            // True if the regular expression finds a match; otherwise, false.
            if (ComplexityID == 0) {
                if (ComplexPwdPattern.IsMatch(PwdString)) {
                    Status = true;
                }
            } else {
                if (PwdPattern.IsMatch(PwdString)) {
                    Status = true;
                }
            }

            return Status;
        }

	}
}
