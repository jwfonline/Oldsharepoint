﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using System.Net.Mail;
using Iascend.Intranet.Framework.Extensions;

namespace Iascend.Intranet.Framework.Helpers
{
    public class MailHelper
    {
        public static void SendMail(string from, string to, string cc, string bcc,
                                    string subject, string body, 
                                    IList attachments)
        {
            if (from.IsNullEmptyOrEmptySpaces() ||
                to.IsNullEmptyOrEmptySpaces() ||
                subject.IsNullEmptyOrEmptySpaces() || 
                body.IsNullEmptyOrEmptySpaces())
            {
                throw new Exception("From, To, Subject, and Body, cannot be null or empty");
            }

            MailMessage message = new MailMessage()
            {
                Subject = subject,
                Body = body
            };

            message.From = new MailAddress(from);
            message.To.Add(to);

            if (!cc.IsNullEmptyOrEmptySpaces())
            {
                message.CC.Add(cc);
            }
            if (!bcc.IsNullEmptyOrEmptySpaces())
            {
                message.Bcc.Add(bcc);
            }

            if (attachments != null && attachments.Count > 0)
            {
                foreach(object attachment in attachments)
                {
                    attachments.Add(attachment);
                }
            }

            SmtpClient client = new SmtpClient(ConfigurationHelper.GetFromAppSettings("MailServer"));
            client.Send(message);
        }

    }
}
