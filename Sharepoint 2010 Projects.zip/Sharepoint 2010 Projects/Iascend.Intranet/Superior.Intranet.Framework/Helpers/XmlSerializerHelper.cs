using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Collections;
using System.Xml.Serialization;

namespace Iascend.Intranet.Framework.Helpers
{
	/// <summary>
	/// <para>Helper class to serialize XML objects.</para>
	/// </summary>\
	/// <include file='doc\XmlSerializerHelper.uex' path='docs/doc[@for="XmlSerializerHelper"]/*' />
	public class XmlSerializerHelper {

		/// <summary>
		/// <para>Default private Constructor.</para>
		/// </summary>
		/// <include file='doc\XmlSerializerHelper.uex' path='docs/doc[@for="XmlSerializerHelper.XmlSerializerHelper"]/*' />
		private XmlSerializerHelper() {}

		/// <summary>
		/// <para>Serializes the specified object.</para>
		/// </summary>
		/// <param name="value">Object to serialize.</param>
		/// <returns>String with the serialized object in a XML format.</returns>
		public static string SerializeToString( object value ) {
			using( StringWriter stringWriter = new StringWriter( System.Globalization.CultureInfo.InvariantCulture ) ) {
				XmlSerializer serializer = new XmlSerializer( value.GetType() );
				XmlTextWriter xmlWriter = new XmlTextWriter(stringWriter);
				serializer.Serialize( stringWriter, value );							
				return stringWriter.ToString();
			}
		}

		/// <summary>
		/// <para>Serializes the specified object.</para>
		/// </summary>
		/// <param name="value">Object to serialize.</param>
		/// <returns><see cref="XmlNode"/>with the serialized object.</returns>
		public static XmlNode SerializeToXmlNode( object value ) {
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.LoadXml( SerializeToString(value) );

			return xmlDoc.DocumentElement.CloneNode(true);
		}

		/// <summary>
		/// <para>Serializes the specified object to a <see cref="XmlDocument"/>.</para>
		/// </summary>
		/// <param name="value">Object to serialize.</param>
		/// <returns><see cref="XmlDocument"/> with the serialized object.</returns>
		public static XmlDocument SerializeToXml( object value ) {
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.PreserveWhitespace = true;
			xmlDoc.LoadXml( SerializeToString(value) );
			return xmlDoc;
		}


		/// <summary>
		/// <para>Deserializes the specified object.</para>
		/// </summary>
		/// <param name="serializedValue">The serialized string object.</param>
		/// <param name="type">The serialized object type.</param>
		/// <returns>The real object.</returns>
		public static object Deserialize(string serializedValue, Type type){
			using(StringReader stringReader = new StringReader(serializedValue)) {				
				XmlSerializer xs = new XmlSerializer(type);
				XmlTextReader xmlReader = new XmlTextReader(stringReader);
				return xs.Deserialize(xmlReader);
			}
		}
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="serializedValue"></param>
		/// <param name="type"></param>
		/// <param name="ns"></param>
		/// <returns></returns>
		public static object Deserialize( string serializedValue, Type type, string ns ) {
			using(StringReader stringReader = new StringReader( serializedValue )) {				
				XmlSerializer xs = new XmlSerializer( type, ns );
				return xs.Deserialize(stringReader);
			}
		}
		/// <summary>
		/// <para>Deserializes the specified object.</para>
		/// </summary>
		/// <param name="serializedValue">The serialized <see cref="XmlNode"/> object.</param>
		/// <param name="type">The serialized object type.</param>
		/// <returns>The real object.</returns>
		public static object Deserialize(XmlNode serializedValue, Type type){
			XmlSerializer xs = new XmlSerializer(type);
			XmlNodeReader xmlReader = new XmlNodeReader(serializedValue);

			try {
				return xs.Deserialize(xmlReader);
			}finally {
				xmlReader.Close();
			}
		}
	
	} // End Class XmlSerializeHelper
}
