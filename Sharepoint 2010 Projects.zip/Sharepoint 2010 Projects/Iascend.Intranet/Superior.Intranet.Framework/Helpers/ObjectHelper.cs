﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

using Iascend.Intranet.Framework.Model;
using Iascend.Intranet.Framework.Extensions;
using System.Data;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Contains functionalities to use with several object types.
    /// </summary>
    public static class ObjectHelper
    {

        /// <summary>
        /// This method attempts to convert a string value to the correct object type
        /// </summary>
        /// <param name="pType">The property type to conver too</param>
        /// <param name="val">The string value to convert</param>
        /// <param name="convertedObject">The object that will be returned of the correct type</param>
        /// <returns>ConvertedObject of the right type</returns>
        public static bool ConvertToType(Type propertyType, string val, out object convertedObject)
        {
            convertedObject = null;

            try
            {
                // do only null checks
                if (propertyType != null && val != null)
                {
                    if (propertyType.IsPrimitive || (propertyType.IsSerializable && propertyType.UnderlyingSystemType.Name == "String"))
                    {
                        convertedObject = Convert.ChangeType((object)val, propertyType, null);
                    }
                    else
                    {
                        // do a empty value check
                        if (!string.IsNullOrEmpty(val))
                        {
                            if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
                            {
                                Type newType = Nullable.GetUnderlyingType(propertyType);
                                convertedObject = (object)Convert.ChangeType((object)val, newType);
                                convertedObject = (object)Activator.CreateInstance(propertyType, new object[] { convertedObject });
                            }
                            else
                            {
                                if (propertyType.IsEnum)
                                {
                                    convertedObject = (object)Enum.Parse(propertyType, val, true);
                                }
                                else
                                {
                                    // Do nothing
                                }
                            }
                        }
                        else
                        {
                            // Do nothing
                        }
                    }
                }
                else
                {
                    // Do nothing
                }
            }
            catch (Exception ex)
            {
                string error = "Exception caught converting {0} to type {1}" + System.Environment.NewLine;
                error += "Exception: {2}" + System.Environment.NewLine + "ToString: {3}";

                Debug.WriteLine(String.Format(error, val, propertyType.ToString(), ex.Message, ex.ToString()));
            }

            return (convertedObject != null);
        }

        /// <summary>
        /// This method accepts one object and some data values, then it attempts to copy/load
        /// the data into the object
        /// </summary>
        /// <param name="original">The original/current object to load with data</param>
        /// <param name="values">The values to load into the object</param>
        public static bool Load(object original, Dictionary<string, string> values)
        {
            bool success = true;
            try
            {
                if (original != null && values != null && values.Count > 0)
                {
                    foreach (string key in values.Keys)
                    {
                        // Retrieve the property from the original object
                        PropertyInfo oProp = original.GetType().GetProperty(key);
                        object uValue = null;

                        // If we succeeded in getting a property try to update
                        if (oProp != null && ConvertToType(oProp.PropertyType, values[key], out uValue))
                        {
                            oProp.SetValue(original, uValue, null);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string error = "Exception caught loading object:" + System.Environment.NewLine;
                error += "Exception: {1}" + System.Environment.NewLine + "ToString: {2}";
                Debug.WriteLine(String.Format(ex.Message, ex.ToString()));
                success = false;
            }
            return success;
        }

        /// <summary>
        /// This method performs a sync between the current and the updated values ensuring
        /// that properties that have been changed by other users are not overwritten.  
        /// </summary>
        /// <typeparam name="T">The generic object type that we are trying to Sync from the updated state</typeparam>
        /// <param name="original">The original values</param>
        /// <param name="current">The current db values</param>
        /// <param name="values">The values to update the current values by</param>
        /// <returns>True if operation succeeded, false if it failed</returns>
        public static bool SyncObjects<T>(T original, T current, Dictionary<string, string> values)
        {
            List<string> conflicts = null;

            return SyncObjects<T>(original, current, values, out conflicts, false);
        }

        /// <summary>
        /// This method performs a sync between the current and the updated values ensuring
        /// that properties that have been changed by other users are not overwritten.  
        /// </summary>
        /// <typeparam name="T">The generic object type that we are trying to Sync from the updated state</typeparam>
        /// <param name="original">The original values</param>
        /// <param name="current">The current db values</param>
        /// <param name="values">The values to update the current values by</param>
        /// <param name="rollBack">Flag to rollback current object if any conflicts occurred</param>
        /// <returns>True if operation succeeded, false if it failed</returns>
        public static bool SyncObjects<T>(T original, T current, Dictionary<string, string> values, bool rollBack)
        {
            List<string> conflicts = null;

            return SyncObjects<T>(original, current, values, out conflicts, rollBack);
        }

        /// <summary>
        /// This method performs a sync between the current and the updated values ensuring
        /// that properties that have been changed by other users are not overwritten.  
        /// Properties that conflict will be added to the error properties list
        /// </summary>
        /// <typeparam name="T">The generic object type that we are trying to Sync from the updated state</typeparam>
        /// <param name="original">The original values</param>
        /// <param name="current">The current db values</param>
        /// <param name="values">The values to update the current values by</param>
        /// <param name="conflicts">A list of columns that failed the sync check</param>
        /// <param name="rollBack">Flag to rollback current object if any conflicts occurred</param>
        /// <returns>True if operation succeeded, false if it failed</returns>
        public static bool SyncObjects<T>(T original, T current, Dictionary<string, string> values, out List<string> conflicts, bool doRollBack)
        {
            // Instantiate the boolean success variable and the errorProperties list
            bool success = (original != null && current != null && values.Count > 0);
            conflicts = new List<string>();
            Dictionary<string, object> rollback = new Dictionary<string, object>();

            // Verify we have non null objects and a dictionary of at least 1 property name to sync
            if (success)
            {
                // For each property we need to sync
                foreach (string key in values.Keys)
                {
                    try
                    {
                        // Retrieve the same property from the original and current objects
                        PropertyInfo oProp = original.GetType().GetProperty(key);
                        PropertyInfo cProp = current.GetType().GetProperty(key);

                        // If we succeeded in getting a property from each project and they are the same property
                        if (oProp != null && cProp != null && oProp.Name == cProp.Name)
                        {
                            // Get all the actual values from the 3 object collections
                            object oValue = oProp.GetValue(original, null);
                            object cValue = cProp.GetValue(current, null);
                            object uValue = null;

                            // Try to convert the value to its correct object type
                            if (ConvertToType(cProp.PropertyType, values[key], out uValue))
                            {
                                bool changeOriginalToDB = (oValue != null && cValue == null) || (oValue == null && cValue != null) ||
                                                            (oValue != null && cValue != null && !oValue.Equals(cValue));
                                bool changeUpdateToDB = (uValue != null && cValue == null) || (uValue == null && cValue != null) ||
                                                            (uValue != null && cValue != null && !uValue.Equals(cValue));

                                // If the original value doesn't match the current value
                                // And the updated value doesn't match the original value
                                // we have a conflict and have to trigger an error
                                if (changeOriginalToDB && changeUpdateToDB)
                                {
                                    success = false;
                                    conflicts.Add(key);
                                }
                                else
                                {
                                    // Safe to push updated value to the current database object.  No conflicts
                                    // Store rollback values.  If for some reason we have a single conflict and can't update to DB
                                    // Easier to rollback to original values rather than removing item from update list.
                                    rollback.Add(key, cValue);
                                    oProp.SetValue(current, uValue, null);
                                }
                            }
                            else
                            {
                                // Do nothing
                            }
                        }
                        else
                        {
                            // Do nothing
                        }
                    }
                    catch (Exception ex)
                    {
                        string error = "Exception caught syncing original to db object;  key {0} " + System.Environment.NewLine;
                        error += "Exception: {1}" + System.Environment.NewLine + "ToString: {2}";

                        Debug.WriteLine(String.Format(error, key, ex.Message, ex.ToString()));
                    }
                }

                // Perform rollback
                if (!success && doRollBack)
                {
                    // For each property we need to sync
                    foreach (string key in rollback.Keys)
                    {
                        // Retrieve the same property from the original and current objects
                        PropertyInfo cProp = current.GetType().GetProperty(key);
                        object rValue = rollback[key];

                        // If we succeeded in getting a property from each project and they are the same property
                        if (cProp != null)
                        {
                            cProp.SetValue(current, rValue, null);
                        }
                        else
                        {
                            // Do nothing
                        }
                    }
                }
                else
                {
                    // Do nothing
                }
            }
            else
            {
                // Do nothing
            }

            return success;
        }

        /// <summary>
        /// Deserialize the xmlToDeserialize to an object of type T.
        /// </summary>
        /// <typeparam name="T">The type of the deserialized object.</typeparam>
        /// <param name="xmlToDeserialize">The XML to deserialize.</param>
        /// <returns>The object deserialized from the XML.</returns>
        public static T XmlDeserialize<T>(string xmlToDeserialize)
        {
            //Deserialize the XML.
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            StringReader stringReader = new StringReader(xmlToDeserialize);
            XmlReader xmlReader = XmlReader.Create(stringReader);
            object deserializedObject = xmlSerializer.Deserialize(xmlReader);

            return (T)deserializedObject;
        }


        /// <summary>
        /// Serialize the objectToSerialize to XML.
        /// </summary>
        /// <param name="objectToSerialize">The object to serialize.</param>
        /// <returns>The object serialized as XML.</returns>
        public static string XmlSerialize(object objectToSerialize)
        {
            //Specify the removal of the generated XML namespaces (which do not appear in the XML exchanged with the Flash front-end), i.e.:
            //  * xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            //  * xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            XmlSerializerNamespaces xmlnsEmpty = new XmlSerializerNamespaces();
            xmlnsEmpty.Add("", "");

            //Serialize the object.
            XmlSerializer xmlSerializer = new XmlSerializer(objectToSerialize.GetType());
            StringWriter stringWriter = new StringWriter();
            XmlWriter xmlWriter = XmlWriter.Create(stringWriter);
            xmlSerializer.Serialize(xmlWriter, objectToSerialize, xmlnsEmpty);
            String xmlString = stringWriter.ToString();

            //Clean the XML version declaration (to match the XML exchanged with the Flash front-end).
            xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "<?xml version=\"1.0\"?>");

            return xmlString;
        }

        /// <summary>
        /// Compares two objects properties values and returns a IDictionary contaning all properties values that have changed.
        /// </summary>
        /// <typeparam name="T">Object type to compare</typeparam>
        /// <param name="previous">Object's previous version</param>
        /// <param name="current">Object's current version</param>
        /// <returns>An IDictionary containing the property name as a key and a ObjectVersion object containing previous and current values</returns>
        /// <remarks>If previous value was null and current is not, the value pair gets added anyway as [null, currentValue]</remarks>
        public static IDictionary<string, ObjectVersion> CompareObject<T>(T previous, T current)
        {
            Dictionary<string, ObjectVersion> differentProperties = new Dictionary<string, ObjectVersion>();

            foreach (PropertyInfo typeProperty in typeof(T).GetProperties())
            {
                Type propertyType = typeProperty.PropertyType;
                if (propertyType is IComparable)
                {
                    object previousValue = typeProperty.GetValue(previous, null);
                    object currentValue = typeProperty.GetValue(current, null);
                    string previousValueString = previousValue.GetStringRepresentationOrNull();
                    string currentValueString = currentValue.GetStringRepresentationOrNull();

                    //check if properties string prepresentation values are not the same
                    if (previousValueString == null && currentValueString != null ||
                        previousValueString != null && !previousValueString.Equals(currentValueString))
                    {
                        //add properties info the the different properties dictionary
                        differentProperties.Add(typeProperty.Name,
                            new ObjectVersion(previousValueString, currentValueString));
                    }
                }
            }

            return differentProperties;
        }

        /// <summary>
        /// Creates a flatted hashtable representation of a IDictionary<string, ObjectVersion>
        /// </summary>
        /// <param name="properties">Properties to flat</param>
        /// <returns>A hashtable with the flattened representation</returns>
        public static Hashtable GetFlattenedProperties(IDictionary<string, ObjectVersion> properties)
        {
            //reserve space for twice the size of the original properties collection
            Hashtable propertiesToReturn = new Hashtable(properties.Count * 2);

            foreach (string propertyName in properties.Keys)
            {
                //add the previous value to the hash
                propertiesToReturn.Add("Previous" + propertyName, properties[propertyName].PreviousValue);
                //add the current value to the hash
                propertiesToReturn.Add("Current" + propertyName, properties[propertyName].CurrentValue);
            }

            return propertiesToReturn;
        }
    }
}