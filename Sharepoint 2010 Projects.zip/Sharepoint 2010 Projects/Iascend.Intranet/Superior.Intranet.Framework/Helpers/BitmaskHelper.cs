using System;
using System.Collections.Generic;
using System.Text;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// Bitmask helper
    /// </summary>
    public class BitmaskHelper
    {
        /// <summary>
        /// Check enum
        /// </summary>
        /// <param name="Bitmask"></param>
        /// <param name="Bits"></param>
        /// <returns></returns>
        public static bool CheckEnum(int Bitmask, int Bits)
        {
            return ((Bitmask & Bits) == Bits);
        }
    }
}
