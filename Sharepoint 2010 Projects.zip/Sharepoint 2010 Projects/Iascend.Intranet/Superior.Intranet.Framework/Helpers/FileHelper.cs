﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// File helper
    /// </summary>
    public class FileHelper
    {
        /// <summary>
        /// Write file
        /// </summary>
        /// <param name="fileLocation"></param>
        /// <param name="fileContent"></param>
        public static void WriteFile(string fileLocation, byte[] fileContent)
        {
            File.WriteAllBytes(fileLocation, fileContent);
        }

        /// <summary>
        /// Read file
        /// </summary>
        /// <param name="fileLocation"></param>
        /// <returns></returns>
        public static byte[] ReadFile(string fileLocation)
        {
            return File.ReadAllBytes(fileLocation);
        }
    }
}
