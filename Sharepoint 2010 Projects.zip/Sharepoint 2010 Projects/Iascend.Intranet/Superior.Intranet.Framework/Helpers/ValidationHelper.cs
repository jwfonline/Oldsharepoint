﻿using System;
using Regex=System.Text.RegularExpressions.Regex;
using Match = System.Text.RegularExpressions.Match;

namespace Iascend.Intranet.Framework.Helpers
{
    /// <summary>
    /// This public helper exposes basic methods for input validation
    /// </summary>
    public class ValidationHelper
    {
        public static bool IsWithinRange<T>(T data, T min, T max, bool inclusive)
        {
            if (default(T) is IComparable)
            {
                int minCompare = ((IComparable)data).CompareTo((IComparable)min);
                int maxCompare = ((IComparable)data).CompareTo((IComparable)max);

                if (inclusive)
                {
                    return minCompare >= 0 && maxCompare <= 0;
                }
                else
                {
                    return minCompare == 1 && maxCompare == -1;
                }
            }
            else
            {
                throw new ArgumentException("Type must be IComparable");
            }
        }

        /// <summary>
        /// Converts the string representation of a Guid to its Guid 
        /// equivalent. A return value indicates whether the operation 
        /// succeeded. 
        /// </summary>
        /// <param name="s">A string containing a Guid to convert.</param>
        /// <param name="result">
        /// When this method returns, contains the Guid value equivalent to 
        /// the Guid contained in <paramref name="s"/>, if the conversion 
        /// succeeded, or <see cref="Guid.Empty"/> if the conversion failed. 
        /// The conversion fails if the <paramref name="s"/> parameter is a 
        /// <see langword="null" /> reference (<see langword="Nothing" /> in 
        /// Visual Basic), or is not of the correct format. 
        /// </param>
        /// <value>
        /// <see langword="true" /> if <paramref name="s"/> was converted 
        /// successfully; otherwise, <see langword="false" />.
        /// </value>
        /// <exception cref="ArgumentNullException">
        ///        Thrown if <pararef name="s"/> is <see langword="null"/>.
        /// </exception>
        public static bool GuidTryParse(string s, out Guid result)
        {
            if (s == null)
                throw new ArgumentNullException("s");
            Regex format = new Regex(
                "^[A-Fa-f0-9]{32}$|" +
                "^({|\\()?[A-Fa-f0-9]{8}-([A-Fa-f0-9]{4}-){3}[A-Fa-f0-9]{12}(}|\\))?$|" +
                "^({)?[0xA-Fa-f0-9]{3,10}(, {0,1}[0xA-Fa-f0-9]{3,6}){2}, {0,1}({)([0xA-Fa-f0-9]{3,4}, {0,1}){7}[0xA-Fa-f0-9]{3,4}(}})$");
            Match match = format.Match(s);
            if (match.Success)
            {
                result = new Guid(s);
                return true;
            }
            else
            {
                result = Guid.Empty;
                return false;
            }
        }
    }
}
