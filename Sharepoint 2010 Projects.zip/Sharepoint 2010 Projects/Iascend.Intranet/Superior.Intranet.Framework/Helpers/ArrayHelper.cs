using System;
using System.Reflection; 
using System.Collections;

namespace Iascend.Intranet.Framework.Helpers{

	/// <summary>
	/// Summary description for ArrayHelper.
	/// </summary>
	public abstract class ArrayHelper{

        public static System.Array ResizeArray (System.Array OldArray) {           
            
            System.Type ElementType = OldArray.GetType().GetElementType();
            System.Array NewArray = System.Array.CreateInstance(ElementType, OldArray.Length + 1);
                                   
            System.Array.Copy(OldArray, NewArray, OldArray.Length);

            return NewArray; 

        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="Source"></param>
		/// <param name="NewItem"></param>
		/// <returns></returns>
		public static object[] AddItemToArray(object[] Source, object NewItem){

			// Convert array to arraylist
			ArrayList Al = new ArrayList(Source);

			//add item to arraylist
			Al.Add(NewItem);

			//put arraylist back into new array
			object[] NewArray = Al.ToArray();

			return NewArray;
		}

		/// <summary>
		/// Helper method to Split a single byte array into
		/// multiple byte arrays of a certain length. The last
		/// byte array may be shorter than the max length depending
		/// on the size of the original.
		/// </summary>
		/// <param name="ArgMaster">the original array</param>
		/// <param name="ArgMaxLength">the length of each smaller array</param>
		/// <returns>array list with each element as a byte[]
		/// no longer than the max length parameter</returns>
		public static IList SplitByteArray(byte[] ArgMaster, long ArgMaxLength) {
			
			if(ArgMaster == null || ArgMaster.Length <= 1 || ArgMaxLength <= 0) return null;
			int SplitCount = Convert.ToInt16(ArgMaster.Length / ArgMaxLength);
            
			// Handle the zero case
			if(SplitCount == 0) {
				ArrayList RetVal = new ArrayList(1);
				RetVal.Add(ArgMaster);
				return RetVal;
			}

			if((ArgMaster.Length % ArgMaxLength) != 0) SplitCount++;

			int TotalBytesRead = 0;
			ArrayList SplitArrays = new ArrayList(SplitCount);

			for(int i = 0; i < SplitCount; i++) {
				byte[] Split = new byte[i == SplitCount -1 ? ArgMaster.Length - TotalBytesRead : ArgMaxLength];
				for(int j = 0; j < ArgMaxLength && TotalBytesRead < ArgMaster.Length; j++) {
					Split[j] = ArgMaster[TotalBytesRead++];
				}
				SplitArrays.Add(Split);
			}
			return SplitArrays;
		}

		/// <summary>
		/// Helper method to Split a single byte array into
		/// multiple byte arrays of a certain length. The last
		/// byte array may be shorter than the max length depending
		/// on the size of the original. If the pad last boolean parameter
		/// is provided, each block will be the same.
		/// </summary>
		/// <param name="ArgMaster">the original array</param>
		/// <param name="ArgMaxLength">the length of each smaller array</param>
		/// <param name="ArgPadLast">Indicates if the last element in the array
		/// should be padded to match the length of the others</param>
		/// <returns>array list with each element as a byte[]
		/// no longer than the max length parameter</returns>
		public static IList SplitByteArray(byte[] ArgMaster, long ArgMaxLength, bool ArgPadLast) {
			
			if(ArgMaster == null || ArgMaster.Length <= 1 || ArgMaxLength <= 0) return null;
			int SplitCount = Convert.ToInt16(ArgMaster.Length / ArgMaxLength);
            
			// Handle the zero case
			if(SplitCount == 0) {
				ArrayList RetVal = new ArrayList(1);
				RetVal.Add(ArgMaster);
				return RetVal;
			}
			if((ArgMaster.Length % ArgMaxLength) != 0) SplitCount++;

			int TotalBytesRead = 0;
			ArrayList SplitArrays = new ArrayList(SplitCount);

			for(int i = 0; i < SplitCount; i++) {
				byte[] Split = null;
				if(ArgPadLast) {
					Split = new byte[ArgMaxLength];
				}else {
					Split = new byte[i == SplitCount -1 ? ArgMaster.Length - TotalBytesRead : ArgMaxLength];
				}

				for(int j = 0; j < ArgMaxLength && TotalBytesRead < ArgMaster.Length; j++) {
					Split[j] = ArgMaster[TotalBytesRead++];
				}
				SplitArrays.Add(Split);
			}
			return SplitArrays;
		}

		/// <summary>
		/// Convert the keys of a dictionary to an Object[].
		/// </summary>
		/// <param name="ArgDictionary">The dictionary to extract the
		/// keys from.</param>
		/// <returns>Object[] of keys from the dictionary</returns>
		public static Object[] GetKeysAsArray(IDictionary ArgDictionary) {
			
			if(ArgDictionary == null)return null;
			
			int Counter = 0;
			Object[] keys = new Object[ArgDictionary.Count];
			
			foreach(Object obj in ArgDictionary.Keys) {
				keys[Counter++] = obj;
			}
			return keys;
		}

		/// <summary>
		/// Convert the values of a dictionary to an Object[].
		/// </summary>
		/// <param name="ArgDictionary">The dictionary to extract the
		/// values from.</param>
		/// <returns>Values of the dictionary as an Object[]</returns>
		public static Object[] GetValuesAsArray(IDictionary ArgDictionary) {
			
			if(ArgDictionary == null)return null;
			
			int Counter = 0;
			Object[] values = new Object[ArgDictionary.Count];
			
			foreach(Object obj in ArgDictionary.Values) {
				values[Counter++] = obj;
			}
			return values;
		}
	}
}
