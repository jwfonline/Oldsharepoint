﻿using System;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Net;
using System.Security.Principal;
using System.Collections;
using System.Globalization;

using Iascend.Intranet.Framework.Extensions;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.Framework.Services;

using Microsoft.SharePoint;
using Iascend.Intranet.Framework.Enumerations;

namespace Iascend.Intranet.Framework.Helpers
{
    public static class SPHelper
    {
        #region Public CAML Query Templates

        //"<Where><And>" +
        //"<Eq><FieldRef Name='Company'/> <Value Type='CHOICE'>Test Company</Value></Eq>" +
        //"<Eq><FieldRef Name='Site Type'/><Value Type='CHOICE'>Plant</Value></Eq>" +
        //"</And></Where>";

        /// <summary>
        /// This is the outer shell for a CAML View.  It requires two areas to be filled in.
        /// {0} - The actual query component, a simple statement or a combination of or/and statements
        /// {1} - The view fields (columns) to return
        /// </summary>
        public const string VIEW_OUTER_SHELL =
        @"<View>" +
                   "<Query>" +
                        "{0}" +
                   "</Query>" +
                   "<ViewFields>" +
                        "{1}" +
                   "</ViewFields>" +
          "</View>";

        /// <summary>
        /// This is the simple where clause
        /// {0} - The actual query component, a simple statement or a combination of or/and statements
        /// <Eq><FieldRef Name='Company'/> <Value Type='CHOICE'>Test Company</Value></Eq>
        /// </summary>
        public const string SIMPLE_WHERE =
        @"<Where>" +
            "{0}" +
         "</Where>";

        /// <summary>
        /// This is a simple query clause.  It allows one field to be checked
        /// {0} - The single clause
        /// </summary>
        public const string SIMPLE_QUERY =
        @"{0}";

        /// <summary>
        /// This is a complex query clause.  It allows for a group of operations to be performed
        /// {0} - The aggregate operation to perform (And/Or, etc..)
        /// {1} - The 1 or more filter clauses
        /// </summary>
        public const string COMPLEX_QUERY =
        @"<{0}>" +
               "{1}" +
        "</{0}>";

        /// <summary>
        /// This is the filter clause.  It supports a filter operation, and it expects a field name, type, and value.
        /// {0} - The filter operation to perform (Eq, etc...)
        /// {1} - The field reference
        /// {2} - The field type and value
        /// <Eq><FieldRef Name='Company'/> <Value Type='CHOICE'>Test Company</Value></Eq>
        /// </summary>
        public const string FILTER_CLAUSE =
        @"<{0}>{1}{2}</{0}>";

        /// <summary>
        /// Simple field reference clause
        /// {0} - The field name
        /// {1} - The IncludeTimeValue="TRUE" attribute for datetime fields
        /// <FieldRef Name='Company'/>
        /// </summary>
        public const string FIELD_NAME = @"<FieldRef Name='{0:S}' {1}/>";

        /// <summary>
        /// Simple field type clause
        /// {0} - The field type
        /// {1} - The field value
        /// <FieldRef Name='Company'/>
        /// </summary>
        public const string FIELD_TYPE = @"<Value Type='{0}'>{1}</Value>";

        #endregion

        #region Public Static CAML Methods

        /// <summary>
        /// This method builds a complex view.  It calls build complex query and wraps it 
        /// in a view template
        /// <param name="fields">The fields to query/filter by</param>
        /// <param name="operation">The aggregate operation to perform (and/or)</param> 
        /// <returns>Full View Query for filtering</returns>
        public static string BuildComplexView(FieldFilterCollection fields,
                                              List<string> returnedFields)
        {
            if (fields == null)
            {
                throw new Exception("Fields list cannot be null");
            }

            // generate the search query
            string searchQuery = BuildComplexQuery(fields);
            // generate thh view fields
            string fieldQuery = BuildViewFieldsXml(returnedFields);
            // return the formatted string of data
            return String.Format(VIEW_OUTER_SHELL, searchQuery, fieldQuery);
        }

        /// <summary>
        /// This method takes a list of fields and an aggregate operation and then
        /// attempts to build a where clause query
        /// </summary>
        /// <param name="fields">The fields to create</param>
        /// <param name="operation">The aggregate operation to perform</param>
        /// <returns></returns>
        public static string BuildComplexQuery(FieldFilterCollection fields)
        {
            if (fields == null || fields.Count == 0)
            {
                throw new Exception("Fields list cannot be null or empty");
            }

            // instantiate the complex query data
            string complexQuery = String.Empty;
            // build the where clause
            string whereClause = BuildWhereClauseElements(fields);
            // wrap the outer layers
            complexQuery = String.Format(SIMPLE_WHERE, whereClause);

            return complexQuery;
        }

        /// <summary>
        /// This method builds and returns all the build clause elements
        /// </summary>
        ///  <{0}>{1}</{0}>";  complex query
        /// <param name="fields"></param>
        /// <returns></returns>
        private static string BuildWhereClauseElements(FieldFilterCollection fields)
        {
            if (fields == null || fields.Count == 0)
            {
                throw new Exception("Fields list cannot be null or empty");
            }

            // declare local variables needed for temporary storage
            StringBuilder whereClauses = new StringBuilder(500);
            string outerLayer = String.Empty;
            string fieldReference = String.Empty;
            string fieldValue = String.Empty;
            bool nullCheckOperation = true;
            string finalClauseQuery = String.Empty;

            foreach (FilterField field in fields)
            {
                // check to see if we have a field name, otherwise continue
                if (field.FieldName.IsNullEmptyOrEmptySpaces())
                {
                    throw new Exception("Bad filter field, the name cannot be null");
                }

                // save off flag to see if this is a null check
                nullCheckOperation = (field.OperationType == IndividualQueryOperation.IsNull ||
                                      field.OperationType == IndividualQueryOperation.IsNotNull);

                // check to see if we have/need a value, otherwise continue
                if (field.FieldValue.IsNullEmptyOrEmptySpaces() && !nullCheckOperation)
                {
                    throw new Exception("Bad filter field, no field value, and not a null check");
                }

                // Build the field reference
                //FIELD_NAME = @"<FieldRef Name='{0:S}' {1}/>";
                fieldReference = String.Format(FIELD_NAME, field.FieldName,
                                               (field.FieldValueType == FieldValueType.DateTime) ?
                                               "IncludeTimeValue='TRUE'" : String.Empty);

                // Build the field value
                //FIELD_TYPE = @"<Value Type='{0}'>{1}</Value>";
                fieldValue = (!nullCheckOperation) ?
                                String.Format(FIELD_TYPE, field.FieldValueType.GetStringValue(),
                                              field.FieldValue) : null;
                // build clause
                //@"<{0}>{1}{2}</{0}>";
                outerLayer = String.Format(FILTER_CLAUSE, field.OperationType.GetStringValue(),
                                           fieldReference, fieldValue);
                // append to list of clauses
                whereClauses.Append(outerLayer);

                // also append any sub level clauses
            }

            // After looping on all the fields, add any sub child collection elements
            if (fields.ChildFilterCollection != null && fields.ChildFilterCollection.Count > 0)
            {
                whereClauses.Append(BuildWhereClauseElements(fields.ChildFilterCollection));
            }

            // now format into the proper aggregate operation final string
            if (fields.Count > 1)
            {
                finalClauseQuery = String.Format(COMPLEX_QUERY,
                                                fields.QueryOperation.ToString(),
                                                whereClauses.ToString());
            }
            else
            {
                finalClauseQuery = String.Format(SIMPLE_QUERY, whereClauses.ToString());
            }
            return finalClauseQuery;
        }

        /// <summary>
        /// Converts a field into a template field reference for CAML views
        /// </summary>
        /// <param name="field">The field name to convert/build</param>
        /// <returns>CAML complaint XML required for CAML query</returns>
        public static string BuildViewFieldXml(string field)
        {
            if (field.IsNullEmptyOrEmptySpaces())
            {
                throw new Exception("Field list cannot be null");
            }

            return String.Format(FIELD_NAME, field)
                         .Replace(" ", "_x0020_");
        }

        /// <summary>
        /// Converts multiple fields into a template field reference for CAML Views
        /// </summary>
        /// <param name="fields">The array of field names to convert</param>
        /// <returns>CAML complaint XML required for CAML query</returns>
        public static string BuildViewFieldsXml(List<string> fields)
        {
            if (fields == null || fields.Count == 0)
            {
                throw new Exception("Fields list cannot be null or empty");
            }
            return String.Join("", fields.Select(s => BuildViewFieldXml(s)).ToArray());
        }

        #endregion

        #region Simplified SharePoint Access Members

        /// <summary>
        /// This overloaded method accepts a list name, filters, the returned fields,
        /// and the aggregate operation to perform.  It then generates the select query
        /// and passes it to the next overloaded version of the GetSPList
        /// </summary>
        /// <param name="listName">The list name to lookup</param>
        /// <param name="filters">The filter criteria for the query</param>
        /// <returns>A datatable of specified fields</returns>
        public static DataTable GetSPList(Folder folder, string listName, FieldFilterCollection filters)
        {
            // if we have filters, try to create them

            if (filters != null && filters.Count > 0)
            {
                return GetSPList(folder, listName, filters, null);
            }
            else
            {
                // no filter search
                return GetSPList(listName);
            }
        }

        /// <summary>
        /// This overloaded method accepts a list name, filters, folder, the returned fields,
        /// and the aggregate operation to perform.  It then generates the select query
        /// and passes it to the next overloaded version of the GetSPList
        /// </summary>
        /// <param name="listName">The list name to lookup</param>
        /// <param name="filters">The filter criteria for the query</param>
        /// <param name="returnedFields">The fields to return in the view</param>
        /// <returns>A datatable of specified fields</returns>
        public static DataTable GetSPList(Folder folder, string listName, FieldFilterCollection filters,
                                          List<string> returnedFields)
        {
            string selectXML = (returnedFields != null) ?
                    SPHelper.BuildComplexView(filters, returnedFields) :
                    SPHelper.BuildComplexQuery(filters);
            return GetSPList(folder, listName, selectXML);
        }

        #endregion

        #region Core SharePoint Access Members

        /// <summary>
        /// Add a new item to the SPList
        /// </summary>
        /// <param name="listName"></param>
        /// <param name="fileds"></param>
        /// <returns></returns>
        public static bool AddSPListItem(string listName, Dictionary<string, string> fileds)
        {
            using (SPSite site = new SPSite(SharepointSiteURL))
            {
                if (site == null)
                {
                    throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);
                }

                using (SPWeb web = site.OpenWeb("/"))
                {
                    if (web == null)
                    {
                        throw new Exception("Failed to access the Sharepoint Site : " + SharepointSiteURL);
                    }

                    SPListItem item = web.Lists[listName].Items.Add();

                    foreach (KeyValuePair<string, string> kvp in fileds)
                    {
                        item.Properties.Add(kvp.Key, kvp.Value);
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Create Documentlibrary Folder
        /// </summary>
        /// <param name="folderList"></param>
        /// <param name="documentLibraryfolder"></param>
        /// <returns></returns>
        private static SPFolder CreateSPFolderStructure(IList<string> folderList, SPFolder documentLibraryfolder)
        {

            SPFolder documentfolder = null;
            string folderName = string.Empty;

            if ((folderList == null) || (folderList.Count == 0))
            {
                return documentLibraryfolder;
            }
            else
            {
                folderName = folderList[0];
                folderList.RemoveAt(0);
            }

            try
            {
                documentfolder = documentLibraryfolder.SubFolders[folderName];
            }
            catch
            {
            }
            if (documentfolder == null)
            {
                documentfolder = documentLibraryfolder.SubFolders.Add(folderName);
            }
            return CreateSPFolderStructure(folderList, documentfolder);
        }

        /// <summary>
        /// Returns a byte array of the requested document
        /// </summary>
        /// <param name="DocumentLibraryName"></param>
        /// <param name="folderPath"></param>
        /// <param name="documentName"></param>
        /// <returns></returns>
        public static byte[] GetDocument(string DocumentLibraryName, string folderPath, string documentName)
        {
            byte[] data = null;

            using (SPSite site = new SPSite(SharepointSiteURL))
            {
                if (site == null)
                {
                    throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);
                }

                using (SPWeb web = site.OpenWeb("/"))
                {
                    if (web == null)
                    {
                        throw new Exception("Failed to access the Sharepoint Site : " + SharepointSiteURL);
                    }

                    SPFolder spfolder = folderPath.IsNullEmptyOrEmptySpaces() ? web.Folders[DocumentLibraryName] : GetSPDocumentFolder(folderPath, web.Folders[DocumentLibraryName]);
                    data = spfolder.Files[documentName].OpenBinary();
                }
            }

            return data;
        }

        /// <summary>
        /// Get SPDocumentFolder
        /// </summary>
        /// <param name="folderList"></param>
        /// <param name="documentLibraryfolder"></param>
        /// <returns></returns>
        private static SPFolder GetSPDocumentFolder(string folderName, SPFolder documentLibraryfolder)
        {
            string[] folderNames = folderName.Split('/');
            IList<string> folderList = new List<string>(folderNames);

            for (int i = 0; i < folderList.Count; i++)
            {
                documentLibraryfolder = documentLibraryfolder.SubFolders[folderList[i]];
            }
            return documentLibraryfolder;
        }

        /// <summary>
        /// This method returns data from a list based on the selectXML criteria (ViewXML)
        /// </summary>
        /// <param name="userCredentials"></param>
        /// <param name="subSiteURL"></param>
        /// <param name="listName"></param>
        /// <param name="siteCollectionURL"></param>
        /// <param name="selectXML"></param>
        /// <returns></returns>
        public static DataTable GetSPListBySite(string siteUrl, string listName, string selectXML)
        {
            DataTable table = new DataTable();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    if (site == null)
                        throw new Exception("Failed to access the Sharepoint Site : " + siteUrl);

                    using (SPWeb web = site.OpenWeb())
                    {
                        if (web == null)
                            throw new Exception("Failed to access the Sharepoint Site : " + siteUrl);

                        if (!selectXML.IsNullEmptyOrEmptySpaces())
                        {
                            SPQuery spQuery = new SPQuery();

                            if (selectXML.Contains("<where>"))
                            {
                                spQuery.ViewXml = selectXML;
                            }
                            else
                            {
                                spQuery.Query = selectXML;
                            }

                            if (web.Lists[listName] is SPDocumentLibrary)
                            {
                                // get access to the document library
                                SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                                // pull a subcollection of items
                                SPListItemCollection subItems = spdoc.GetItems(spQuery);
                                table = subItems.GetDataTable();
                                if (subItems != null && subItems != null &&
                                    table != null && table.Rows != null)
                                {
                                    EnhanceTableColumns(table);
                                    LoadItems(subItems, table);
                                }
                            }
                            else
                            {
                                table = web.Lists[listName].GetItems(spQuery).GetDataTable();
                            }
                        }
                        else
                        {
                            if (web.Lists[listName] is SPDocumentLibrary)
                            {
                                SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                                table = spdoc.Items.GetDataTable();

                                // Need to pull 5-8 unique properties from spdocument library 
                                // that aren't available via the GetDataTable call.
                                if (spdoc != null && spdoc.Items != null && table != null && table.Rows != null)
                                {
                                    EnhanceTableColumns(table);
                                    LoadItems(spdoc.Items, table);
                                }
                            }
                            else
                            {
                                table = web.Lists[listName].Items.GetDataTable();
                            }

                        }


                    }

                }
            });

            return table;
        }

        /// <summary>
        /// This overload method returns data from a list based on the selectXML criteria (ViewXML) usign folder as a parameter
        /// </summary>
        /// <param name="userCredentials"></param>
        /// <param name="subSiteURL"></param>
        /// <param name="listName"></param>
        /// <param name="siteCollectionURL"></param>
        /// <param name="selectXML"></param>
        /// <returns></returns>
        public static DataTable GetSPList(ICredentials userCredentials, string subSiteURL, string listName,
                                    string siteCollectionURL, string selectXML, Folder Folder)
        {
            DataTable table = new DataTable();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(siteCollectionURL))
                {
                    if (site == null)
                        throw new Exception("Can not find Sharepoint Site Collection: " + siteCollectionURL);

                    if (subSiteURL.Trim().Equals(String.Empty))
                    {
                        //subSiteURL = "/";
                    }
                    using (SPWeb web = site.OpenWeb(subSiteURL))
                    {
                        if (web == null)
                            throw new Exception("Failed to access the Sharepoint Site : " + subSiteURL);


                        if (!selectXML.IsNullEmptyOrEmptySpaces())
                        {
                            SPQuery spQuery = new SPQuery();

                            if (selectXML.Contains("<where>"))
                            {
                                spQuery.ViewXml = selectXML;
                            }
                            else
                            {
                                spQuery.Query = selectXML;
                            }

                            foreach (SPFolder subFolder in web.Lists[listName].RootFolder.SubFolders)
                            {
                                if (subFolder.Name == Folder.FolderName)
                                {
                                    spQuery.Folder = subFolder;
                                    break;
                                }
                            }

                            if (web.Lists[listName] is SPDocumentLibrary)
                            {
                                // get access to the document library
                                SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                                // pull a subcollection of items

                                SPListItemCollection subItems = spdoc.GetItems(spQuery);
                                table = subItems.GetDataTable();
                                if (subItems != null && subItems != null &&
                                    table != null && table.Rows != null)
                                {
                                    EnhanceTableColumns(table);
                                    LoadItems(subItems, table);
                                }
                            }
                            else
                            {
                                table = web.Lists[listName].GetItems(spQuery).GetDataTable();
                            }
                        }
                        else
                        {
                            if (web.Lists[listName] is SPDocumentLibrary)
                            {
                                SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                                table = spdoc.Items.GetDataTable();

                                // Need to pull 5-8 unique properties from spdocument library 
                                // that aren't available via the GetDataTable call.
                                if (spdoc != null && spdoc.Items != null && table != null && table.Rows != null)
                                {
                                    EnhanceTableColumns(table);
                                    LoadItems(spdoc.Items, table);
                                }
                            }
                            else
                            {
                                table = web.Lists[listName].Items.GetDataTable();
                            }

                        }


                    }
                }
            });

            return table;
        }

        /// <summary>
        /// Returns the SharePoint List from the specified web url as a data table.
        /// </summary>
        /// <param name="listTitle"></param>
        /// <param name="webUrl"></param>
        /// <returns></returns>
        public static DataTable GetSPListByListTitle(string listTitle, string webUrl)
        {
            DataTable dt = new DataTable();

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite currentSite = new SPSite(webUrl))
                {
                    using (SPWeb currentWeb = currentSite.OpenWeb())
                    {
                        SPList list = currentWeb.Lists.TryGetList(listTitle);

                        if (list != null)
                        {
                            dt = list.Items.GetDataTable();
                            if (dt == null)
                            {
                                dt = new DataTable();
                            }
                        }
                    }
                }
            });

            return dt;
        }

        /// <summary>
        /// Returns the SharePoint List from the specified web url as a data table.
        /// </summary>
        /// <param name="listTitle"></param>
        /// <param name="webUrl"></param>
        /// <returns></returns>
        public static DataTable GetSPListByListTitle(string listTitle, string webUrl, bool asCurrentUser)
        {
            if (asCurrentUser)
            {
                DataTable dt = new DataTable();

                using (SPSite currentSite = new SPSite(webUrl))
                {
                    using (SPWeb currentWeb = currentSite.OpenWeb())
                    {
                        SPList list = currentWeb.Lists.TryGetList(listTitle);

                        if (list != null)
                        {
                            dt = list.Items.GetDataTable();
                        }
                    }
                }

                return dt;
            }
            else
            {
                return GetSPListByListTitle(listTitle, webUrl);
            }
        }

        /// <summary>
        /// This method attempts to pull data from a document library.  It requires
        /// select and view xml query parameters to be effective
        /// </summary>
        /// <param name="userCredentials"></param>
        /// <param name="subSiteURL"></param>
        /// <param name="listName"></param>
        /// <param name="siteCollectionURL"></param>
        /// <param name="selectXML"></param>
        /// <param name="viewXML"></param>
        /// <returns></returns>
        public static DataTable GetSPDocumentLibraryWithCredentials(ICredentials userCredentials, string subSiteURL,
                                                                    string listName, string siteCollectionURL,
                                                                    string selectXML, string viewXML)
        {

            using (SPSite site = new SPSite(siteCollectionURL))
            {
                if (site == null)
                    throw new Exception("Can not find Sharepoint Site Collection: " + siteCollectionURL);

                if (subSiteURL.Trim().Equals(String.Empty))
                {
                    subSiteURL = "/";
                }
                using (SPWeb web = site.OpenWeb(subSiteURL))
                {
                    if (web == null)
                        throw new Exception("Failed to access the Sharepoint Site : " + subSiteURL);

                    DataTable table = null;
                    // check to see if we have a query to filter by
                    if (!selectXML.IsNullEmptyOrEmptySpaces())
                    {
                        SPQuery spQuery = new SPQuery();
                        spQuery.ViewXml = selectXML;
                        if (web.Lists[listName] is SPDocumentLibrary)
                        {
                            SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                            SPListItemCollection subItems = spdoc.GetItems(spQuery);
                            table = subItems.GetDataTable();
                            if (subItems != null && subItems != null &&
                                table != null && table.Rows != null)
                            {
                                EnhanceTableColumns(table);
                                LoadItems(subItems, table);
                            }
                        }
                        else
                        {
                            table = web.Lists[listName].GetItems(spQuery).GetDataTable();
                        }

                    }
                    else
                    {
                        if (web.Lists[listName] is SPDocumentLibrary)
                        {
                            SPDocumentLibrary spdoc = (SPDocumentLibrary)web.Lists[listName];
                            table = spdoc.Items.GetDataTable();

                            // Need to pull 5-8 unique properties from spdocument library 
                            // that aren't available via the GetDataTable call.
                            if (spdoc != null && spdoc.Items != null &&
                                table != null && table.Rows != null)
                            {
                                EnhanceTableColumns(table);
                                LoadItems(spdoc.Items, table);
                            }
                        }
                        else
                        {
                            table = web.Lists[listName].Items.GetDataTable();
                        }

                    }

                    if (table != null)
                    {
                        table.ReassignColumns();
                    }
                    return table;
                }
            }
        }

        public static DataTable GetSPList(Folder folder, string listName, string selectXML)
        {
            string siteCollectionURL = SharepointSiteURL;
            ICredentials userCredentials = CurrentWindowsCredentials;
            string subSiteURL = String.Empty;
            return GetSPList(userCredentials, subSiteURL, listName, siteCollectionURL, selectXML, folder);
        }

        public static DataTable GetSPDocumentLibrary(string listName, string selectXML, string viewXML)
        {
            string siteCollectionURL = SharepointSiteURL;
            ICredentials userCredentials = CurrentWindowsCredentials;
            string subSiteURL = String.Empty;
            DataTable retval = GetSPDocumentLibraryWithCredentials(userCredentials, subSiteURL, listName, siteCollectionURL, selectXML, viewXML);
            return retval;
        }

        public static DataTable GetSPList(string listName)
        {
            string siteCollectionURL = SharepointSiteURL;
            return GetSPListBySite(siteCollectionURL, listName, null);
        }

        public static DataTable GetSPList(string listName, string siteURL)
        {
            return GetSPListBySite(siteURL, listName, null);
        }

        public static SPList GetSPList(SharePointLists listName)
        {
            SPList returnList = null;

            using (SPSite site = new SPSite(SharepointSiteURL))
            {
                if (site == null)
                {
                    throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);
                }

                using (SPWeb web = site.OpenWeb("/"))
                {
                    if (web == null)
                    {
                        throw new Exception("Failed to access the Sharepoint Site : " + SharepointSiteURL);
                    }

                    returnList = web.Lists.TryGetList(listName.GetStringValue());
                }
            }

            return returnList;
        }

        /// <summary>
        /// This method checks to see if a SharePoint document by a certain name exists in a list/library
        /// </summary>
        /// <param name="documentLibrary"></param>
        /// <param name="folderPath"></param>
        /// <param name="documentName"></param>
        /// <returns></returns>
        public static bool SharePointDocumentExists(string documentLibrary, string folderPath,
                                                    string documentName)
        {
            try
            {
                SPFolder spfolder = folderPath.IsNullEmptyOrEmptySpaces() ? RootSPWeb.Folders[documentLibrary] : RootSPWeb.Folders[documentLibrary].SubFolders[folderPath];
                if (spfolder.Files[documentName] != null)
                {

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// /// Upload a Document to the document library and apply given metadata.
        /// </summary>
        /// <param name="document"></param>
        /// <param name="documentProperties"></param>
        /// <returns></returns>
        public static bool UploadDocument(byte[] document, Hashtable documentProperties)
        {
            if (documentProperties == null)
            {
                throw new Exception("documentProperties can not be null");
            }

            string documentLibraryName = (string)documentProperties["document_library_name"];
            string folderName = (string)documentProperties["document_folder_name"];
            string documentURL = (string)documentProperties["document_url"];
            int overWriteFlag;

            if (!int.TryParse((string)documentProperties["document_overwrite_flag"], out overWriteFlag))
            {
                throw new Exception("Incorrect value for 'document_overwrite_flag'");

            }
            if (documentLibraryName.IsNullEmptyOrEmptySpaces())
            {
                throw new Exception("'document_library_name' can not be empty");
            }

            if (documentURL.IsNullEmptyOrEmptySpaces())
            {
                throw new Exception("'document_url' can not be empty");
            }


            SPFolder documentLibraryfolder = RootSPWeb.Folders[documentLibraryName];
            SPFolder documentfolder = null;

            if (documentLibraryfolder == null)
            {
                throw new ArgumentException(string.Format("Can not find the document librray {0}", documentLibraryName));
            }

            if (!folderName.IsNullEmptyOrEmptySpaces())
            {
                string[] folderNames = folderName.Split('\\');
                IList<string> folderList = new List<string>(folderNames);

                documentfolder = CreateSPFolderStructure(folderList, documentLibraryfolder);

            }
            else
            {
                documentfolder = documentLibraryfolder;
            }

            try
            {
                if (documentfolder.Files[documentURL] != null)
                {
                    switch (overWriteFlag)
                    {
                        case 0: // overwrite
                            documentfolder.Files[documentURL].Delete();
                            break;
                        case 1: // add new version
                            break;
                        case 2: // skip upload
                            return true;
                    }
                }
            }
            catch
            {
                // catch and ignore the sharepoint exception thrown while trying to access a resource that does not exisits.

            }

            SPFile file = documentfolder.Files.Add(documentURL, document, documentProperties, true);

            if (file == null)
                return false;
            else
                return true;

        }

        /// <summary>
        /// This method gets the mail server instance from SharePoint
        /// </summary>
        /// <returns>The SharePoint SMTP server instance</returns>
        public static string GetMailServer()
        {
            string retval = "localhost";
            using (SPSite site = new SPSite(SharepointSiteURL))
            {
                if (site == null)
                {
                    throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);
                }

                using (SPWeb web = site.OpenWeb("/"))
                {
                    if (web != null && web.Site != null &&
                       web.Site.WebApplication != null &&
                       web.Site.WebApplication.OutboundMailServiceInstance != null &&
                       web.Site.WebApplication.OutboundMailServiceInstance.Server != null)
                    {
                        retval = web.Site.WebApplication.OutboundMailServiceInstance.Server.Address;
                    }
                }
            }
            return retval;
        }

        /// <summary>
        /// Add a new list item to a sharepoint list
        /// </summary>
        /// <param name="listName">The listname to add this item too</param>
        /// <param name="item">The list properties to set</param>
        public static void AddNewListItem(string listName, Dictionary<string, string> data)
        {
            // Need to explicitly declare impersonation
            WindowsImpersonationContext wic = WindowsIdentity.GetCurrent().Impersonate();
            // run with elevated priviledges
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SharepointSiteURL))
                {
                    if (site == null)
                        throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);

                    using (SPWeb web = site.OpenWeb("/"))
                    {
                        if (web == null)
                        {
                            throw new Exception("Failed to access the Sharepoint Site : /");
                        }

                        // Need to first to allow unsafe updates
                        site.AllowUnsafeUpdates = web.AllowUnsafeUpdates = true;
                        // add new item
                        SPListItem newItem = web.Lists[listName].Items.Add();

                        foreach (KeyValuePair<string, string> pair in data)
                        {
                            newItem[pair.Key] = pair.Value;
                        }
                        newItem.Update();
                        // remove unsafe updates
                        site.AllowUnsafeUpdates = web.AllowUnsafeUpdates = false;
                    }
                }
            });
            // undo impersonation
            wic.Undo();
        }

        #endregion

        #region SharePointAccess Private Properties

        /// <summary>
        /// return the current windows credentials for a SharePoint lookup
        /// </summary>
        private static ICredentials CurrentWindowsCredentials
        {
            get
            {
                if (WindowsIdentity.GetCurrent() is ICredentials)
                {
                    return (ICredentials)WindowsIdentity.GetCurrent();
                }
                else
                {
                    System.Net.NetworkCredential custom = new
                    System.Net.NetworkCredential("cs_admin",
                                                 "p@ssw0rd1", "dmz");
                    return (ICredentials)custom;
                }

                //return default(ICredentials);
            }
        }

        /// <summary>
        /// return the sharepoint site url from the web.config appsettings section
        /// </summary>
        private static string SharepointSiteURL
        {
            get
            {
                return ConfigurationService.SharepointSiteUrl;
            }
        }

        /// <summary>
        /// Return an instance of the root SPWeb object
        /// </summary>
        private static SPWeb RootSPWeb
        {
            get
            {
                SPSite site = new SPSite(SharepointSiteURL);
                if (site == null)
                {
                    throw new Exception("Can not find Sharepoint Site Collection: " + SharepointSiteURL);
                }
                SPWeb web = site.OpenWeb("/");
                if (web == null)
                {
                    throw new Exception("Failed to access the Sharepoint Site : " + SharepointSiteURL);
                }
                return web;
            }
        }

        /// <summary>
        /// Function to return Locale information
        /// from the current SPContext
        /// </summary>
        /// <returns></returns>
        public static CultureInfo GetCurrentLocale()
        {
            using (SPSite currentSite = SPContext.Current.Site)
            {
                using (SPWeb currentWeb = currentSite.OpenWeb())
                {
                    return currentWeb.Locale;
                }
            }
        }

        #endregion

        #region SharePoint Access Utility functions

        /// <summary>
        /// This method adds additional custom columns to the OTB data table.
        /// </summary>
        /// <param name="table"></param>
        private static void EnhanceTableColumns(DataTable table)
        {
            //Unique Field: ID

            //6: Content Type - Publications
            //7: Content Type ID - 0x010100E05EA14628B34D1490E16BBD08E2AAEA00FA50B91079E821429F344128DFB12108
            //19: Encoded Absolute URL - http://tcdrswork3:9001/TCDRS%20Horizons%20NewsLetter/PlanAssessment100.pdf
            //21: File Size - 67435
            //22: File Type - pdf
            //66: URL Path - /TCDRS Horizons NewsLetter/PlanAssessment100.pdf
            if (table != null && table.Columns != null)
            {
                table.Columns.Add("Content Type", typeof(string));
                table.Columns.Add("Content Type ID", typeof(string));
                table.Columns.Add("Encoded Absolute URL", typeof(string));
                table.Columns.Add("URL Path", typeof(string));
                table.Columns.Add("File Size", typeof(string));
                table.Columns.Add("File Type", typeof(string));
                table.Columns.Add("BaseName", typeof(string));
            }
        }

        /// <summary>
        /// This method loads additional properties/data from a SPListItem into
        /// the data table
        /// </summary>
        /// <param name="items">The items to load into the datatable</param>
        /// <param name="table">The datatable to load</param>
        private static void LoadItems(SPListItemCollection items, DataTable table)
        {
            //Unique Field: ID
            //6: Content Type - Publications
            //7: Content Type ID - 0x010100E05EA14628B34D1490E16BBD08E2AAEA00FA50B91079E821429F344128DFB12108
            //19: Encoded Absolute URL - http://tcdrswork3:9001/TCDRS%20Horizons%20NewsLetter/PlanAssessment100.pdf
            //21: File Size - 67435
            //22: File Type - pdf
            //66: URL Path - /TCDRS Horizons NewsLetter/PlanAssessment100.pdf

            // verify that we have items available and the count matches
            if (items != null && table != null && table.Rows != null &&
               table.Rows.Count > 0) //&& items.Count == table.Rows.Count)
            {
                // First build a dictionary hash of all items by ID for quick lookup
                Dictionary<string, SPListItem> hash = new Dictionary<string, SPListItem>();
                foreach (SPListItem item in items)
                {
                    if (item.Fields.ContainsField("ID"))
                    {
                        hash.Add(item["ID"].ToString(), item);
                    }
                }

                // Now look on each data row and update its column properties
                string key = String.Empty;
                foreach (DataRow item in table.Rows)
                {
                    key = item["ID"].ToString();
                    item["Content Type"] = hash.ContainsKey(key) ? hash[key]["Content Type"].ToString() : "";
                    item["Content Type ID"] = hash.ContainsKey(key) ? hash[key]["Content Type ID"].ToString() : "";
                    item["Encoded Absolute URL"] = hash.ContainsKey(key) ? hash[key]["Encoded Absolute URL"].ToString() : "";
                    item["URL Path"] = hash.ContainsKey(key) ? hash[key]["URL Path"].ToString() : "";
                    item["File Size"] = hash.ContainsKey(key) ? hash[key]["File Size"].ToString() : "";
                    item["File Type"] = hash.ContainsKey(key) ? hash[key]["File Type"].ToString() : "";
                    item["BaseName"] = hash.ContainsKey(key) ? hash[key]["BaseName"].ToString() : "";
                }
            }
        }

        #endregion

        public static SPList GetList(string listUrl, bool asCurrentUser)
        {
            if (!asCurrentUser)
            {
                return GetList(listUrl);
            }
            SPList list = null;
            using (SPSite site = new SPSite(listUrl))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    try
                    {
                        // try with absolute url first
                        if (!listUrl.ToLower().StartsWith(web.Url.ToLower()))
                        {
                            if (!listUrl.StartsWith("/"))
                            {
                                listUrl = "/" + listUrl;
                            }
                            listUrl = web.Url + listUrl;
                        }
                        list = web.GetListFromUrl(listUrl);
                    }
                    catch
                    {
                        try
                        {
                            // try with relative url
                            if (listUrl.ToLower().StartsWith(web.Url.ToLower()))
                            {
                                listUrl = listUrl.Substring(web.Url.Length);
                                if (!listUrl.StartsWith("/"))
                                {
                                    listUrl = "/" + listUrl;
                                }
                            }
                            list = web.GetListFromUrl(listUrl);
                        }
                        catch
                        {
                            list = null;
                        }
                    }
                }
            }
            return list;
        }

        private static SPList GetList(string listUrl)
        {
            SPList list = null;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(listUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        try
                        {
                            // try with absolute url first
                            if (!listUrl.ToLower().StartsWith(web.Url.ToLower()))
                            {
                                if (!listUrl.StartsWith("/"))
                                {
                                    listUrl = "/" + listUrl;
                                }
                                listUrl = web.Url + listUrl;
                            }
                            list = web.GetListFromUrl(listUrl);
                        }
                        catch
                        {
                            try
                            {
                                // try with relative url
                                if (listUrl.ToLower().StartsWith(web.Url.ToLower()))
                                {
                                    listUrl = listUrl.Substring(web.Url.Length);
                                    if (!listUrl.StartsWith("/"))
                                    {
                                        listUrl = "/" + listUrl;
                                    }
                                }
                                list = web.GetListFromUrl(listUrl);
                            }
                            catch
                            {
                                list = null;
                            }
                        }
                    }
                }
            });
            return list;
        }

        public static DateTime GetDate(SPListItem item, string fieldStaticName)
        {
            DateTime result = DateTime.MinValue;
            try
            {
                SPField field = item.Fields.TryGetFieldByStaticName(fieldStaticName);
                if (field != null && field is SPFieldDateTime)
                {
                    SPFieldDateTime fieldDateTime = field as SPFieldDateTime;
                    result = (DateTime)fieldDateTime.GetFieldValue(item[field.Id].ToString());
                }
            }
            catch
            {
                result = DateTime.MinValue;
            }
            return result;
        }

        public static string GetUserDisplayName(SPListItem item, string fieldStaticName)
        {
            string result = null;
            try
            {
                SPField field = item.Fields.TryGetFieldByStaticName(fieldStaticName);
                if (field != null && field is SPFieldUser)
                {
                    SPFieldUser typedField = field as SPFieldUser;
                    SPFieldUserValue fieldValue = typedField.GetFieldValue(item[field.Id].ToString()) as SPFieldUserValue;
                    if (fieldValue.User != null)
                    {
                        result = fieldValue.User.Name;
                    }
                }
            }
            catch
            {
                result = null;
            }
            return result;
        }

        public static string GetText(SPListItem item, string fieldStaticName)
        {
            string result = null;
            try
            {
                SPField field = item.Fields.TryGetFieldByStaticName(fieldStaticName);
                if (field != null && field is SPFieldText)
                {
                    SPFieldText typedField = field as SPFieldText;
                    result = typedField.GetFieldValue(item[field.Id].ToString()).ToString();
                }
            }
            catch
            {
                result = null;
            }
            return result;
        }
/// <summary>
/// checks to see if a list exists
/// </summary>
/// <param name="web"></param>
/// <param name="listName"></param>
/// <returns></returns>
        public static bool ListExists(SPWeb web, string listName)
        {
            return web.Lists.Cast<SPList>().Any(list => string.Equals(list.Title, listName));
        }


    }
}
