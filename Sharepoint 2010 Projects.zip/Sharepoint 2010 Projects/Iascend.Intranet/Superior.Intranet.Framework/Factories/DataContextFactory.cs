﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace Iascend.Intranet.Framework.Factories
{
    public static class DataContextFactory
    {
        private static Dictionary<string, DataContextConnectionMapping> _connectionMappingSource = new Dictionary<string, DataContextConnectionMapping>();

        public static T GetDataContext<T>()
        {
            object dataContext = (object)default(T);

            if (typeof(T).BaseType == typeof(DataContext))
            {
                if (_connectionMappingSource.ContainsKey(typeof(T).ToString()))
                {
                    DataContextConnectionMapping connectionMapping = _connectionMappingSource[typeof(T).ToString()];

                    dataContext = Activator.CreateInstance(typeof(T),connectionMapping.ConnectionString, connectionMapping.MappingSource);
                }
                else
                {
                    dataContext = (object)Activator.CreateInstance<T>();
                    DataContextConnectionMapping connectionMapping = new DataContextConnectionMapping();
                    connectionMapping.ConnectionString = ((DataContext)dataContext).Connection.ConnectionString;
                    connectionMapping.MappingSource = ((DataContext)dataContext).Mapping.MappingSource;
                    _connectionMappingSource.Add(typeof(T).ToString(), connectionMapping);
                }
            }
            else
            {
                throw new ArgumentException("Type is not a DataContext");
            }
            return (T)dataContext;
        }

        private class DataContextConnectionMapping
        {
            public MappingSource MappingSource { get; set; }
            public string ConnectionString { get; set; }
        }
    }
}
