﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Server.Diagnostics;

namespace Iascend.Intranet.Framework.Logging
{
    public static class ULSLogHelper
    {
        public static void LogErrorMessage(string errMsg, string stackTrace) 
        {                        
            PortalLog.LogString("Iascend Custom Exception Occurred: {0} || {1}", errMsg, stackTrace);            
        }

        public static void LogDebugMessage(PortalLogLevel logLevel, string errMsg, string stackTrace) 
        {
            PortalLog.DebugLogString(PortalLogLevel.Verbose, "Iascend Custom Exception Occurred: {0} || {1}", errMsg, stackTrace);
        }      
    }
}
