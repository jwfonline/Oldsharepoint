﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Logging.ExtraInformation;

namespace Iascend.Intranet.Framework.Logging
{
    #region LoggingContextInfo class
   
    /// <summary>
    /// Logging Context Info
    /// </summary>
    public class LoggingContextInfo : ManagedSecurityContextInformationProvider
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dict"></param>
        public static void PopulateDictionary(ref IDictionary<string, object> dict)
        {
            ManagedSecurityContextInformationProvider mscip = new ManagedSecurityContextInformationProvider();
            mscip.PopulateDictionary(dict);
        }
    }

    #endregion
}
