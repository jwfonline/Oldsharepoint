﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using Microsoft.Practices.EnterpriseLibrary.Logging.ExtraInformation;
using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Enumerations;


namespace Iascend.Intranet.Framework.Logging
{
    /// <summary>
    /// LoggingHelper:
    /// A facade pattern access to Enterprise Library Logging using
    /// LoggingHelper.Log(...)
    /// </summary>
    public class LoggingHelper
    {

        #region private static fields
        private static Priority defaultPriority = Priority.Low;
        private static EventIds defaultEventId = EventIds.UnSpecified;
        private static TraceEventType defaultSeverity = TraceEventType.Information;
        private static int defaultTitleLength = 30;
        #endregion

        #region :: Log method(s) ::

        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// TraceEventType defaults to Informational
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="category">FxPortal.Common.EntLibFx.Logging.Category enum</param>
        /// <param name="priority">FxPortal.Common.EntLibFx.Logging.Priority enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        public static void Log(object message, Category category, Priority priority, EventIds eventId)
        {
            LoggingHelper.Log(message, category, priority, eventId, defaultSeverity);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// Priority defaults to Low
        /// EventId defaults to UnSpecified
        /// TraceEventType defaults to Informational
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="category">FxPortal.Common.EntLibFx.Logging.Category enum</param>        
        public static void Log(object message, Category category)
        {
            LoggingHelper.Log(message, category, defaultPriority, defaultEventId, defaultSeverity);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// Priority defaults to Low
        /// EventId defaults to UnSpecified
        /// TraceEventType defaults to Informational
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="category">FxPortal.Common.EntLibFx.Logging.Category enum</param>        
        public static void Log(object message, Category category, TraceEventType severity)
        {
            LoggingHelper.Log(message, category, defaultPriority, defaultEventId, severity);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// Priority defaults to Low
        /// TraceEventType defaults to Informational
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="category">FxPortal.Common.EntLibFx.Logging.Category enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        public static void Log(object message, Category category, EventIds eventId)
        {
            LoggingHelper.Log(message, category, defaultPriority, eventId, defaultSeverity);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="category">FxPortal.Common.EntLibFx.Logging.Category enum</param>
        /// <param name="priority">FxPortal.Common.EntLibFx.Logging.Priority enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        /// <param name="severity">System.Diagnostics.TraceEventType enum</param>
        public static void Log(object message, Category category, Priority priority, EventIds eventId, TraceEventType severity)
        {
            ICollection<Category> cat = new List<Category>();
            cat.Add(category);
            LoggingHelper.Log(message, cat, defaultPriority, eventId, defaultSeverity, null);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="categories">FxPortal.Common.EntLibFx.Logging.Category enum</param>
        /// <param name="priority">FxPortal.Common.EntLibFx.Logging.Priority enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        /// <param name="severity">System.Diagnostics.TraceEventType enum</param>
        public static void Log(object message, ICollection<Category> categories, Priority priority, EventIds eventId, TraceEventType severity)
        {
            LoggingHelper.Log(message, categories, priority, eventId, severity, null);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="categories">FxPortal.Common.EntLibFx.Logging.Category as a collection</param>
        /// <param name="priority">FxPortal.Common.EntLibFx.Logging.Priority enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        /// <param name="severity">System.Diagnostics.TraceEventType enum</param>
        /// <param name="classForProperties">Class to reflect for extended properties to be logged</param>
        public static void Log(object message, ICollection<Category> categories, Priority priority, EventIds eventId, TraceEventType severity, object classForProperties)
        {
            IDictionary<string, object> contextInfo = new Dictionary<string, object>();
            LoggingContextInfo.PopulateDictionary(ref contextInfo);

            // Reflects the object to properties.
            if (!(classForProperties == null))
            {
                try
                {
                    IEnumerable enumerable = (IEnumerable)classForProperties.GetType().GetInterface("IEnumerable");
                    if (!(enumerable == null))
                    {
                        IEnumerator enumr = ((IEnumerable)classForProperties).GetEnumerator();
                        while (enumr.MoveNext())
                        {
                            // ToDo: Work in progress
                        }
                    }
                    else
                    {
                        contextInfo = ReflectionHelper.GetDictionary(classForProperties);
                    }
                }
                catch { }
            }

            LoggingHelper.Log(message, categories, priority, eventId, severity, contextInfo);
        }
        /// <summary>
        /// Log:
        /// Write an entry to Logging.
        /// Uses: FxPortal.Common.EntLibFx.Logging enums for Category and Priority.
        /// </summary>
        /// <param name="message">Message to Log</param>
        /// <param name="categories">FxPortal.Common.EntLibFx.Logging.Category enum as a collection</param>
        /// <param name="priority">FxPortal.Common.EntLibFx.Logging.Priority enum</param>
        /// <param name="eventId">FxPortal.Common.EntLibFx.Logging.EventIds enum</param>
        /// <param name="severity">System.Diagnostics.TraceEventType enum</param>
        /// <param name="properties">extended properties to be logged</param>
        public static void Log(object message, ICollection<Category> categories, Priority priority, EventIds eventId, TraceEventType severity, IDictionary<string, object> properties)
        {
            ICollection<string> catStrings = new List<string>();
            foreach (Category item in categories)
                catStrings.Add(Enum.GetName(typeof(Category), item));

            LogEntry entry = new LogEntry(message, catStrings, Convert.ToInt32(priority), Convert.ToInt32(eventId), severity, message.ToString().Substring(0, Math.Min(defaultTitleLength, message.ToString().Length)), properties);
            Logger.Write(entry);
        }

        #endregion

        #region for testing (From Ent Lib testing)

        public static IList<Exception> LoggingTester()
        {
            IList<Exception> problems = new List<Exception>();
            // ----------------------------------------------------------------------
            // Query the logging enabled filter to determine if logging is enabled.
            // ----------------------------------------------------------------------
            if (!(Logger.GetFilter<LogEnabledFilter>().Enabled))
            {
                // Logging is not enabled. Events will not be logged. Your application can avoid the performance
                // penalty of collecting information for an event that will not be
                // loggeed.
                problems.Add(new Exception("Logging is not enabled."));
            }

            // ----------------------------------------------------------------------
            // Query the category filter to determine if the LogCategory enums pass the filter check.
            // ----------------------------------------------------------------------
            if (!(Logger.GetFilter<CategoryFilter>().ShouldLog(LoggingHelper.getCategoriesList())))
            {
                // Event will not be logged. You application can avoid the performance
                // penalty of collecting information for an event that will not be
                // loggeed.
                problems.Add(new Exception("The LogCategory enum contain categories that do not pass filter check."));
            }

            // ----------------------------------------------------------------------
            // Query the priority filter to determine if the LogPriority enums pass the filter check.
            // ----------------------------------------------------------------------
            foreach (int priority in Enum.GetValues(typeof(Priority)))
            {
                if (!(Logger.GetFilter<PriorityFilter>().ShouldLog(priority)))
                {

                    // Event will not be logged. You application can avoid the performance
                    // penalty of collection information for an even that will not be
                    // loggeed.
                    problems.Add(new Exception("The priority (" + priority.ToString() + ") does not pass the filter check."));
                }
            }
            return problems;
        }

        /// <summary>
        /// Helper method to construct an ICollecton list of categories in the LogCategory enum. 
        /// collection.
        /// </summary>
        /// <param name="categories">Collection of category names</param>
        /// <returns>ICollection&lt;string&gt;</returns>
        private static ICollection<string> getCategoriesList()
        {
            ICollection<string> categories = new List<string>();
            foreach (string category in Enum.GetNames(typeof(Category)))
            {
                categories.Add(category);
            }

            return categories;
        }

        #endregion
    }
}
