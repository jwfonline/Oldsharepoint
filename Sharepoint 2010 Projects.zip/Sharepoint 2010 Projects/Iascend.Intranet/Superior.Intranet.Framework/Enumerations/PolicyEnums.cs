﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Enumerations
{
    #region Policy Enums
    /// <summary>
    /// enum for established Enterprise Library Exception Handling Policy
    /// </summary>
    public enum ExpPolicy
    {
        /// <summary>
        /// Handle a Caching, Configuration, Instrumentation, Logging
        /// exception using Ent Lib ArchitecturalPolicy
        /// </summary>
        Architectural,

        /// <summary>
        /// Handle a DataAccess exception using Ent Lib DataAccessPolicy
        /// </summary>
        DataAccess,

        /// <summary>
        /// Handle a DataAccessCritical exception using Ent Lib DataAccessCriticalPolicy
        /// </summary>
        DataAccessCritical,

        /// <summary>
        /// Handle a ExternalInterface exception using Ent Lib ExternalInterfacePolicy
        /// </summary>
        ExternalInterface,

        /// <summary>
        /// Handle a General exception using Ent Lib GeneralPolicy
        /// </summary>
        General,

        /// <summary>
        /// Handle a Security exception using Ent Lib SecurityPolicy
        /// </summary>
        Security,

        /// <summary>
        /// Handle a UserInterface exception using Ent Lib UserInterfacePolicy
        /// </summary>
        UserInterface,

        /// <summary>
        /// Handle a Service exception using Ent Lib ServicePolicy
        /// </summary>
        Service
    }
    #endregion
}
