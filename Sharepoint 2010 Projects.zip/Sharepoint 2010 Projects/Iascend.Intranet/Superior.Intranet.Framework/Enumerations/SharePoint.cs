﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iascend.Intranet.Framework.Model.Attributes;

namespace Iascend.Intranet.Framework.Enumerations
{
    /// <summary>
    /// This enum contains all the supported SharePoint lists 
    /// </summary>
    public enum SharePointLists
    {
        [StringValue("Videos")]
        Videos,
        [StringValue("Headlines")]
        Headlines,
        [StringValue("Pages")]
        Articles,
        [StringValue("QuickLinks")]
        QuickLinks = 0,
        [StringValue("Configuration List")]
        ConfigurationList,
        [StringValue("Upcoming Events")]
        UpcomingEventsCalendar,
        [StringValue("In the News & Alerts")]
        InTheNews,
        [StringValue("Posts")]
        BlogPosts,
        [StringValue("Videos and Photos")]
        VideosAndPhotos,
        [StringValue("WhatsHot")]
        WhatsHot,
        [StringValue("Discussions")]
        Discussions,
        [StringValue("Comments")]
        Comments,
        [StringValue("TaskSummaries")]
        TaskSummaries,
        [StringValue("Project Status")]
        ProjectStatus,
        [StringValue("Files")]
        Files,
        [StringValue("Brand List")]
        BrandList,
        [StringValue("Logos")]
        Logos,
        [StringValue("Tickers")]
        Tickers,
        [StringValue("ReportCalendar")]
        ReportCalendar,
        [StringValue("News")]
        News,
        [StringValue("Announcements")]
        Announcements,
        [StringValue("EventsCalendar")]
        EventsCalendar,
        [StringValue("LeftNavigation")]
        LeftNavigation,
        [StringValue("Metadata")]
        Metadata
    };

    /// <summary>
    /// Enums used for learning center metadata fields
    /// </summary>
    public enum SharePointMetaDataFields
    {
        [StringValue("Wiki_x0020_Page_x0020_Categories")]
        WikiCategory = 0,
        [StringValue("Wiki_x0020_Page_x0020_Categories")]
        WikiCategory2,
    };

    ///// <summary>
    ///// This enum contains all the related page types 
    ///// </summary>
    public enum FolderName
    {
        [StringValue("DetailView")]
        Detail,
        [StringValue("LargeView")]
        Large,
        [StringValue("QuickView")]
        Quick,
        [StringValue("ThumbView")]
        Thumbnail,
    };

    /// <summary>
    /// The location on the landing page where a headline needs to display
    /// </summary>
    public enum PageLocation
    {
        [StringValue("Top")]
        Top = 0,
        [StringValue("Center")]
        Center,
        [StringValue("Center")]
        Bottom
    }

    /// <summary>
    /// This enum contains all the related content types created
    /// </summary>
    public enum DisplayType
    {
        [StringValue("Portrait")]
        Portrait = 0,
        [StringValue("Landscape")]
        Landscape
    };
}
