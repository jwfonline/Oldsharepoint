﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iascend.Intranet.Framework.Model.Attributes;

namespace Iascend.Intranet.Framework.Enumerations
{
    /// <summary>
    /// This enum contains all the supported CAML Filter Query Operations
    /// </summary>
    public enum IndividualQueryOperation
    {
        [StringValue("Eq")]
        Equal = 0,
        [StringValue("Gt")]
        GreaterThen = 1,
        [StringValue("Lt")]
        LessThen = 2,
        [StringValue("Geq")]
        GreaterOrEqual = 3,
        [StringValue("Leq")]
        LessThenOrEqual = 4,
        [StringValue("Neq")]
        NotEqual = 5,
        [StringValue("Contains")]
        Contains = 6,
        [StringValue("IsNull")]
        IsNull = 7,
        [StringValue("IsNotNull")]
        IsNotNull = 8,
        [StringValue("BeginsWith")]
        BeginsWith = 9,
        [StringValue("DateRangesOverlap")]
        DateRangeOverlap = 10
    };

    /// <summary>
    /// This is for aggregate Query Operations
    /// </summary>
    public enum AggregateQueryOperation
    {
        [StringValue("And")]
        And = 0,
        [StringValue("Or")]
        Or = 1
    };


    /// <summary>
    /// This is for available value types
    /// </summary>
    public enum FieldValueType
    {
        [StringValue("String")]
        String = 0,
        [StringValue("Number")]
        Number = 1,
        [StringValue("Currency")]
        Currency = 2,
        [StringValue("Boolean")]
        Boolean = 3,
        [StringValue("Choice")]
        Choice = 4,
        [StringValue("Lookup")]
        Lookup = 5,
        [StringValue("Text")]
        Text = 6,
        [StringValue("DateTime")]
        DateTime = 7,
        [StringValue("ModStat")]
        ModerationStatus
    };
}
