﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Iascend.Intranet.Framework.Model.Attributes;

namespace Iascend.Intranet.Framework.Enumerations
{
    /// <summary>
    /// This enum contains all the supported locales.
    /// </summary>
    public enum Locales
    {
        [StringValue("en-US")]
        English = 0,
        [StringValue("es-ES")]
        Spanish = 1
    };
}
