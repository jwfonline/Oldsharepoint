﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Enumerations
{
    #region LoggingEnums

    /// <summary>
    /// Defines the logging categories
    /// </summary>
    public enum Category
    {
        /// <summary>
        /// Messages and exceptions that require immediate action
        /// </summary>
        CriticalFailures,
        /// <summary>
        /// Messages and exceptions that require attention
        /// </summary>
        Exceptions,
        /// <summary>
        /// Messages logged for performance tracking
        /// </summary>
        Performance,
        /// <summary>
        /// Messages logged for tracing in Façade layers only
        /// </summary>
        Tracing,
        /// <summary>
        /// Messages logged for troubleshooting
        /// </summary>
        Troubleshooting
    }

    /// <summary>
    /// Defines the logging priority
    /// </summary>
    public enum Priority : int
    {
        /// <summary>
        /// Unkonwn priority
        /// </summary>
        Unknown,
        /// <summary>
        /// No priority specified
        /// 
        /// Note: this level coincides with the default
        /// value for the Microsoft Enterprise Library Logging
        /// Application Block default Priority value
        /// </summary>
        None = -1,
        /// <summary>
        /// Low priority, defines exceptions or messages that can be ignored 
        /// and have very minimal or no impact to system functionality
        /// 
        /// Note: this level coincides with the Trace priority value
        /// from the Microsoft Enterprise Library Logging Application 
        /// Block
        /// </summary>
        Low = 5,
        /// <summary>
        /// Medium priority, defines exceptions that are recoverable with low 
        /// business impact
        /// </summary>
        Medium = 6,
        /// <summary>
        /// High priority, defines exceptions that can be recovered from 
        /// or business cases requiring expedited notification
        /// </summary>
        High = 7,
        /// <summary>
        /// Critical priority, defines unrecoverable errors that require immediate 
        /// attention and/or action
        /// </summary>
        Critical = 8
    }

    /// <summary>
    /// The EventIds is utilized to define an orgin of the Logging.
    /// </summary>
    public enum EventIds
    {
        /// <summary>
        /// Logging orgin is Caching
        /// </summary>
        Caching = 100,
        /// <summary>
        /// Logging orgin is Configuration
        /// </summary>
        Configuration = 200,
        /// <summary>
        /// Logging orgin is DataAccess
        /// </summary>
        DataAccess = 300,
        /// <summary>
        /// Logging orgin is ExceptionManagement
        /// </summary>
        ExceptionManagement = 400,
        /// <summary>
        /// Logging orgin is Instrumentation
        /// </summary>
        Instrumentation = 500,
        /// <summary>
        /// Logging orgin is Utilities
        /// </summary>
        Utilities = 600,
        /// <summary>
        /// Logging orgin is InternalUI
        /// </summary>
        InternalWebUI = 700,
        /// <summary>
        /// Logging orgin is Unspecified
        /// </summary>
        UnSpecified = 800,
        /// <summary>
        /// Logging orgin is Services
        /// </summary>
        Service = 900
    }

    #endregion
}
