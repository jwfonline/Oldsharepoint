﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Iascend.Intranet.Framework.Model.Attributes;

namespace Iascend.Intranet.Framework.Enumerations
{
    /// <summary>
    /// This enum contains all Session objects
    /// </summary>
    public enum Sessions
    {
        [StringValue("SessionProductFilter")]
        ProductFilter = 0,
    };

    /// <summary>
    /// This enum contains all view state objects
    /// </summary>
    public enum ViewState
    {
        [StringValue("ViewStateGemstones")]
        Gemstones = 0,
        [StringValue("ViewStateMetals")]
        Metals,
        [StringValue("ViewStateCollection")]
        Collections,
    };

}
