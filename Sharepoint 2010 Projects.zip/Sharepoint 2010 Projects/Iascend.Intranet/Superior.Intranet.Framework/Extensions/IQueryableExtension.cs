﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class IQueryableExtension
    {
        public static IQueryable<T> In<T>(this IQueryable<T> source,
                            IQueryable<T> checkAgainst)
        {
            return from s in source
                   where checkAgainst.Contains(s)
                   select s;
        }

        public static IQueryable<T> NotIn<T>(this IQueryable<T> source,
                                          IQueryable<T> checkAgainst)
        {
            return from s in source
                   where !checkAgainst.Contains(s)
                   select s;
        }
    }
}
