﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Microsoft.SharePoint;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class DataExtension
    {
        #region DataTable and List Extension Methods

        /// <summary>
        /// This method takes an existing table and attempts to add additional columns 
        /// to its column collection
        /// </summary>
        /// <param name="dt">The current table object to modify</param>
        /// <param name="columns">The columns to add</param>
        public static void AddColumns(this DataTable dt, List<string> columns)
        {
            if (dt != null && columns != null && columns.Count > 0)
            {
                columns = columns.Distinct().ToList();
                // loop on all column names and add them if needed
                foreach (string column in columns)
                {
                    if (dt.Columns.Contains(column))
                    {
                        continue;
                    }
                    else
                    {
                        dt.Columns.Add(new DataColumn(column));
                    }
                }
            }
        }

        /// <summary>
        /// This method takes an existing list and attempts to clean up the list of filters
        /// to only contain valid column names for filtering
        /// </summary>
        /// <param name="list">The current list to validate</param>
        /// <param name="filters">The filters to verify/clean</param>
        public static void RemoveBadColumnNames(this SPList list, Dictionary<string, string> filters)
        {
            if (list != null && filters != null && filters.Count > 0)
            {
                foreach (string key in filters.Keys)
                {
                    if (filters.ContainsKey(key) && list.Fields.GetFieldByInternalName(key) == null)
                    {
                        filters.Remove(key);
                    }
                }
            }
        }


        /// <summary>
        /// This method takes an existing list and attempts to clean up the list of returned fields
        /// to only contain valid column names
        /// </summary>
        /// <param name="list">The current list to validate</param>
        /// <param name="returnedFields">The fields to verify/clean</param>
        public static void RemoveBadColumnNames(this SPList list, List<string> returnedFields)
        {
            if (list != null && returnedFields != null && returnedFields.Count > 0)
            {
                List<string> finalFields = new List<string>();
                foreach (string item in returnedFields)
                {
                    if (list.Fields.GetFieldByInternalName(item) != null)
                    {
                        finalFields.Add(item);
                    }
                }

                // after running the loop, clear out the original list and replace with valid entries
                returnedFields.Clear();
                returnedFields.AddRange(finalFields);
            }
        }

        /// <summary>
        /// This method takes a list of items and a list of fields to return.  It then populates a datatable
        /// with this information
        /// </summary>
        /// <param name="items">The items to return</param>
        /// <param name="returnedFields">The columns of data to return</param>
        public static void LoadSPItems(this DataTable dt, List<SPListItem> items, 
                                       List<string> returnedFields)
        {
            if (dt != null && items != null && items.Count > 0 &&
                returnedFields != null && returnedFields.Count > 0)
            {
                // loop on all items and add a new data table row for each
                foreach (SPListItem item in items)
                {
                    DataRow row = dt.NewRow();
                    // loop on all fields to return and populate the new row
                    foreach (string field in returnedFields)
                    {
                        row[field] = item[field].ToString();
                    }
                }
            }
        }


        /// <summary>
        /// Two columns ID' and 'Created' always come from the CAML query resultset. 
        /// This function deletes the two unwanted columns and sets the column names to their respective caption values
        /// </summary>
        /// <param name="dataTable"> Datatable to be changed</param>
        /// <returns>Changed datatable</returns>
        public static void ReassignColumns(this DataTable dt)
        {
            if (dt.Columns.Contains("ID"))
            {
                dt.Columns.Remove("ID");
            }
            else
            {
                // Do nothing
            }

            if (dt.Columns.Contains("Created"))
            {
                dt.Columns.Remove("Created");
            }
            else
            {
                // Do nothing
            }

            foreach (DataColumn dataColumn in dt.Columns)
            {
                dataColumn.ColumnName = dataColumn.Caption;
            }
        }

        #endregion
    }
}
