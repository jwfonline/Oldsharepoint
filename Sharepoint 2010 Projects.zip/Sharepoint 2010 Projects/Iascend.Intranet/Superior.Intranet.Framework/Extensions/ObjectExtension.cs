﻿using System.Collections.Generic;
using System.IO;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Principal;
using System.Text;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Serialization;
using System;

using Iascend.Intranet.Framework.Helpers;
using Iascend.Intranet.Framework.Model;
using Iascend.Intranet.Framework.Model.SharePoint;
using Iascend.Intranet.Framework.Services;
using Iascend.Intranet.Framework.Enumerations;
using Iascend.Intranet.EnumsAndConstants.Constants;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class ObjectExtension
    {
        #region Variables and Properties

        /// <summary>
        /// Object used for JSON conversion
        /// </summary>
        private static JavaScriptSerializer _JavaScriptSerializer = new JavaScriptSerializer();

        #endregion

        #region Public Extensions for all objects

        /// <summary>
        /// Gets an object's string representation, or null if the object is null
        /// </summary>
        /// <param name="value">Object to represent</param>
        /// <returns>Object's string representation if it is not null, null otherwise</returns>
        public static string GetStringRepresentationOrNull(this object value)
        {
            return value != null ? value.ToString() : null;
        }

        /// <summary>
        /// This method will copy the content of each property to the destination object.
        /// Both arguments should have the same type and cannot be null.  This is a shallow copy
        /// but works for objects that can't serialize
        /// </summary>
        /// <param name="Source">The source object</param>
        /// <param name="Destination">The destination object</param>
        public static void Clone(this Object Source, Object Destination)
        {
            // exceptions
            if (Source == null || Destination == null)
            {
                throw new ArgumentNullException("Source and Destination cannot be null");
            }

            if (Destination.GetType() != Source.GetType())
            {
                throw new ArgumentException("Type mismatch");
            }

            // copy each value over
            foreach (PropertyInfo pi in Source.GetType().GetProperties())
            {
                if (pi.CanRead && pi.CanWrite)
                {
                    pi.SetValue(Destination, pi.GetValue(Source, null), null);
                }
            }
        }

        /// <summary>
        /// This method performs a deep clone but the object must serialize to a binary 
        /// formatter.
        /// </summary>
        /// <typeparam name="T">The type to serialize/clone</typeparam>
        /// <param name="value">The object serialized</param>
        /// <returns>The object that has been cloned</returns>
        public static T Clone<T>(this object value)
        {
            T retval = default(T);
            if (value != null)
            {
                MemoryStream ms = new MemoryStream();
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, value);
                ms.Position = 0;
                object obj = bf.Deserialize(ms);
                ms.Close();
                retval = (T)obj;
            }
            return retval;
        }

        /// <summary>
        /// This method accepts a List of objects and a DataTable with key/values, then it attempts to generate 
        /// all the new objects needed
        /// </summary>
        /// <param name="original">The original/current object to load with data</param>
        /// <param name="values">The values to load into the object</param>
        public static bool Load<T>(this List<T> original, DataTable values)
        {
            bool success = true;
            try
            {
                // verify we have valid objects to work with
                if (original != null && values != null && values.Columns != null && values.Rows.Count > 0)
                {
                    // get the underlying object type in the list
                    Type objectType = typeof(T);

                    // Loop on each row in the data table and create a new item
                    foreach (DataRow dr in values.Rows)
                    {
                        // create new item
                        T newItem = (T)Activator.CreateInstance(objectType);
                        // loop on each column in the column collection
                        foreach (DataColumn column in values.Columns)
                        {
                            // Retrieve the property we want to set via the column name
                            PropertyInfo oProp = objectType.GetProperty(column.ColumnName);
                            object uValue = null;

                            // If we succeeded in getting a property try to update
                            if (oProp != null && dr[column.ColumnName] != null &&
                                ObjectHelper.ConvertToType(oProp.PropertyType, dr[column.ColumnName].ToString(), out uValue))
                            {
                                // set our object's property with the proper value
                                oProp.SetValue(newItem, uValue, null);
                            }
                        }
                        original.Add(newItem);
                    }
                }
            }
            catch (Exception ex)
            {
                string error = "Exception caught loading object:" + System.Environment.NewLine;
                error += "Exception: {1}" + System.Environment.NewLine + "ToString: {2}";
                Debug.WriteLine(String.Format(ex.Message, ex.ToString()));
                success = false;
            }
            return success;
        }

        /// <summary>
        /// This method accepts one object and a DataRow with A Column Collection, then it attempts to copy/load
        /// the data into the object
        /// </summary>
        /// <param name="original">The original/current object to load with data</param>
        /// <param name="columns">The columns to use as a property check/guide</param>
        /// <param name="values">The values to load into the object</param>
        public static bool Load(this object original, DataColumnCollection columns, DataRow values)
        {
            bool success = true;
            try
            {
                if (original != null && columns != null && columns.Count > 0 && values != null)
                {
                    Type objectType = original.GetType();
                    foreach (DataColumn column in columns)
                    {
                        // Retrieve the property from the original object
                        PropertyInfo oProp = objectType.GetProperty(column.ColumnName);
                        object uValue = null;

                        // If we succeeded in getting a property try to update
                        if (oProp != null && values[column.ColumnName] != null &&
                            ObjectHelper.ConvertToType(oProp.PropertyType, values[column.ColumnName].ToString(), out uValue))
                        {
                            oProp.SetValue(original, uValue, null);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string error = "Exception caught loading object:" + System.Environment.NewLine;
                error += "Exception: {1}" + System.Environment.NewLine + "ToString: {2}";
                Debug.WriteLine(String.Format(ex.Message, ex.ToString()));
                success = false;
            }
            return success;
        }

        /// <summary>
        /// This method accepts a List of objects and a DataTable with key/values, it also accepts a 
        /// locale object.  It then attempts to load the DTO with the correct locale information from
        /// the datable for each item.
        /// </summary>
        /// <param name="original">The original/current object to load with data</param>
        /// <param name="values">The values to load into the object</param>
        /// <param name="locale">The locale to se</param>
        public static bool Load<T>(this List<T> original, DataTable values, Locales locale)
        {
            bool success = true;
            try
            {
                string loc = (locale == Locales.Spanish) ?
                              locale.GetStringValue() : String.Empty;
                // verify we have valid objects to work with
                if (original != null && values != null && values.Columns != null
                    && values.Rows.Count > 0)
                {
                    // get the underlying object type in the list
                    Type objectType = typeof(T);
                    PropertyInfo[] properties = objectType.GetProperties();

                    // Loop on each row in the data table and create a new item
                    foreach (DataRow dr in values.Rows)
                    {
                        // create new item
                        T newItem = (T)Activator.CreateInstance(objectType);

                        // loop on each property in the object
                        foreach (PropertyInfo property in properties)
                        {
                            object uValue = null;

                            // If we succeeded in getting a property try to update
                            // also check for locale
                            if (dr[property.Name + loc] != null &&
                                ObjectHelper.ConvertToType(property.PropertyType,
                                                           dr[property.Name + loc].ToString(),
                                                           out uValue))
                            {
                                // set our object's property with the proper value
                                property.SetValue(newItem, uValue, null);
                            }
                            else
                            {
                                // if locale lookup failed, lets try a non-locale lookup
                                if (dr[property.Name] != null &&
                                    ObjectHelper.ConvertToType(property.PropertyType,
                                    dr[property.Name].ToString(),
                                    out uValue))
                                    {
                                        // set our object's property with the proper value
                                        property.SetValue(newItem, uValue, null);
                                    }
                            }
                        }
                        original.Add(newItem);
                    }
                }
            }
            catch (Exception ex)
            {
                string error = "Exception caught loading object:" + System.Environment.NewLine;
                error += "Exception: {1}" + System.Environment.NewLine + "ToString: {2}";
                Debug.WriteLine(String.Format(ex.Message, ex.ToString()));
                success = false;
            }
            return success;
        }

        /// <summary>
        /// Deserialize the xmlToDeserialize to an object of type T.
        /// </summary>
        /// <typeparam name="T">The type of the deserialized object.</typeparam>
        /// <param name="xmlToDeserialize">The XML to deserialize.</param>
        /// <returns>The object deserialized from the XML.</returns>
        public static T FromXml<T>(this string xmlToDeserialize)
        {
            //Deserialize the XML.
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            StringReader stringReader = new StringReader(xmlToDeserialize);
            XmlReader xmlReader = XmlReader.Create(stringReader);
            object deserializedObject = xmlSerializer.Deserialize(xmlReader);

            return (T)deserializedObject;
        }


        /// <summary>
        /// Serialize the objectToSerialize to XML.
        /// </summary>
        /// <param name="objectToSerialize">The object to serialize.</param>
        /// <returns>The object serialized as XML.</returns>
        public static string ToXML<T>(this T objectToSerialize)
        {
            //Specify the removal of the generated XML namespaces (which do not appear in the XML exchanged with the Flash front-end), i.e.:
            //  * xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            //  * xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            XmlSerializerNamespaces xmlnsEmpty = new XmlSerializerNamespaces();
            xmlnsEmpty.Add("", "");

            //Serialize the object.
            XmlSerializer xmlSerializer = new XmlSerializer(objectToSerialize.GetType());
            StringWriter stringWriter = new StringWriter();
            XmlWriter xmlWriter = XmlWriter.Create(stringWriter);
            xmlSerializer.Serialize(xmlWriter, objectToSerialize, xmlnsEmpty);
            String xmlString = stringWriter.ToString();

            //Clean the XML version declaration (to match the XML exchanged with the Flash front-end).
            xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "<?xml version=\"1.0\"?>");

            return xmlString;
        }


        static public IEnumerable<ElementWithContext<T>> WithContext<T>(this IEnumerable<T> source)
        {
            // initialize the previous and current item for the first source element
            T previous = default(T);
            T current = source.FirstOrDefault();
            int index = 0;

            // Loop all 'Next' items
            foreach (T next in source.Union(new[] { default(T) }).Skip(1))
            {
                yield return new ElementWithContext<T>(previous, current, next,
                        index, source.Take(index), source.Skip(index + 1));

                previous = current;
                current = next;
                index++;
            }
        }
        #endregion
    }
}
