﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Iascend.Intranet.Framework.Extensions
{
    /// <summary>
    /// Helper functions when working with the stream object
    /// </summary>
    public static class StreamExtension
    {
        /// <summary>
        /// Copies the content from one stream to another
        /// </summary>
        /// <param name="inputStream">Stream containing the source data</param>
        /// <param name="outputStream">Stream to which the source data is copied</param>
        public static void CopyStream(this Stream inputStream, Stream outputStream)
        {
            byte[] buffer = new byte[512];
            int read = inputStream.Read(buffer, 0, buffer.Length);
            while (read > 0)
            {
                outputStream.Write(buffer, 0, read);
                read = inputStream.Read(buffer, 0, buffer.Length);
            }
        }
    }
}
