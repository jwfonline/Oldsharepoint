﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    /// <summary>
    /// This class handles list extention methods
    /// </summary>
    public static class ListExtension
    {
        // added so that randomness actually occurs -Andy 5/16/2010
        // note: Random is not threadsafe
        private static Random _random = new Random(Environment.TickCount + 1);

        /// <summary>
        /// Perform a basic random shuffle of the list and returns the shuffled 
        /// list, leaving the original, untouched.
        /// </summary>
        /// <typeparam name="T">The type of data being randomized</typeparam>
        /// <param name="value">The list to randomize</param>
        /// <returns>Randomized list</returns>
        public static IList<T> Shuffle<T>(this IList<T> value)
        {
            if (value != null && value.Count > 0)
            {
                // create a new list and instantiate temporary variables
                List<T> randomList = new List<T>();
                List<T> valueCopy = new List<T>();
                valueCopy.AddRange(value);

                //Random r = new Random(Environment.TickCount - 1);
                int randomIndex = 0;

                // loop on all existing values
                while (valueCopy.Count > 0)
                {
                    //Choose a random object in the list
                    lock (_random)
                    {
                        randomIndex = _random.Next(0, valueCopy.Count);
                    }
                    //add it to the new, random list
                    randomList.Add(valueCopy[randomIndex]);
                    //remove to avoid duplicates
                    valueCopy.RemoveAt(randomIndex);
                }
                //return the new random list
                return randomList;
            }
            else
            {
                return value;
            }
        }

        public static T GetRandom<T>(this IList<T> value)
        {
            if (value != null && value.Count > 0)
            {
                //Random r = new Random(Environment.TickCount + 1);
                int randomIndex;
                lock (_random)
                {
                    randomIndex = _random.Next(0, value.Count);
                }

                return value[randomIndex];
            }
            else
            {
                return default(T);
            }
        }

        public static string Join(this IList<string> values, string separator)
        {
            if (values != null)
            {
                return string.Join(separator, values.ToArray());
            }
            else
            {
                return String.Empty;
            }
        }

        /// <summary>
        /// Accepts a List.  
        /// If value is null, the method converts null list to empty list.
        /// Otherwise, the accepted list is returned
        /// </summary>
        /// <param name="value">List to check.</param>
        /// <returns>An empty string if the string is null, the value otherwise.</returns>
        public static IList<T> ConvertNullToEmpty<T>(this IList<T> value)
        {
            if (value == null)
            {
                return new List<T>();
            }

            return value;
        }

        /// <summary>
        /// This method takes a list and attempts to create a 
        /// </summary>
        /// <typeparam name="T">The generic type of the original list</typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static List<string> GetEnumStringValue<T>(this IList<T> value)
        {
            List<string> retval = new List<string>();
            if (value != null && value.Count > 0)
            {
                retval = value.Where(s => s is Enum).Select(s => ((Enum)Convert.ChangeType(s, typeof(Enum))).GetStringValue()).ToList();
            }
            return retval;
        }

       
    }
}
