﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class GuidExtension
    {
        public static bool HasValue(this Guid value)
        {
            return (value != null && value != System.Guid.Empty);
        }
    }
}
