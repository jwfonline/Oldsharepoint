﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class StringExtension
    {
        /// <summary>
        /// Accepts a string.  
        /// If value is null, the method converts null string to empty string.
        /// Otherwise, the accepted string value is returned
        /// </summary>
        /// <param name="stringToCheck">String to check.</param>
        /// <returns>An empty string if the string is null, the value otherwise.</returns>
        public static string ConvertNullToEmpty(this string value)
        {
            if (value == null)
                return string.Empty;

            return value;
        }

        /// <summary>
        /// Determines whether a string is null or empty.
        /// </summary>
        /// <param name="stringToCheck">String to check.</param>
        /// <returns>True if the string is null or empty, false otherwise.</returns>
        public static bool IsNullOrEmpty(this string value)
        {
            return String.IsNullOrEmpty(value);
        }

        /// <summary>
        /// Determines whether a string and its trimmed representation is null or empty.
        /// </summary>
        /// <param name="stringToCheck">String to check.</param>
        /// <returns>True if the string or it trimmed representation is null or empty, false otherwise.</returns>
        public static bool IsNullEmptyOrEmptySpaces(this string value)
        {
            bool isNullOrEmpty;
            isNullOrEmpty = String.IsNullOrEmpty(value);

            if (!isNullOrEmpty)
            {
                isNullOrEmpty = (value.Trim() == string.Empty);
            }

            return isNullOrEmpty;
        }

        /// <summary>
        /// Returns a character string of the specified length from the beginning or less if the source string is less than the specified length
        /// </summary>
        /// <param name="value">The source string</param>
        /// <param name="length">The maximum length returned</param>
        /// <returns></returns>
        public static string Left(this string value, int length)
        {
            return value.Left(length, true);
        }

        /// <summary>
        /// Returns a character string of the specified length from the beginning or less if the source string is less than the specified length
        /// </summary>
        /// <param name="value">The source string</param>
        /// <param name="length">The maximum length returned</param>
        /// <param name="ignoreSpaces">Should leading or trailing spaces count towards length</param>
        /// <returns></returns>
        public static string Left(this string value, int length, bool ignoreSpaces)
        {
            if (value.IsNullOrEmpty())
            {
                return String.Empty;
            }

            if (ignoreSpaces)
            {
                value = value.Trim();
            }

            if (value.Length > length)
            {
                return value.Substring(0, length);
            }
            else
            {
                return value;
            }
        }

        /// <summary>
        /// Returns a character string of the specified length from the end or less if the source string is less than the specified length
        /// </summary>
        /// <param name="value">The source string</param>
        /// <param name="length">The maximum length returned</param>
        /// <returns></returns>
        public static string Right(this string value, int length)
        {
            return value.Right(length, true);
        }

        /// <summary>
        /// Returns a character string of the specified length from the end or less if the source string is less than the specified length
        /// </summary>
        /// <param name="value">The source string</param>
        /// <param name="length">The maximum length returned</param>
        /// <param name="ignoreSpaces">Should leading or trailing spaces count towards length</param>
        /// <returns></returns>
        public static string Right(this string value, int length, bool ignoreSpaces)
        {
            if (value.IsNullOrEmpty())
            {
                return String.Empty;
            }

            if (ignoreSpaces)
            {
                value = value.Trim();
            }
            
            if (value.Length > length)
            {
                return value.Substring(value.Length - length, length);
            }
            else
            {
                return value;
            }
        }

        /// <summary>
        /// Base64 decode a string of data
        /// </summary>
        /// <param name="data">The string data to decode</param>
        /// <returns>Decoded string</returns>
        public static string DecodeFromBase64(this string data)
        {
            data = Encoding.UTF8.GetString(Convert.FromBase64String(data));
            return data;

        }

        /// <summary>
        /// Base64 encode a string of data
        /// </summary>
        /// <param name="data">The string data to encode</param>
        /// <returns>Base64 encoded string</returns>
        public static string EncodeToBase64(this string data)
        {
            data = Convert.ToBase64String(Encoding.UTF8.GetBytes(data));
            return data;
        }

        /// <summary>
        /// Currency without dolar sign string
        /// </summary>
        /// <param name="data">The string data to remove dolar sign</param>
        /// <returns>string without dolar sign</returns>
        public static string CurrencyStringWithoutDollarSign(this string data)
        {
            if (data.StartsWith("$"))
                return data.Substring(1);
            else
                return data;
        }

        /// <summary>
        /// Add a dollar sign to a string if it doesn't start with one
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string AddDollarSign(this string data)
        {
            if (data.StartsWith("$"))
                return data;
            else
                return "$" + data;
        }

        /// <summary>
        /// Takes in a string and attempts to format it into a clean dash spaced phone number
        /// </summary>
        /// <param name="data">The data to convert</param>
        /// <returns>A converted phone number string</returns>
        public static string ToPhoneNumber(this string data)
        {
            if (!data.IsNullEmptyOrEmptySpaces())
            {
                string strippedData = data.Replace(" ", "").Replace("-", "").Replace("(", "").Replace(")", "").Replace("+", "").Replace(".", "");
                string countryCode = string.Empty;
                string areaCode = string.Empty;
                string prefix = string.Empty;
                string lineNumber = string.Empty;
                string extraData = string.Empty;
                System.Text.StringBuilder phoneNumber = new System.Text.StringBuilder();

                char[] charArray = strippedData.ToCharArray();
                int numericLength = 0;
                foreach (char c in charArray)
                {
                    if (Char.IsNumber(c))
                    {
                        numericLength++;
                    }
                    else
                    {
                        break;
                    }
                }

                string numberData = strippedData.Left(numericLength);
                extraData = strippedData.Right(strippedData.Length - numericLength);

                // area code provided
                if (numberData.Length > 10)
                {
                    countryCode = numberData.Substring(0, 1);
                    areaCode = numberData.Substring(1, 3);
                    prefix = numberData.Substring(4, 3);
                    lineNumber = numberData.Substring(7, 4);
                }
                if (numberData.Length == 10)
                {
                    areaCode = numberData.Substring(0, 3);
                    prefix = numberData.Substring(3, 3);
                    lineNumber = numberData.Substring(6, 4);
                }
                else if (numberData.Length >= 7)
                {
                    areaCode = numberData.Substring(3, 3);
                    prefix = numberData.Substring(3, 3);
                    lineNumber = numberData.Substring(6, 4);
                }
                else // no area code provided
                {
                    lineNumber = numberData;
                }

                if (areaCode == "800")
                {
                    if (!countryCode.IsNullEmptyOrEmptySpaces())
                    {
                        phoneNumber.Append(countryCode);
                        phoneNumber.Append("-");
                    }
                    if (!areaCode.IsNullEmptyOrEmptySpaces())
                    {
                        phoneNumber.Append(areaCode);
                        phoneNumber.Append("-");
                    }
                    phoneNumber.Append(prefix);
                    phoneNumber.Append("-");
                    phoneNumber.Append(lineNumber);
                    phoneNumber.Append(" ");
                    phoneNumber.Append(extraData);
                }
                else
                {
                    if (!countryCode.IsNullEmptyOrEmptySpaces())
                    {
                        phoneNumber.Append(countryCode);
                        phoneNumber.Append(" ");
                    }
                    if (!areaCode.IsNullEmptyOrEmptySpaces())
                    {
                        phoneNumber.Append("(");
                        phoneNumber.Append(areaCode);
                        phoneNumber.Append(") ");
                    }
                    phoneNumber.Append(prefix);
                    phoneNumber.Append("-");
                    phoneNumber.Append(lineNumber);
                    phoneNumber.Append(" ");
                    phoneNumber.Append(extraData);
                }

                return phoneNumber.ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// method to strip HTML tags using Regular Expressions
        /// </summary>
        /// <param name="str">String to strip HTML from</param>
        /// <returns></returns>
        public static string StripHTML(this string source)
        {
            if (String.IsNullOrEmpty(source))
                return String.Empty;

            char[] array = new char[source.Length];
            int arrayIndex = 0;
            bool inside = false;

            for (int i = 0; i < source.Length; i++)
            {
                char let = source[i];

                if (let == '<')
                {
                    inside = true;
                    continue;
                }

                if (let == '>')
                {
                    inside = false;
                    continue;
                }

                if (!inside)
                {
                    array[arrayIndex] = let;
                    arrayIndex++;
                }
            }

            return new string(array, 0, arrayIndex);
        }

        /// <summary>
        /// This method takes a string and attempts to do a share point split on the
        /// ;#.  Retain all the elements that aren't an ID.
        /// </summary>
        /// <param name="data">The data to perform this operation on</param>
        /// <param name="removeIDs">Flag to remove or keep id's</param> 
        /// <returns>List of string values</returns>
        public static List<string> SharePointPoundCommaToList(this string data, bool removeIDs)
        {
            List<string> items = new List<string>();

            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                // populate terms
                //"11;#county;#10;#court"
                items = Regex.Split(data, ";#").ToList();
                // filter out number/id data from the final list
                if (removeIDs)
                {
                    // to be safe, add a range even if null to an empty list so other logic doesn't fail 
                    // at the web levels.
                    items = items.Where(c => !char.IsDigit(c[0])).ToList();
                }
            }
            return items;
        }

        /// <summary>
        /// This method takes a string and attempts to do a share point split on the
        /// ;#.
        /// </summary>
        /// <param name="data">The data to perform this operation on</param>
        /// <param name="removeIDs">Flag to remove or keep id's</param> 
        /// <returns>List of string values</returns>
        public static Dictionary<int, string> SharePointCommaPoundToDictionary(this string data)
        {
            Dictionary<int, string> items = new Dictionary<int, string>();

            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                int x = 0;
                string[] splitValues = Regex.Split(data, ";#");

                // populate terms
                //"11;#county;#10;#court"
                if(splitValues != null && splitValues.Length > 0)
                {
                    while (x < splitValues.Length)
                    {
                        items.Add(Convert.ToInt32(splitValues[x]), splitValues[x + 1]);
                        x = x + 2;                    
                    }
                }
            }
                
            return items;
        }

        /// <summary>
        /// This method returns the first key in a dictionary of int keys
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static int? FirstKey(this Dictionary<int, string> data)
        {
            int? retval = null;
            if (data != null && data.Count > 0)
            {
                retval = data.FirstOrDefault().Key;
            }
            return retval;
        }

        /// <summary>
        /// This method takes in a Share Point hyperlink, and keeps only the url
        /// </summary>
        /// <param name="data">The data to clean</param>
        /// <returns>A cleaned sharepoint URL</returns>
        public static string ParseSPHyperlink(this string data)
        {
            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                return data.Split(',')[0].Trim();
            }
            return data;
        }

        /// <summary>
        /// This method takes in a Share Point hyperlink, and keeps only the url
        /// </summary>
        /// <param name="data">The data to clean</param>
        /// <returns>A cleaned sharepoint URL</returns>
        public static List<string> ParseSPHyperlinkList(this string data)
        {
            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                return data.Split(',').ToList();
            }
            return new List<string>(){data};
        }

        public static string ParseSPSingleSPLookField(this string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return string.Empty;
            }

            string[] lookupValues = data.Split(new string[] { ";#" }, StringSplitOptions.None);
            if (lookupValues.Length > 1)
            {
                return lookupValues[1];
            }
            else if (lookupValues.Length > 0)
            {
                return lookupValues[0];
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// This method returns a single group from a regex expression
        /// </summary>
        /// <param name="data">The data to run a regex on</param>
        /// <param name="expression">The regex expression to run</param>
        /// <returns>The group of data to return</returns>
        public static string RegexCapture(this string data, string expression)
        {
            Regex regex = new Regex(expression);
            Match match = regex.Match(data);

            if (match.Groups != null && match.Groups.Count > 1)
            {
                return match.Groups[1].Value;
            }
            return String.Empty;
        }

        /// <summary>
        /// This method takes in a Share Point Manage Metadata field, and returns the collection of the Manged Terms
        /// </summary>
        /// <param name="data">The data to clean</param>
        /// <returns>A collection of managed terms</returns>
        public static List<string> ParseSPMetadataCollection(this string data)
        {
            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                return data.Split(';').ToList();
            }
            return new List<string>() { data };
        }

        /// <summary>
        /// This method takes in a Share Point Manage Metadata single item value, and returns the ID and Name of the Term
        /// </summary>
        /// <param name="data">The data to clean</param>
        /// <returns>A single managed term</returns>
        public static List<string> ParseSPMetadataItem(this string data)
        {
            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                return data.Split('|').ToList();
            }
            return new List<string>() { data };
        }

        public static string SharePointMetaDataFirst(this string data)
        {
            List<string> items = new List<string>();

            if (!data.ConvertNullToEmpty().IsNullEmptyOrEmptySpaces())
            {
                items = data.Split(';').ToList();
                items = items.Select(c => c.Split('|')[0]).ToList();
            }

            if (items.Count > 0) return items.First();

            return "";
        }
    }
}
