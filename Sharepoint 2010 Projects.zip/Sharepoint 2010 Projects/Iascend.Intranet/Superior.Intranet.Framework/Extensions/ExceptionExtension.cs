﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class ExceptionExtension
    {
        public static string Unroll(this Exception ex)
        {
            string exStr = ex.Message + "\n" + ex.StackTrace;

            if (ex.InnerException != null)
            {
                exStr += "\n" + ex.InnerException.Unroll();
            }

            return exStr;
        }
    }
}
