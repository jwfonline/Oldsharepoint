﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class DoubleExtension
    {
        public static string GetCurrencyWithoutCents(this double data)
        {
            return data.ToString("C0");
        }
    }

    public static class NullableDoubleExtension
    {
        public static double ValueOrZero(this double? value)
        {
            if (value.HasValue)
            {
                return value.Value;
            }
            else
            {
                return 0.00;
            }
        }
    }
}
