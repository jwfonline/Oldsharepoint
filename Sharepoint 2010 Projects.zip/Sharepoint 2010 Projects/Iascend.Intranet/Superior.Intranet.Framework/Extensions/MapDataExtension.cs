﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Diagnostics;

using Microsoft.SharePoint;

using Iascend.Intranet.Framework.Logging;
using Iascend.Intranet.Framework.Enumerations;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class MapDataExtension
    {
        #region Unique Conversion Methods

        /// <summary>
        /// This method takes a data row, a field name
        /// </summary>
        /// <typeparam name="T">The type returned</typeparam>
        /// <param name="dr">This data row to look into</param>
        /// <param name="fieldName">The column/field name to look up</param>
        /// <returns>The converted data type</returns>
        public static T Lookup<T>(this DataRow dr, string fieldName)
        {
            fieldName = fieldName.Trim();
            //string dataType = (dr != null && dr.Table != null && dr.Table.Columns != null && dr.Table.Columns.Contains(fieldName)) ? 
            //                   dr.Table.Columns[fieldName].DataType.ToString() : "Column is Null";
            //string temp = string.Format("{0}, {1}, {2}", fieldName, typeof(T).ToString(), 
            //                dr.Table.Columns[fieldName].DataType.ToString());

            try
            {
                // validate input parameters
                if (dr != null && !fieldName.IsNullEmptyOrEmptySpaces() && dr.Table.Columns.Contains(fieldName))
                {
                    // check for null
                    if (!dr.IsNull(fieldName))
                    {
                        return dr.Field<T>(fieldName);
                    }
                }
            }
            catch (Exception ex)
            {
                //temp += System.Environment.NewLine + ex.Unroll();
                System.Diagnostics.Debug.Write(ex.ToString());
            }
            // return null or some basic primitive value type
            return default(T);
        }
        #endregion
    }
}
