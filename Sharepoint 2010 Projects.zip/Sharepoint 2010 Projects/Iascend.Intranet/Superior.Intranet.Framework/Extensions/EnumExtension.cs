﻿using System;
using System.Reflection;
using Iascend.Intranet.Framework.Model.Attributes;
using Iascend.Intranet.Framework.Logging;
using System.Diagnostics;
using Iascend.Intranet.Framework.Enumerations;


namespace Iascend.Intranet.Framework.Extensions
{
    public static class EnumExtension
    {
        /// <summary>
        /// This method returns the string value attribute of an enum
        /// </summary>
        /// <param name="value">The enum to verify</param>
        /// <returns>The string value of the enum</returns>
        public static string GetStringValue(this Enum value)
        {
            // Get the type
            Type type = value.GetType();
            // Get fieldinfo for this type
            FieldInfo fi = type.GetField(value.ToString());
            // Get the stringvalue attributes
            StringValueAttribute[] attribs = new StringValueAttribute[0];

            if (fi != null && fi.IsDefined(typeof(StringValueAttribute), true))
            {
                attribs = fi.GetCustomAttributes(typeof(StringValueAttribute), false) as StringValueAttribute[];
            }
            // Return the first if there was a match.
            return attribs.Length > 0 ? attribs[0].StringValue : value.ToString();
        }

        /// <summary>
        /// This method returns the object value of the attribute painted on an enum
        /// </summary>
        /// <typeparam name="T">The type of object to return</typeparam>
        /// <param name="value">The enum to verify</param>
        /// <returns>The return object</returns>
        public static object GetObjectValue<T>(this Enum value)
        {
            // Get the type
            Type type = value.GetType();

            // Get fieldinfo for this type
            FieldInfo fieldInfo = type.GetField(value.ToString());

            // Get the stringvalue attributes
            ObjectValueAttribute[] attribs = fieldInfo.GetCustomAttributes(typeof(ObjectValueAttribute), false) as ObjectValueAttribute[];

            if(attribs.Length > 0)
            {
                ObjectValueAttribute objectValue = attribs[0];
                if(objectValue.ObjectType == typeof(T))
                {
                    return (T)objectValue.ObjectValue;
                }
            }

            return null;
        }

        /// <summary>
        /// This method figures out the correct sort order of the enum
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static object GetSortOrder<T>(this Enum value)
        {
            // Get the type
            Type type = value.GetType();

            // Get fieldinfo for this type
            FieldInfo fieldInfo = type.GetField(value.ToString());

            // Get the stringvalue attributes
            SortOrderAttribute[] attribs = fieldInfo.GetCustomAttributes(typeof(SortOrderAttribute), false) as SortOrderAttribute[];

            if (attribs.Length > 0)
            {
                SortOrderAttribute objectValue = attribs[0];
                if (objectValue.SortOrderType == typeof(T))
                {
                    return (T)objectValue.SortOrder;
                }
            }

            return null;
        }

        /// <summary>
        /// This method attempts to convert a string value into an Enum value
        /// </summary>
        /// <typeparam name="T">The enum to convert to</typeparam>
        /// <param name="value">The value to convert</param>
        /// <returns>Converted enum or its default value</returns>
        public static T CastToEnum<T>(this string value)
        {
            return value.CastToEnum<T>(false);
        }

        /// <summary>
        /// This method attempts to convert a string value into an Enum value
        /// </summary>
        /// <typeparam name="T">The enum to convert to</typeparam>
        /// <param name="value">The value to convert</param>
        /// <param name="containsCheck">Flag to perform a contains check</param>
        /// <returns>Converted enum or its default value</returns>
        public static T CastToEnum<T>(this string value, bool containsCheck)
        {
            string errorMsg = String.Format("Failed Convert Value: {0} to Enum: {1}",
                                            value, typeof(T).ToString());
            T retval = default(T);

            // to be safe, lets check against both the string value and the actual value of the enum
            // to verify a match.  Just trying to parse won't always guarantee success
            if (!value.IsNullEmptyOrEmptySpaces() && retval is Enum)
            {
                try
                {
                    // get the type of enum
                    Type enumType = typeof(T);
                    // cast to lower
                    value = value.ToLower();
                    // loop on all possible values in the enum
                    foreach (T item in Enum.GetValues(enumType))
                    {
                        // convert from a generic enum to a the object Enum
                        Enum temp = (Enum)Enum.Parse(enumType, item.ToString());
                        string enumName = temp.ToString().ToLower();
                        string enumStringvalue = temp.GetStringValue().ToLower();

                        // now perform a check against the name and the display name
                        if (enumName == value || enumStringvalue == value)
                        {
                            retval = item;
                            break;
                        }

                        // perform a contains check.
                        // See if the value passed in, is contained in
                        if (containsCheck && 
                            (enumName.Contains(value) || enumStringvalue.Contains(value)))
                        {
                            retval = item;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Write(ex.ToString());
                }
            }

            return retval;
        }

        /// <summary>
        /// This method accepts a string value and checks if a provided value exists in an enum
        /// </summary>
        /// <typeparam name="T">The enum type to check</typeparam>
        /// <param name="value">The value to check against all enum properties</param>
        /// <returns>True if it exsits</returns>
        public static bool ExistsInEnum<T>(this string value)
        {
            return value.ExistsInEnum<T>(false);
        }

        /// <summary>
        /// This method accepts a string value and checks if a provided value exists in an enum
        /// </summary>
        /// <typeparam name="T">The enum type to check</typeparam>
        /// <param name="value">The value to check against all enum properties</param>
        /// <param name="containsCheck">Flag to perform a contains check</param>
        /// <returns>True if it exsits</returns>
        public static bool ExistsInEnum<T>(this string value, bool containsCheck)
        {
            bool retval = false;
            T dummy = default(T);

            // to be safe, lets check against both the string value and the actual value of the enum
            // to verify a match.  Just trying to parse won't always guarantee success
            if (!value.IsNullEmptyOrEmptySpaces() && dummy is Enum)
            {
                try
                {
                    // get the type of enum
                    Type enumType = typeof(T);
                    // cast to lower
                    value = value.ToLower();
                    // loop on all possible values in the enum
                    foreach (T item in Enum.GetValues(enumType))
                    {
                        // convert from a generic enum to a the object Enum
                        Enum temp = (Enum)Enum.Parse(enumType, item.ToString());
                        string enumName = temp.ToString().ToLower();
                        string enumStringvalue = temp.GetStringValue().ToLower();

                        // now perform a check against the name and the display name
                        if (enumName == value || enumStringvalue == value)
                        {
                            retval = true;
                            break;
                        }

                        // perform a contains check.
                        // See if the value passed in, is contained in
                        if (containsCheck &&
                            (enumName.Contains(value) || enumStringvalue.Contains(value)))
                        {
                            retval = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Write(ex.ToString());
                }
            }

            return retval;
        }

    }
}
