﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class IMethodInvocationExtensionClass
    {
        public static string GetMethodSignature(this IMethodInvocation value)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append(value.MethodBase.DeclaringType.Name)
                    .Append('.')
                    .Append(value.MethodBase.Name)
                    .Append('(');

                string separator = ", ";
                for (int i = 0; i < value.Arguments.Count; i++)
                {
                    if (i == value.Arguments.Count - 1)
                    {
                        separator = string.Empty;
                    }

                    if (value.Arguments[i] != null)
                    {
                        sb.AppendFormat("'{0}'", value.Arguments[i])
                            .Append(separator);
                    }
                }
                sb.Append(')');
            }
            catch
            {
                sb.Append(" *** EXCEPTION GETTING METHOD SIGNATURE ****");
            }

            return sb.ToString();
        }

        public static string GetMethodName(this IMethodInvocation value)
        {
            return value.MethodBase.DeclaringType.Name + "." + value.MethodBase.Name;
        }
    }
}
