﻿using System;
using Iascend.Intranet.Framework.Services;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class DatetimeExtension
    {
        public static string ToMonthYearString(this DateTime datetime)
        {
            return datetime.ToString(ConfigurationService.MonthYearPattern);
        }

        public static string ToMonthYearString(this DateTime? datetime)
        {
            if(datetime == null)
            {
                return string.Empty;
            }

            return datetime.Value.ToMonthYearString();
        }

        public static DateTime? DateTimeOrNull(this DateTime datetime)
        {
            return datetime == default(DateTime) ? (DateTime?)null : datetime;
        }
    }
}