﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Framework.Extensions
{
    public static class IEnumerableExtension
    {
        public static T NextRandom<T>(this IEnumerable<T> source)
        {

            Random gen = new Random((int)DateTime.Now.Ticks);

            return source.Skip(gen.Next(0, source.Count() - 1) - 1).Take(1).ToArray()[0];

        }

        public static IEnumerable<T> Randomized<T>(this IEnumerable<T> source)
        {

            List<T> Remaining = new List<T>(source);

            while (Remaining.Count >= 1)
            {

                T temp = NextRandom<T>(Remaining);

                Remaining.Remove(temp);

                yield return temp;

            }

        }

 
    }
}
