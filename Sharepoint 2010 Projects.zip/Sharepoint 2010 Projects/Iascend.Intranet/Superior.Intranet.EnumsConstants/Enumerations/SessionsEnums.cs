﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Enumerations
{
    /// <summary>
    /// This enum contains all Session objects
    /// </summary>
    public enum Sessions
    {
        [StringValue("SessionProductFilter")]
        ProductFilter = 0,
    };

    /// <summary>
    /// This enum contains all view state objects
    /// </summary>
    public enum ViewState
    {
        [StringValue("ViewStateGemstones")]
        Gemstones = 0,
        [StringValue("ViewStateMetals")]
        Metals,
        [StringValue("ViewStateCollection")]
        Collections,
    };

}
