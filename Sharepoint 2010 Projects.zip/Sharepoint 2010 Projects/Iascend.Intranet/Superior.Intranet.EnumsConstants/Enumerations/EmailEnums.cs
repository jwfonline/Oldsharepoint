﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Enums.Enumerations
{
    /// <summary>
    /// Enumerated options for Sending Email
    /// </summary>
    [FlagsAttribute]
    public enum EmailOptions
    {
        None = 0,
        SendAsHTML = 1,
        DisplayNoReply = 2
    }
}
