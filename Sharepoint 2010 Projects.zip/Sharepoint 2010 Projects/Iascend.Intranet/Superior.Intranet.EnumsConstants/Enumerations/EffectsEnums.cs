﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Enumerations
{
    /// <summary>
    /// Effects used for the announcements web part item transitions
    /// </summary>
    public enum TransitionEffectsEnums
    {
        [StringValue("none")]
        Static,
        [StringValue("fade")]
        HorizontalFade,
        [StringValue("vert.random.fade")]
        RandomFade,
        [StringValue("vert.tl")]
        TopLeft,
        [StringValue("vert.tr")]
        TopRight,
        [StringValue("vert.bl")]
        BottomLeft,
        [StringValue("vert.br")]
        BottomRight,
        [StringValue("fade.left")]
        LeftFade,
        [StringValue("fade.right")]
        RightFade,
        [StringValue("alt.left")]
        LeftAlternating,
        [StringValue("alt.right")]
        RightAlternating,
        [StringValue("blinds.left")]
        LeftBlinds,
        [StringValue("blinds.right")]
        RightBlinds,
        [StringValue("diag.fade")]
        DiagonalFade,
        [StringValue("diag.exp")]
        DiagonalExpand,
        [StringValue("rev.diag.fade")]
        ReverseDiagonalFade,
        [StringValue("rev.diag.exp")]
        ReverseDiagonalExpand
    };

    /// <summary>
    /// Effects used for the announcements web part item transitions
    /// </summary>
    public enum TextBoxEffectsEnums
    {
        [StringValue("none")]
        None,
        [StringValue("fade")]
        Fade,
        [StringValue("down")]
        Down,
        [StringValue("right")]
        Right
    };
}
