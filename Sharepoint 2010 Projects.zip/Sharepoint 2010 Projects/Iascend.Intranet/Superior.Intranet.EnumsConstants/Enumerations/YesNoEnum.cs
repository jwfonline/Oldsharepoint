﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.Enums.Enumerations
{
    /// <summary>
    /// Enumerated options for Yes or No
    /// </summary>
    [FlagsAttribute]
    public enum YesNoEnum
    {
        Yes = 1,
        No = 0
    }
}
