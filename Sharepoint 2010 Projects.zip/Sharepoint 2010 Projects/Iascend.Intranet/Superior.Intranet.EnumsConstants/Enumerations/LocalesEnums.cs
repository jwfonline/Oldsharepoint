﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Enumerations
{
    /// <summary>
    /// This enum contains all the supported locales.
    /// </summary>
    public enum Locales
    {
        [StringValue("en-US")]
        English = 0,
        [StringValue("es-ES")]
        Spanish = 1
    };
}
