﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Enumerations
{
    public enum FilterType
    {
        EqualityCheck = 0,
        ContainsCheck = 1
    }
}
