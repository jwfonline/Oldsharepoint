﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Enumerations
{
    /// <summary>
    /// This enum contains all the supported SharePoint lists 
    /// </summary>
    public enum SharePointLists
    {
        [StringValue("Videos")]
        Videos,
        [StringValue("Headlines")]
        Headlines,
        [StringValue("Pages")]
        Articles,
        [StringValue("Announcements")]
        Announcements,
        [StringValue("EventsCalendar")]
        EventsCalendar,
        [StringValue("ReportCalendar")]
        ReportCalendar,
        [StringValue("Employee Spotlights")]
        EmployeeSpotlights,
        [StringValue("Quicklinks")]
        Quicklinks,
        [StringValue("ApplicationLinks")]
        ApplicationLinks,
        [StringValue("News")]
        News,
        [StringValue("PerformanceTab")]
        PerformanceTab,
        [StringValue("RevenueTab")]
        RevenueTab,
        [StringValue("CostTab")]
        CostTab,
        [StringValue("CustomerTab")]
        CustomerTab,
        [StringValue("Indexes")]
        IndexesTab,
        [StringValue("FooBar")]
        FooBar,
        [StringValue("VideoMessages")]
        VideoMessages,
        [StringValue("VideoPreviewImages")]
        VideoPreviewImages,
        [StringValue("Tickers")]
        Tickers,
        [StringValue("WelcomeMessage")]
        WelcomeMessage,
        [StringValue("MariosContactInformation")]
        MariosContactInformation,
        [StringValue("MariosBooks")]
        MariosBooks,
        [StringValue("PictureOfTheWeek")]
        PictureOfTheWeek,
        [StringValue("Discussions")]
        Discussions,
        [StringValue("HowAreWeDoingMetrics")]
        HowAreWeDoingMetrics,
        [StringValue("LeftNavigation")]
        LeftNavigation,
        [StringValue("ProjectStatus")]
        ProjectStatus,
        [StringValue("TabFootnotes")]
        TabFootnotes
    };

    /// <summary>
    /// Enums used for learning center metadata fields
    /// </summary>
    public enum SharePointMetaDataFields
    {
        [StringValue("Wiki_x0020_Page_x0020_Categories")]
        WikiCategory = 0,
        [StringValue("Wiki_x0020_Page_x0020_Categories")]
        WikiCategory2,
    };

    ///// <summary>
    ///// This enum contains all the related page types 
    ///// </summary>
    public enum FolderName
    {
        [StringValue("DetailView")]
        Detail,
        [StringValue("LargeView")]
        Large,
        [StringValue("QuickView")]
        Quick,
        [StringValue("ThumbView")]
        Thumbnail,
    };

    /// <summary>
    /// The location on the landing page where a headline needs to display
    /// </summary>
    public enum PageLocation
    {
        [StringValue("Top")]
        Top = 0,
        [StringValue("Center")]
        Center,
        [StringValue("Center")]
        Bottom
    }

    /// <summary>
    /// This enum contains all the related content types created
    /// </summary>
    public enum DisplayType
    {
        [StringValue("Portrait")]
        Portrait = 0,
        [StringValue("Landscape")]
        Landscape
    };

    /// <summary>
    /// Visibility Toggle
    /// </summary>
    public enum Visibility
    {
        [StringValue("No")]
        No = 0,
        [StringValue("Yes")]
        Yes = 1
    };

    /// <summary>
    /// This enum contains all SubSites
    /// </summary>
    public enum SubSite
    {
        [StringValue("/")]
        Home = 0,
        [StringValue("Tabc")]
        Tabc,
        [StringValue("Dir")]
        Dir,
        [StringValue("HR")]
        HR,
        [StringValue("IT")]
        IT
    }
}
