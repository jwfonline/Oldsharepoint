﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace Iascend.Intranet.EnumsConstants.Constants
{
    public sealed class DiscussionBoardConstants
    {
        public sealed class ContentTypes
        {
            public sealed class Custom
            {
                public const string Group = @"Iascend Content Types";

                public sealed class DiscussionConfiguration
                {
                    public static readonly string[] DeprecatedFields = new string[] { @"Title" };
                    public const string Description = @"";
                    public const string Name = @"Discussion Configuration";
                    public const string ParentTypeName = @"Item";
                    public static readonly string[] Fields = new string[] { SiteColumns.Custom.BoardDisplayOrder.Title, SiteColumns.Custom.BoardImage.Title, SiteColumns.Custom.BoardURL.Title };
                }
            }

            public sealed class Standard
            {
                public sealed class Discussion
                {
                    public static readonly SPContentTypeId ContentTypeId = new SPContentTypeId(@"0x012002"); 
                    public const string Name = @"Discussion";
                }

                public sealed class Message
                {
                    public static readonly SPContentTypeId ContentTypeId = new SPContentTypeId(@"0x0107");
                    public const string Name = @"Message";
                }
            }
        }

        public sealed class Lists
        {
            public sealed class Custom
            {
                public sealed class DiscussionConfigurations
                {
                    public const string Title = @"Discussion Configurations";
                    public const string Description = @"";
                    public static readonly SPListTemplateType TemplateType = SPListTemplateType.GenericList;
                    public static readonly string[] ContentTypes = new string[] { DiscussionBoardConstants.ContentTypes.Custom.DiscussionConfiguration.Name };
                }
            }

            public sealed class Standard
            {
                public sealed class DiscussionBoard
                {
                    public static readonly SPListTemplateType TemplateType = SPListTemplateType.DiscussionBoard;
                    public static readonly string[] ContentTypes = new string[] { DiscussionBoardConstants.ContentTypes.Standard.Discussion.Name, DiscussionBoardConstants.ContentTypes.Standard.Message.Name };

                    public sealed class Feilds
                    {
                        public sealed class Body
                        {
                            public const string StaticName = @"Body";
                            public const string Title = @"Body";
                            public static readonly SPFieldType Type = SPFieldType.Note;
                        }

                        public sealed class ContentType
                        {
                            public const string StaticName = @"ContentType";
                            public const string Title = @"Content Type";
                            public static readonly SPFieldType Type = SPFieldType.Computed;
                        }

                        public sealed class Created
                        {
                            public const string StaticName = @"Created";
                            public const string Title = @"Created";
                            public static readonly SPFieldType Type = SPFieldType.DateTime;
                        }

                        public sealed class CreatedBy
                        {
                            public const string StaticName = @"Author";
                            public const string Title = @"Created By";
                            public static readonly SPFieldType Type = SPFieldType.User;
                        }

                        public sealed class Subject
                        {
                            public const string StaticName = @"Title";
                            public const string Title = @"Subject";
                            public static readonly SPFieldType Type = SPFieldType.Text;
                        }
                    }
                }
            }
        }

        public sealed class SiteColumns
        {
            public sealed class Custom
            {
                public const string Group = @"Iascend Intranet Columns";

                public sealed class BoardDisplayOrder
                {
                    public const string Description = @"";
                    public const string DisplayName = @"DiscussionBoardDisplayOrder";
                    public static readonly SPFieldType FieldType = SPFieldType.Number;
                    public static readonly Nullable<SPNumberFormatTypes> NumberFormat = SPNumberFormatTypes.NoDecimal;
                    public const bool Required = false;
                    public const string Title = @"Display Order";
                    public static readonly Nullable<SPUrlFieldFormatType> UrlFormat = null;
                }

                public sealed class BoardImage
                {
                    public const string Description = @"";
                    public const string DisplayName = @"DiscussionBoardImage";
                    public static readonly SPFieldType FieldType = SPFieldType.URL;
                    public static readonly Nullable<SPNumberFormatTypes> NumberFormat = null;
                    public const bool Required = true;
                    public const string Title = @"Board Image";
                    public static readonly Nullable<SPUrlFieldFormatType> UrlFormat = SPUrlFieldFormatType.Image;
                }

                public sealed class BoardURL
                {
                    public const string Description = @"";
                    public const string DisplayName = @"DiscussionBoardURL";
                    public static readonly SPFieldType FieldType = SPFieldType.URL;
                    public static readonly Nullable<SPNumberFormatTypes> NumberFormat = null;
                    public const bool Required = true;
                    public const string Title = @"Board URL";
                    public static readonly Nullable<SPUrlFieldFormatType> UrlFormat = SPUrlFieldFormatType.Hyperlink;
                }
            }

            public sealed class Standard
            {

            }
        }
    }
}
