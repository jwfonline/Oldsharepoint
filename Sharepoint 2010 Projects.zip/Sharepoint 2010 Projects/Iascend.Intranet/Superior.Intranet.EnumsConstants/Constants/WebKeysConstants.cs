using System;
using System.Collections.Generic;
using System.Text;

namespace Iascend.Intranet.EnumsAndConstants.Constants
{
    /// <summary>
    /// Keys used to access configuration settings in the application's Web.config file.
    /// </summary>
    public class WebKeys
    {
        #region [Key used to get the mail server]

        public const string MAIL_SERVER = "EmailServer";                                    
        public const string MESSAGE_DONOTREPLY = "Message.DoNotReply";

        #endregion

        #region [Key to get MSMQ name setting from web.config]

        public const string MSMQ_QUEUE = "MSMQ.Queue";

        #endregion

        #region [List placeholder]

        public const string LIST_PLACEHOLDER = "List.Placeholder";

        #endregion
    }
}
