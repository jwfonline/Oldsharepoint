﻿function RibbonGroupHandler() {
    alert('RibbonGroupHandler');
}

// Shows custom dialog using SharePoint Client JS OM
function RibbonButtonHandler() {

    // var listId = new SP.Guid(SP.ListOperation.Selection.getSelectedList());
    //var layoutsUrl = SP.Utilities.Utility.getLayoutsPageUrl('/RibbonDemo/SendAlertEmail.aspx?items=' + ItemsID + '&amp;source=' + listId);
    //   var listId = queryStringVals["ListId"];

    var options = {
        url: 'http://win-mjd65clcebq/it/_layouts/Iascend.Intranet.Site/SendAlertEmail.aspx?itemId=1&amp;listId={439F7D30-DF0C-439E-99A7-45288B5234B4}',
        tite: 'Email Alerts',
        allowMaximize: false,
        showClose: true,
        width: 800,
        height: 600
    };
    SP.UI.ModalDialog.showModalDialog(options);
    
    
}
