﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;
using System.Text;


namespace Iascend.Intranet.Site.Layouts.Iascend.Intranet.Site
{
    public partial class SendOutageResolution : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        // protected Label LabelItems;
        //protected TextBox TextDestination;

        //  protected System.Collections.Generic.List<SPListItem> ListItems;

        public string subject
        {
            get
            {
                return Convert.ToString(ViewState["subject"]);
            }
            set
            {
                ViewState["subject"] = value;
            }
        }


        public string htmlBody
        {
            get
            {
                return Convert.ToString(ViewState["htmlBody"]);
            }
            set
            {
                ViewState["htmlBody"] = value;

            }
        }
        protected override void OnLoad(EventArgs e)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["itemId"] != null && Request.QueryString["listId"] != null)
                {
                    // string listId = Request.QueryString["listId"];
                    Int32 itemId = Convert.ToInt32(Request.QueryString["itemId"]);

                    //Label3.Text = Context.Request.Url.ToString();

                    // source = source.Substring(1, source.Length - 2).ToLower();
                    try
                    {
                    // Guid sourceID = new Guid(listId);
                    //hard coding in list name for now
                    SPList alist = (SPList)SPContext.Current.Web.Lists["Tickers"];
                    SPListItem listitem = alist.GetItemById(itemId);

                    //set the alert to closed
                    listitem["Open"] = "0";
                   //listitem["AlertSentDate"] = DateTime.Now;
                    SPContext.Current.Web.AllowUnsafeUpdates = true;
                    listitem.Update();
                    SPContext.Current.Web.AllowUnsafeUpdates = false;

                    SPList etlist = SPContext.Current.Web.Lists["OutageEmailTemplate"];
                    SPListItem emailTemplate = etlist.GetItemById(1);

                    subject = "NOTIFICATION OF OUTAGE RESOLUTION: " + Convert.ToString(listitem["Title"]);
                    //dirty will go back and check on status if open highlight red if closed highlight green
                    string bodyheader = Convert.ToString(emailTemplate["EmailTemplate"]);
                    StringBuilder htmlbodybuilder = new StringBuilder();
                    htmlbodybuilder.Append(bodyheader);
                    htmlbodybuilder.Append("<br />");
                    htmlbodybuilder.Append("<br />");
                    htmlbodybuilder.Append(subject);

                    htmlbodybuilder.Append(Convert.ToString(listitem["Body"]));
                    // Label1.Text = listitem["Title"].ToString();
                    // Label2.Text = listitem["Body"].ToString();
                    htmlBody = htmlbodybuilder.ToString();
                    //  htmlBody =   htmlBody.Replace(" ", "%20");
                    litEmailMsg.Text = htmlBody;
                    HyperLink1.NavigateUrl = "mailto:" + Convert.ToString(emailTemplate["EmailTemplate"]) + "?subject=" + subject + "&body=" + htmlBody;
                    HyperLink1.Text = "Send Email";

                    }
                    catch (Exception Ex)
                    {
                        lblMsg.Text = "Error has Occurred";
                        System.Diagnostics.Debug.Write(Ex.ToString());
                        throw Ex;

                    }
                }
            }
        }

        protected void btnSendEmail_Click(object sender, EventArgs e)
        {
            Sendemail("jermaine.franklin@perficient.com", "jermaine.franklin@perficient.com", subject, htmlBody);
        }


        /// <summary>
        /// sends a email using the sharepoint sputility should add to the Iascend.Intranet.Framework.Helpers
        /// </summary>
        /// <param name="from"></param>
        /// <param name="recipient"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        private void Sendemail(string @from, string recipient, string subject, string body)
        {
            try
            {
                SPWeb site = SPControl.GetContextWeb(Context);
                StringDictionary headers = new StringDictionary();
                headers.Add("to", recipient);
                //headers.Add("cc", "Don.E.galla@williams.com")
                //headers.Add("bcc", "greg.sharp@williams.com")
                headers.Add("from", @from);
                headers.Add("subject", subject);
                headers.Add("content-type", "text/html");
                //This is the default type, so isn't necessary.
                //Dim bodyText As String = "This is the body of my email, in html format."
                // string fullHTML = cssStyles() + body;
                SPUtility.SendEmail(site, headers, body);
                lblMsg.Text = "Email Sent";
            }
            catch (Exception Ex)
            {
                lblMsg.Text = "Error has Occurred";
                System.Diagnostics.Debug.Write(Ex.ToString());
                throw Ex;

            }
        }
    }
}
