﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Data;

namespace Polling.PollingWebPart
{
    public partial class PollingWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack == true)
            {
                QuestionAndResultPart();
            }
        }
        void QuestionAndResultPart()
        {
            try
            {


                SPSite mysite = SPContext.Current.Site;
                SPWeb myweb = SPContext.Current.Web;
                SPList polllist = myweb.Lists["Poll List"];
                SPListItemCollection polllistitems = polllist.Items;

                //Get Valid Question Start
                int MaxId = 0;
                int QuestionAvailableFlag = 0;
                foreach (SPListItem polllistitem1 in polllistitems)
                {
                    string strActive = polllistitem1["Poll Active"].ToString();
                    if (strActive == "Active")
                    {
                        DateTime dtStartdate = Convert.ToDateTime(polllistitem1["Poll Start Date"].ToString());
                        DateTime dtExpirydate = Convert.ToDateTime(polllistitem1["Poll End Date"].ToString());
                        if (DateTime.Compare(dtStartdate, dtExpirydate) <= 0)
                        {
                            MaxId = polllistitem1.ID;
                        }
                    }
                }
                SPListItem polllistitem = polllist.Items.GetItemById(MaxId);
                string stryes = polllistitem["Total Yes"].ToString();
                string strno = polllistitem["Total No"].ToString();
                string strquestion = polllistitem["Title"].ToString();
                string stroptionA = polllistitem["Option A"].ToString();
                string stroptionB = polllistitem["Option B"].ToString();
                //Get Valid Question End



                //Question Part Start
                string currentuser = SPContext.Current.Web.CurrentUser.Name.ToString();
                lblTitle.Text = strquestion;
                rdbtnYes.Text = "";
                rdbtnNo.Text = "";
                lblOptionA.Text = stroptionA;
                lblOptionB.Text = stroptionB;

                SPList userpolllist = myweb.Lists["User Poll List"];
                SPListItemCollection userpollitems = userpolllist.Items;
                int emptyvalue = 0;
                foreach (SPListItem polluserlistitem1 in userpollitems)
                {
                    emptyvalue = 1;
                    if (polluserlistitem1["Title"].ToString() == strquestion && Convert.ToString(polluserlistitem1["Voter's Name"]) == currentuser)
                    {
                        //Result Process Start
                        if (MaxId != 0)
                        {
                            double yesans = 0;
                            double noans = 0;
                            double total = 0;
                            double yesresult = 0;
                            double noresult = 0;
                            if (stryes.Trim() != "")
                                yesans = Convert.ToDouble(stryes);
                            if (strno.Trim() != "")
                                noans = Convert.ToDouble(strno);

                            total = yesans + noans;
                            yesresult = (yesans / total) * (100);
                            noresult = (noans / total) * (100);
                            lbltitle1.Text = strquestion;
                            lblyes.Text = stroptionA;
                            lblno.Text = stroptionB;
                            int finalyesresult = Convert.ToInt32(Math.Round(yesresult));
                            int finalnoresult = Convert.ToInt32(Math.Round(noresult));
                            lblyesvalue.Text = finalyesresult + "%";
                            lblnovalue.Text = finalnoresult + "%";
                            tdYes.Width = finalyesresult.ToString();
                            tdNo.Width = finalnoresult.ToString();
                        }
                        //Result Process End
                        pnlpoll.Visible = false;
                        pnlresults.Visible = true;
                        break;
                    }
                    else
                    {
                        pnlpoll.Visible = true;
                        pnlresults.Visible = false;
                    }
                }
                if (emptyvalue == 0)
                    pnlpoll.Visible = true;
                //QUestion Part End
            }
            catch (Exception exe)
            {
                string strexe = exe.ToString();
                lblMsg.Text += strexe;
            }
        }

        protected void butVote_Click(object sender, EventArgs e)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite site1 = new SPSite(SPContext.Current.Site.ID))
                        {

                            using (SPWeb eweb = site1.OpenWeb())
                            {
                                SPWeb myweb = SPContext.Current.Web;
                                SPSite site = SPContext.Current.Site;
                                myweb.AllowUnsafeUpdates = true;

                                SPList polllist = myweb.Lists["Poll List"];
                                SPList userpolllist = myweb.Lists["User Poll List"];
                                SPListItemCollection polllistitems = polllist.Items;
                                int MaxId = 0;
                                foreach (SPListItem polllistitem1 in polllistitems)
                                {
                                    MaxId = polllistitem1.ID;
                                }
                                SPListItem polllistitem = polllist.Items.GetItemById(MaxId);
                                SPListItem userpolllistitem = userpolllist.Items.Add();

                                string question = polllistitem["Title"].ToString();
                                int yes = Convert.ToInt32(polllistitem["Total Yes"].ToString());
                                int no = Convert.ToInt32(polllistitem["Total No"].ToString());


                                if (rdbtnYes.Checked == true)
                                {
                                    yes = yes + 1;
                                }
                                if (rdbtnNo.Checked == true)
                                {
                                    no = no + 1;
                                }

                                polllistitem["Total Yes"] = yes;
                                polllistitem["Total No"] = no;


                                userpolllistitem["Title"] = question;
                                userpolllistitem["Voter's Name"] = SPContext.Current.Web.CurrentUser.Name.ToString();
                                userpolllistitem.Update();
                                polllistitem.Update();
                                //dirty way to prevent mutiple results for the poll
                                Response.Redirect(@"/");
                            }
                        }

                    });
            QuestionAndResultPart();   
        }
    }
}
